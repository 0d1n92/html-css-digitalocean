export const scrollToTargetElement = targetElement => {
  const element = document.getElementById(targetElement);
  element.scrollIntoView();
};
