import Cookies from 'js-cookie';

export default function initHomepageTest() {
  if (!Cookies.get('home_hero_messaging_10_22_2020')) {
    const randomAssignment = Math.random();
    Cookies.set('home_hero_messaging_10_22_2020', 
    `${randomAssignment <= 0.05
      ? 'treatment_A'
      : randomAssignment > 0.05 && randomAssignment <= 0.1
        ? 'treatment_B'
        : randomAssignment > 0.1 && randomAssignment <= 0.15
          ? 'treatment_C'
          : randomAssignment > 0.15 && randomAssignment <= 0.2
            ? 'treatment_D'
            : 'control'}`, { expires: 60 });
  }
}
