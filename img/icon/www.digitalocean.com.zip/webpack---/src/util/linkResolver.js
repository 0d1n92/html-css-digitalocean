module.exports = {
  linkResolver(doc) {
    if (doc.type === 'page' || doc.type === 'page2' || doc.type === 'page3') {
      return `/${doc.uid}`;
    }

    if (doc.type === 'home') {
      return '/';
    }

    if (doc.type === 'landing') {
      return `/${doc.uid}/`;
    }

    if (doc.type === 'productsoverview') {
      return `/${doc.uid}/`;
    }

    if (doc.type === 'products') {
      return `/products/${doc.uid}/`;
    }

    if (doc.type === 'productslinux') {
      return `/products/linux-distribution/${doc.uid}/`;
    }

    if (doc.type === 'customersoverview') {
      return `/${doc.uid}/`;
    }

    if (doc.type === 'customers') {
      return `/customers/${doc.uid}/`;
    }

    if (doc.type === 'partnersoverview') {
      return `/${doc.uid}/`;
    }

    if (doc.type === 'partners') {
      return `/partners/${doc.uid}/`;
    }

    if (doc.type === 'opensource') {
      return `/${doc.uid}/`;
    }

    if (doc.type === 'currentsoverview') {
      return `/${doc.uid}/`;
    }

    if (doc.type === 'currentsoverview') {
      return `/${doc.uid}/`;
    }

    if (doc.type === 'researchoverview') {
      return `/${doc.uid}/`;
    }

    if (doc.type === 'support') {
      return `/${doc.uid}/`;
    }

    if (doc.type === 'contactoverview') {
      return `/company/${doc.uid}/`;
    }

    if (doc.type === 'contact') {
      return `/company/contact/${doc.uid}/`;
    }

    if (doc.type === 'aboutoverview') {
      return `/${doc.uid}/`;
    }

    if (doc.type === 'about') {
      return `/about/${doc.uid}/`;
    }

    if (doc.type === 'careersoverview') {
      return `/${doc.uid}/`;
    }

    if (doc.type === 'careers') {
      return `/careers/${doc.uid}/`;
    }

    if (doc.type === 'referralprogram') {
      return `/${doc.uid}/`;
    }

    if (doc.type === 'pressoverview') {
      return `/${doc.uid}/`;
    }

    if (doc.type === 'press') {
      return `/press/${doc.uid}/`;
    }

    if (doc.type === 'pressreleases') {
      return `/press/releases/${doc.uid}/`;
    }

    if (doc.type === 'legaloverview') {
      return `/${doc.uid}/`;
    }

    if (doc.type === 'legal') {
      return `/legal/${doc.uid}/`;
    }

    if (doc.type === 'solutions') {
      return `/solutions/${doc.uid}/`;
    }

    if (doc.type === 'pricingoverview') {
      return `/${doc.uid}/`;
    }

    if (doc.type === 'hatchoverview') {
      return `/${doc.uid}/`;
    }

    if (doc.type === 'hatch') {
      return `/hatch/${doc.uid}/`;
    }

    if (doc.type === 'trustcenter') {
      return `/trust/${doc.uid}/`;
    }

    if (doc.type === 'trustcenteroverview') {
      return `/${doc.uid}/`;
    }

    if (doc.type === 'pricingtools') {
      return `/pricing/${doc.uid}/`;
    }

    if (doc.type === 'resources') {
      return `/resources/${doc.uid}/`;
    }

    if (doc.type === 'dropletsdemos') {
      return `/${doc.uid}/`;
    }

    if (doc.type === 'blog') {
      return `/blog/${doc.uid}/`;
    }

    return '/';
  },
};
