import Cookies from 'js-cookie';

const freshCustomerLifetimeDays = 90;
const maxCookieLength = 256; // We only push into the cookie the max length stored in the db

function trackLandingPage() {
  if (!Cookies.get('first_landing_page')) {
    setLandingPageCookie('first_landing_page');
  }

  if (!Cookies.get('last_landing_page')) {
    setLandingPageCookie('last_landing_page', { sessionOnly: true });
  }

  if (!Cookies.get('referrer')) {
    setLandingPageCookie('referrer', { value: document.referrer });
  }
}

/**
 * Set cookie for landing pages
 * @return {void}
 */
function setLandingPageCookie(name, options = {}) {
  const cookieOptions = { domain: window.cookieDomain, path: '/', secure: true };

  if (!options.sessionOnly) {
    cookieOptions.expires = freshCustomerLifetimeDays;
  }

  let cookieValue = options.value;

  if (!cookieValue) {
    const uri = window.location;

    cookieValue = uri.pathname + uri.search + uri.hash;
    cookieValue = cookieValue.substring(0, maxCookieLength);
  }

  // Set cookie
  Cookies.set(name, cookieValue, cookieOptions);
}

function referralRegistrationUrl(refcode) {
  return `https://cloud.digitalocean.com/referrals/${refcode}/register`;
}

function registerReferralCode(url) {
  const matches = url.search.match(/refcode=(\w+)/);

  if (matches) {
    const refcode = matches[1];

    fetch(referralRegistrationUrl(refcode), {
      method: 'GET',
      mode: 'cors',
      credentials: 'include'
    });
  }
}

function queryForm(settings) {
  let reset = settings && settings.reset ? settings.reset : false;
  let self = window.location.toString();
  let querystring = self.split('?');

  if (querystring.length > 1) {
    let pairs = querystring[1].split('&');

    for (const i in pairs) {
      let keyval = pairs[i].split('=');

      if (reset || sessionStorage.getItem(keyval[0]) === null) {
        sessionStorage.setItem(keyval[0], keyval[1]);
      }
    }
  }

  let hiddenFields = document.querySelectorAll("input[type=hidden]");

  for (let i = 0; i < hiddenFields.length; i++) {
    let param = sessionStorage.getItem(hiddenFields[i].name);

    if (param) document.getElementsByName(hiddenFields[i].name)[0].value = param;
  }
}

function getOriginalReferrer() {
  let originalReferrer = document.referrer;

  if (originalReferrer.length > 0 && sessionStorage.getItem('original_referrer') === null) {
    sessionStorage.setItem('original_referrer', originalReferrer);
  }

  let hiddenFields = document.querySelectorAll("input[type=hidden]");

  for (let i = 0; i < hiddenFields.length; i++) {
    let name = sessionStorage.getItem(hiddenFields[i].name);

    if (name) document.getElementsByName(hiddenFields[i].name)[0].value = name;
  }
}

function getLastReferrer() {
  let lastReferrer = document.referrer;

  if (lastReferrer.length > 0 && lastReferrer !== window.location) {
    sessionStorage.setItem('last_referrer', lastReferrer);
  }

  let hiddenFields = document.querySelectorAll("input[type=hidden]");

  for (let i = 0; i < hiddenFields.length; i++) {
    let name = sessionStorage.getItem(hiddenFields[i].name);

    if (name) document.getElementsByName(hiddenFields[i].name)[0].value = name;
  }
}

export default function init() {
  trackLandingPage();
  registerReferralCode(window.location);
  queryForm({reset: true});
  getOriginalReferrer();
  getLastReferrer();
};
