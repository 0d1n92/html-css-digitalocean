// Here we replace any of the the utm querystring paramters with an underscore and send all append all other querystring paramaters to marketo along with full URL and marketo account info.
export const mktoFormDetails = (rawUrl, marketoFormId, munchkinAccountId) => {
	return `&_mktoReferrer=${encodeURI(rawUrl)}&formid=${marketoFormId}&formVid=${marketoFormId}&munchkinid=${munchkinAccountId}`
}