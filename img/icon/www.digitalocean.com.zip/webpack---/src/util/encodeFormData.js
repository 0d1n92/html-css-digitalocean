// Functions for getting data from visabile form fields, hidden form fields and passing data from querystring param values

// This function compares the data object keys and the setFormNameArry and matches them up by name. Some form field names are different than what the post name should be.
export const encodeFormData = (keys, formNameArray, data) => formNameArray
  .filter(formName => keys.indexOf(formName.name) > -1)
  .map(formName => `&${formName.query_name}=${encodeURIComponent(data[formName.name])}`)
  .reduce((acc, val) => acc + val);

