// Util function you pass a key or key/value set to check if they exsist in users cookies and return true or false
export const checkCookies = (key, value) => {
  if (value) {
    const hasKeyValue =
      typeof document !== 'undefined' && document.cookie
        ? document.cookie.split(';').filter(item => item.trim() === `${key}=${value}`).length
        : null;
    return hasKeyValue > 0;
  }
  const hasKey =
    typeof document !== 'undefined' && document.cookie
      ? document.cookie.split(';').filter(item => item.trim().startsWith(`${key}=`)).length
      : null;
  return hasKey > 0;
};
