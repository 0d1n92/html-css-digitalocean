// This function compares the data object keys and the setFormNameArry to values that didn't match. This is so we can pick up any hidden fields.
export const encodeHiddenFormValues = (keys, setFormNameArry, data) =>
  keys
    .filter(d => !setFormNameArry.map(form => form.name).includes(d))
    .map(d => `${data[d] ? `&${d}=${encodeURIComponent(data[d])}` : ''}`)
    .reduce((acc, val) => acc + val);
