// Util function you pass a key or key/value set to check if they exsist in URL params
export const checkURLParams = (params, key, value) => {
  // change params string into object
  const paramsObj = params
    .slice(1)
    .split('&')
    .reduce((obj, data) => {
      const [k, v] = data.split('=');
      obj[k] = v;
      return obj;
    }, {});

  return value ? paramsObj[key] === value : Object.prototype.hasOwnProperty.call(paramsObj, key);
};
