// Here we replace any of the the utm querystring paramters with an underscore and send all append all other querystring paramaters to marketo along with full URL and marketo account info.
export const encodeUrlParams = (urlParamKeys, url) => urlParamKeys
  .map(param => `&${param.includes('utm_') ? param.replace('utm_','utm') : param}=${url.searchParams.get(param)}`)
  .reduce((acc, val) => acc + val);