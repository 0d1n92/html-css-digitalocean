/* eslint-disable no-nested-ternary */

export const setLinkUrl = url => {
  try {
    const parsedURL = new URL(url);

    return parsedURL.host.includes('digitalocean.com')
      ? parsedURL.pathname.indexOf('/docs') === 0 ||
        parsedURL.pathname.indexOf('/community') === 0 ||
        parsedURL.pathname.indexOf('/support') === 0 ||
        parsedURL.pathname.indexOf('/assets/community') === 0 ||
        parsedURL.hostname.includes('go.digitalocean.com') ||
        parsedURL.hostname.includes('cloud.digitalocean.com') ||
        parsedURL.hostname.includes('cloudsupport.digitalocean.com') ||
        parsedURL.hostname.includes('developers.digitalocean.com') ||
        parsedURL.hostname.includes('hacktoberfest.digitalocean.com') ||
        parsedURL.hostname.includes('blog.digitalocean.com') ||
        parsedURL.hostname.includes('marketplace.digitalocean.com') ||
        parsedURL.hostname.includes('status.digitalocean.com') ||
        parsedURL.hostname.includes('store.digitalocean.com') ||
        parsedURL.hostname.includes('speedtest-ams2.digitalocean.com') ||
        parsedURL.hostname.includes('speedtest-ams3.digitalocean.com') ||
        parsedURL.hostname.includes('speedtest-blr1.digitalocean.com') ||
        parsedURL.hostname.includes('speedtest-fra1.digitalocean.com') ||
        parsedURL.hostname.includes('speedtest-lon1.digitalocean.com') ||
        parsedURL.hostname.includes('speedtest-nyc1.digitalocean.com') ||
        parsedURL.hostname.includes('speedtest-nyc2.digitalocean.com') ||
        parsedURL.hostname.includes('speedtest-nyc3.digitalocean.com') ||
        parsedURL.hostname.includes('speedtest-sfo1.digitalocean.com') ||
        parsedURL.hostname.includes('speedtest-sfo2.digitalocean.com') ||
        parsedURL.hostname.includes('speedtest-sfo3.digitalocean.com') ||
        parsedURL.hostname.includes('speedtest-sgp1.digitalocean.com') ||
        parsedURL.hostname.includes('speedtest-tor1.digitalocean.com') ||
        parsedURL.hostname.includes('assets.digitalocean.com')
        ? url
        : `${parsedURL.pathname.replace(/\/?(\?|#|$)/, '/$1')}${parsedURL.hash}${parsedURL.search}`
      : url;
  } catch (error) {
    if (error instanceof TypeError) {
      return null;
    }
    throw error;
  }
};
