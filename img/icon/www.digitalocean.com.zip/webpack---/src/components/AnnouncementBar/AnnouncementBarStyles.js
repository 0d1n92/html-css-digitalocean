// Styles here will override Bulma styles
import styled from '@emotion/styled';
import media from 'css-in-js-media';

import { LazyLink } from '../../slices/atoms';

export const StyledBarLink = styled(LazyLink)`
  position: absolute;
  z-index: 29;
  top: 32px;
  left: 0;
  right: 0;
  margin-left: auto;
  margin-right: auto;
  width: 80vw;
  border-radius: 6px;
  max-width: 1170px;
  box-sizing: border-box;
  box-shadow: 0 2px 4px rgba(3, 27, 78, 0.06) !important;
  transition: all 0.5s ease;
  display: flex;
  justify-content: center;
  align-items: center;
  cursor: pointer;
  background-color: ${props => props.backgroundColor};

  ${media('< desktop')} {
    flex-direction: column;
    top: 10px;
    width: 90vw;
  }

  &:first-of-type {
    margin-top: 0px;
  }

  p {
    color: ${props => props.color};
    margin: 10px;
    padding-top: 1px;
    text-align: center;

    ${media('<= desktop')} {
      font-size: 14px;
    }
  }

  &:hover {
    box-shadow: 0 10px 20px rgba(3, 27, 78, 0.1) !important;
    transform: scale(1.005);
    background-color: ${props => props.backgroundColor || '#15cd72'} !important;
  }
`;

export const StyledBar = styled.aside`
  position: absolute;
  z-index: 29;
  top: 32px;
  left: 0;
  right: 0;
  margin-left: auto;
  margin-right: auto;
  width: 80vw;
  border-radius: 6px;
  max-width: 1170px;
  box-sizing: border-box;
  box-shadow: 0 2px 4px rgba(3, 27, 78, 0.06) !important;
  transition: all 0.5s ease;
  display: flex;
  justify-content: center;
  align-items: center;

  ${media('< desktop')} {
    flex-direction: column;
    top: 10px;
    width: 90vw;
  }

  &:first-of-type {
    margin-top: 0px;
    margin-bottom: 0px;
  }

  p {
    color: ${props => props.color} !important;
    margin: 10px;
    padding-top: 1px;
    text-align: center;

    ${media('<= desktop')} {
      font-size: 14px;
    }
  }
`;

export const StyledIcon = styled.img`
  padding-right: 5px;
  max-width: 20px;

  ${media('<= desktop')} {
    padding-right: 0;
    padding-top: 10px;
  }
`;
