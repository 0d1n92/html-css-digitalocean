/* eslint-disable camelcase */
import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { RichText } from 'prismic-reactjs';
import { StaticQuery, graphql } from 'gatsby';
import { globalHistory as history } from '@reach/router';

import { StyledBarLink, StyledBar, StyledIcon } from './AnnouncementBarStyles';

import { linkResolver } from '../../util/linkResolver';
import { checkCookies } from '../../util/checkCookies';
import { checkURLParams } from '../../util/checkURLParams';

const query = graphql`
  query {
    prismic {
      allAnnouncementbars(sortBy: meta_lastPublicationDate_DESC) {
        edges {
          node {
            title
            background_color
            text_color
            utm_source
            icon
            referral_credit_text
            referral_link_credit_text
            _linkType
            link {
              ... on PRISMIC__ExternalLink {
                _linkType
                url
              }
            }
          }
        }
      }
    }
  }
`;

const renderContent = (item, paramStr) => {
  const { background_color, text_color, icon, link, referral_credit_text, referral_link_credit_text } = item.node;

  const content =
    checkURLParams(paramStr, 'utm_source') && referral_link_credit_text
      ? referral_link_credit_text
      : referral_credit_text;

  return link && link.url ? (
    <StyledBarLink
      url={link.url}
      style={{
        backgroundColor: background_color || '#15cd72',
      }}
      key={content && content.text}
      color={text_color === 'light' ? 'white' : null}
    >
      {icon && icon.url ? <StyledIcon src={icon.url} alt="icon for banner" /> : null}
      <RichText render={content} linkResolver={linkResolver} />
    </StyledBarLink>
  ) : (
    <StyledBar
      style={{ backgroundColor: background_color || '#15cd72' }}
      key={content && content.text}
      color={text_color === 'light' ? 'white' : null}
    >
      {icon && icon.url ? <StyledIcon src={icon.url} alt="icon for banner" /> : null}
      <RichText render={content} linkResolver={linkResolver} />
    </StyledBar>
  );
};

const RenderAnnouncementBar = ({ data, paramStr }) => {
  const { edges } = data.prismic.allAnnouncementbars;

  const [currentRefCookie, setRefCurrentCookie] = useState(checkCookies('refcode'));

  // this logic intercepts any fetch and if it includes a refcode it will update our state to show the
  // refcode AnnouncementBar
  useEffect(() => {
    if (typeof window === 'undefined') return;
    const nativeFetch = window.fetch;
    window.fetch = function(...args) {
      const refcode = args[0].match(/\/referrals\/(\w+)\/register/);
      setRefCurrentCookie(refcode && refcode[1]);
      return nativeFetch.apply(window, args);
    };
  }, []);

  // if utm_source exists in Prismic and is in the URL param - display it as the announcement bar
  const utmBar = edges.find(item => {
    const { utm_source } = item.node;
    return utm_source && checkURLParams(paramStr, 'utm_source', utm_source);
  });

  if (utmBar) {
    return renderContent(utmBar, paramStr);
  }

  // if there's any refcode in the URL params and/or saved in cookies find the most recent AnnouncementBar
  // that does not have a utm_source in Prismic and display that
  const aBar = edges.find(item => {
    const { utm_source } = item.node;
    return (
      (!checkCookies('last_logged_in_at') && checkURLParams(paramStr, 'refcode') && !utm_source) ||
      (!checkCookies('last_logged_in_at') && currentRefCookie && !utm_source)
    );
  });

  if (aBar) {
    return renderContent(aBar, paramStr);
  }

  return null;
};

const AnnouncementBar = () => {
  const { search } = history.location;
  return (
    <>
      <StaticQuery query={`${query}`} render={data => <RenderAnnouncementBar data={data} paramStr={search} />} />
    </>
  );
};

export default AnnouncementBar;

RenderAnnouncementBar.propTypes = {
  data: PropTypes.object.isRequired,
  paramStr: PropTypes.string.isRequired,
};
