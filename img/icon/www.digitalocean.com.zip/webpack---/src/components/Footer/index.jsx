import React from 'react';
import PropTypes from 'prop-types';

import { StaticQuery, graphql } from 'gatsby';

import BulmaColumns from 'react-bulma-components/lib/components/columns';
import BulmaContainer from 'react-bulma-components/lib/components/container';
import BulmaFooter from 'react-bulma-components/lib/components/footer';
import { footerStyled, footerColumnsStyled } from './FooterStyles';

import CompanyDetails from './CompanyDetails';
import Links from './Links';

const query = graphql`
  query MyQuery {
    prismic {
      footer(lang: "en-us", uid: "site-footer") {
        solution_links_title
        community_links {
          community_link {
            ... on PRISMIC__ExternalLink {
              _linkType
              url
            }
          }
          rel
          community_link_text
        }
        community_links_title
        company_links {
          company_link {
            ... on PRISMIC__ExternalLink {
              _linkType
              url
            }
          }
          rel
          company_link_text
        }
        company_links_title
        contact_links {
          contact_link {
            ... on PRISMIC__ExternalLink {
              _linkType
              url
            }
          }
          rel
          contact_link_text
        }
        contact_links_title
        copyright
        logo
        product_links {
          product_link {
            ... on PRISMIC__ExternalLink {
              _linkType
              url
            }
          }
          rel
          product_link_text
        }
        product_links_title
        social_links {
          social_icon
          social_link {
            ... on PRISMIC__ExternalLink {
              _linkType
              url
            }
          }
          rel
        }
        solution_links {
          solution_link {
            ... on PRISMIC__ExternalLink {
              _linkType
              url
            }
          }
          solution_link_text
          rel
        }
      }
    }
  }
`;

const RenderFooter = ({ data }) => {
  const { footer } = data.prismic;
  return (
    <BulmaFooter css={footerStyled}>
      <BulmaContainer>
        <BulmaColumns breakpoint="mobile" is-multiline="false" css={footerColumnsStyled}>
          {Links(footer)}
        </BulmaColumns>

        <BulmaColumns is-multiline="false" css={footerColumnsStyled}>
          {CompanyDetails(footer)}
        </BulmaColumns>
      </BulmaContainer>
    </BulmaFooter>
  );
};

const Footer = () => (
  <>
    <StaticQuery query={`${query}`} render={data => <RenderFooter data={data} />} />
  </>
);

export default Footer;

RenderFooter.propTypes = {
  data: PropTypes.object.isRequired,
};
