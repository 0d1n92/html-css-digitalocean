// Styles here will override Bulma styles
import { css } from '@emotion/core';
import media from 'css-in-js-media';

export const footerStyled = css`
  text-align: center;
  background-color: hsl(220, 95%, 8%);
  color: hsla(0, 0%, 100%, 0.5);
  font-size: 14px !important;
  padding: 3rem 1.5rem;
  position: relative;
  left: 0;
  bottom: 0;
  min-height: 595px;
  overflow: hidden;

  p {
    color: hsla(0, 0%, 100%, 0.5);
    font-family: 'Sailec-Regular', 'Helvetica', 'sans-serif';
    font-size: 14px !important;
    font-weight: 400;
  }

  ul {
    list-style: none;
    text-align: left;

    a {
      color: hsla(0, 0%, 100%, 0.5);
      font-family: 'Sailec-Regular', 'Helvetica', 'sans-serif';
      font-weight: 200;
      text-decoration: none;

      :hover {
        color: hsla(0, 0%, 100%, 1) !important;
      }
    }
  }
`;

export const footerColumnsStyled = css`
  max-width: 1200px;
  margin: 0 auto;

  :first-of-type {
    padding: 0 0 20px 140px;
  }

  :last-of-type {
    border-top: 1px solid hsla(0, 0%, 100%, 0.2);
    padding-top: 20px;
  }

  ${media('< desktop')} {
    :first-of-type {
      padding: 0;
    }
  }
`;
