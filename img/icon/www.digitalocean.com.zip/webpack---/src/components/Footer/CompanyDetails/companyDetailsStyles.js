// Styles here will override Bulma styles
import { css } from '@emotion/core';
import media from 'css-in-js-media';

export const socialColumnStyled = css`
  align-items: center;
  display: flex;
  flex-direction: row;
  justify-content: space-between;

  > div:first-of-type {
    display: flex;
    flex-direction: row;
  }

  img {
    margin-right: 20px;
  }

  ${media('< tablet')} {
    flex-direction: column;
  }
`;

export const socialStyled = css`
  align-items: flex-start;
  display: flex;
  flex-direction: row;
  margin: 0 10px 0 0;

  li {
    filter: invert(100%) sepia(100%) saturate(0%) hue-rotate(52deg) brightness(150%) contrast(101%) opacity(50%);

    :hover {
      filter: invert(100%) sepia(100%) saturate(0%) hue-rotate(52deg) brightness(150%) contrast(101%) opacity(100%);
    }

    img {
      height: 1.5em;
      margin-right: 18px;
      width: 1.5em;
    }
  }

  ${media('< tablet')} {
    margin-top: 30px;
  }
`;
