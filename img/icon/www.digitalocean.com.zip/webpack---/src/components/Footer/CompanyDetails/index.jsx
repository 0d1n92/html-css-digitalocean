import React from 'react';

import BulmaColumns from 'react-bulma-components/lib/components/columns';
import { socialColumnStyled, socialStyled } from './companyDetailsStyles';
import { LazyLink, LazyImage } from '../../../slices/atoms';

const CompanyDetails = footer => (
  <BulmaColumns.Column css={socialColumnStyled} size={12}>
    <div>
      <LazyImage src={footer.logo.url} alt="Digital Ocean logo" />
      <p>{footer.copyright}</p>
    </div>

    <ul css={socialStyled}>
      {footer.social_links.map(
        item =>
          item.social_link &&
          item.social_link.url && (
            <li key={item.social_icon.alt}>
              <LazyLink
                rel={item.rel === 'nofollow' ? 'nofollow' : null}
                id={item.social_icon.alt}
                url={item.social_link.url}
              >
                <LazyImage src={item.social_icon.url} alt={item.social_icon.alt || 'social media icon'} />
              </LazyLink>
            </li>
          ),
      )}
    </ul>
  </BulmaColumns.Column>
);

export default CompanyDetails;
