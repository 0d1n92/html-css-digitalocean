import React from 'react';

import BulmaColumns from 'react-bulma-components/lib/components/columns';
import BulmaHeading from 'react-bulma-components/lib/components/heading';
import { ulStyled, headingStyled } from './LinksStyles';
import { LazyLink } from '../../../slices/atoms';

const Links = footer => (
  <>
    <BulmaColumns.Column mobile={{ size: 'half' }}>
      <BulmaHeading css={headingStyled} renderAs="h6">
        {footer.company_links_title}
      </BulmaHeading>
      <ul css={ulStyled}>
        {footer.company_links.map(item => (
          <li key={item.company_link_text}>
            <LazyLink
              rel={item.rel === 'nofollow' ? 'nofollow' : null}
              url={item.company_link && item.company_link.url}
            >
              {item.company_link_text}
            </LazyLink>
          </li>
        ))}
      </ul>
    </BulmaColumns.Column>

    <BulmaColumns.Column>
      <BulmaHeading css={headingStyled} renderAs="h6">
        {footer.product_links_title}
      </BulmaHeading>
      <ul css={ulStyled}>
        {footer.product_links.map(item => (
          <li key={item.product_link_text}>
            <LazyLink
              rel={item.rel === 'nofollow' ? 'nofollow' : null}
              url={item.product_link && item.product_link.url}
            >
              {item.product_link_text}
            </LazyLink>
          </li>
        ))}
      </ul>
    </BulmaColumns.Column>

    <BulmaColumns.Column mobile={{ size: 'half' }}>
      <BulmaHeading css={headingStyled} renderAs="h6">
        {footer.community_links_title}
      </BulmaHeading>
      <ul css={ulStyled}>
        {footer.community_links.map(item => (
          <li key={item.community_link_text}>
            <LazyLink
              rel={item.rel === 'nofollow' ? 'nofollow' : null}
              url={item.community_link && item.community_link.url}
            >
              {item.community_link_text}
            </LazyLink>
          </li>
        ))}
      </ul>
    </BulmaColumns.Column>

    <BulmaColumns.Column>
      <BulmaHeading css={headingStyled} renderAs="h6">
        {footer.solution_links_title}
      </BulmaHeading>
      <ul css={ulStyled}>
        {footer.solution_links.map(item => (
          <li key={item.solution_link_text}>
            <LazyLink
              rel={item.rel === 'nofollow' ? 'nofollow' : null}
              url={item.solution_link && item.solution_link.url}
            >
              {item.solution_link_text}
            </LazyLink>
          </li>
        ))}
      </ul>
    </BulmaColumns.Column>

    <BulmaColumns.Column mobile={{ size: 'half' }}>
      <BulmaHeading css={headingStyled} renderAs="h6">
        {footer.contact_links_title}
      </BulmaHeading>
      <ul css={ulStyled}>
        {footer.contact_links.map(item => (
          <li key={item.contact_link_text}>
            <LazyLink
              rel={item.rel === 'nofollow' ? 'nofollow' : null}
              url={item.contact_link && item.contact_link.url}
            >
              {item.contact_link_text}
            </LazyLink>
          </li>
        ))}
      </ul>
    </BulmaColumns.Column>
  </>
);

export default Links;
