// Styles here will override Bulma styles
import { css } from '@emotion/core';

export const ulStyled = css`
  margin: 0;

  li {
    margin-bottom: 10px;
  }
`;

export const headingStyled = css`
  font-size: 14px;
  text-align: left;
  color: hsl(0, 0%, 100%);
  font-weight: normal;
`;
