import React, { Component } from 'react';
import PropTypes from 'prop-types';

import { createRandomId } from '../../util/createRandomId';

import {
  CardsContact,
  CardsMasonry,
  CardsHoverLinks,
  CardsV2,
  CarouselCards,
  CarouselImage,
  CarouselTestimonial,
  CarouselVideo,
  CTABand,
  CTACollage,
  CurrentOpenings,
  CodeBlock,
  CustomerContent,
  CustomerStoryCarousel,
  ContentBlock,
  DocumentContent,
  DocumentList,
  FeaturesList,
  Frame,
  HeroBox,
  HeroCarousel,
  HeroCarouselV2,
  HeroHomeForm,
  HeroSearch,
  HeroText,
  HeroTextBranded,
  HeroTextLinks,
  HeroVideo,
  LeftSlidingNavCards,
  LeftSlidingNavContent,
  ListAlternatingV2,
  ListGridV2,
  Locations,
  LogoGrid,
  PeopleGrid,
  OfficesMapGrid,
  PressNews,
  Quote,
  QuotesCarousel,
  ResourceTable,
  SideBySide,
  SignupFormBand,
  Statistics,
  TabbedContent,
  Table,
  TableModal,
  TideForm,
  TopTabbedNavCards,
  TopTabbedNavContent,
  VideoQuote,
  PressTopTabbedLeftNavContent,
  PricingComparison,
  PricingTable,
  PromoBand,
  DropletsDemosForm,
  PositionApply,
  PageNavLinks,
  DynamicFormBuilder,
} from '../../slices';

export default class SliceZone extends Component {
  render() {
    const { allSlices } = this.props;
    const slice = allSlices.map(s => {
      switch (s.type) {
        // These are the API IDs of the slices
        case 'cardscontact':
          return <CardsContact key={createRandomId()} input={s} />;
        case 'cardsv2':
          return <CardsV2 key={createRandomId()} input={s} />;
        case 'cardshoverlinks':
          return <CardsHoverLinks key={createRandomId()} input={s} />;
        case 'cardsmasonry':
          return <CardsMasonry key={createRandomId()} input={s} />;
        case 'carouselcards':
          return <CarouselCards key={createRandomId()} input={s} />;
        case 'carouselimage':
          return <CarouselImage key={createRandomId()} input={s} />;
        case 'carouseltestimonial':
          return <CarouselTestimonial key={createRandomId()} input={s} />;
        case 'customerstorycarousel':
          return <CustomerStoryCarousel key={createRandomId()} input={s} />;
        case 'carouselvideo':
          return <CarouselVideo key={createRandomId()} input={s} />;
        case 'ctaband':
          return <CTABand key={createRandomId()} input={s} />;
        case 'ctacollage':
          return <CTACollage key={createRandomId()} input={s} />;
        case 'codeblock':
          return <CodeBlock key={createRandomId()} input={s} />;
        case 'contentblock':
          return <ContentBlock key={createRandomId()} input={s} />;
        case 'currentopenings':
          return <CurrentOpenings key={createRandomId()} input={s} />;
        case 'customercontent':
          return <CustomerContent key={createRandomId()} input={s} />;
        case 'documentcontent':
          return <DocumentContent key={createRandomId()} input={s} />;
        case 'documentlist':
          return <DocumentList key={createRandomId()} input={s} />;
        case 'dropletsdemosform':
          return <DropletsDemosForm key={createRandomId()} input={s} />;
        case 'dynamicformbuilder':
          return <DynamicFormBuilder key={createRandomId()} input={s} />;
        case 'featureslist':
          return <FeaturesList key={createRandomId()} input={s} />;
        case 'frame':
          return <Frame key={createRandomId()} input={s} />;
        case 'herobox':
          return <HeroBox key={createRandomId()} input={s} />;
        case 'herocarousel':
          return <HeroCarousel key={createRandomId()} input={s} />;
        case 'herocarouselv2':
          return <HeroCarouselV2 key={createRandomId()} input={s} />;
        case 'herosearch':
          return <HeroSearch key={createRandomId()} input={s} />;
        case 'herotext':
          return <HeroText key={createRandomId()} input={s} />;
        case 'herotextbranded':
          return <HeroTextBranded key={createRandomId()} input={s} />;
        case 'herotextlinks':
          return <HeroTextLinks key={createRandomId()} input={s} />;
        case 'herohomeform':
          return <HeroHomeForm key={createRandomId()} input={s} />;
        case 'herovideo':
          return <HeroVideo key={createRandomId()} input={s} />;
        case 'leftslidingnavcards':
          return <LeftSlidingNavCards key={createRandomId()} input={s} />;
        case 'leftslidingnavcontent':
          return <LeftSlidingNavContent key={createRandomId()} input={s} />;
        case 'listalternatingv2':
          return <ListAlternatingV2 key={createRandomId()} input={s} />;
        case 'listgridv2':
          return <ListGridV2 key={createRandomId()} input={s} />;
        case 'locations':
          return <Locations key={createRandomId()} input={s} />;
        case 'logogrid':
          return <LogoGrid key={createRandomId()} input={s} />;
        case 'officesmapgrid':
          return <OfficesMapGrid key={createRandomId()} input={s} />;
        case 'pagenavlinks':
          return <PageNavLinks key={createRandomId()} input={s} />;
        case 'peoplegrid':
          return <PeopleGrid key={createRandomId()} input={s} />;
        case 'positionapply':
          return <PositionApply key={createRandomId()} input={s} />;
        case 'pressnews':
          return <PressNews key={createRandomId()} input={s} />;
        case 'presstoptabbedleftnavcontent':
          return <PressTopTabbedLeftNavContent key={createRandomId()} input={s} />;
        case 'pricingcomparison':
          return <PricingComparison key={createRandomId()} input={s} />;
        case 'pricingtable':
          return <PricingTable key={createRandomId()} input={s} />;
        case 'promoband':
          return <PromoBand key={createRandomId()} input={s} />;
        case 'quote':
          return <Quote key={createRandomId()} input={s} />;
        case 'quotescarousel':
          return <QuotesCarousel key={createRandomId()} input={s} />;
        case 'resourcetable':
          return <ResourceTable key={createRandomId()} input={s} />;
        case 'sidebyside':
          return <SideBySide key={createRandomId()} input={s} />;
        case 'signupformband':
          return <SignupFormBand key={createRandomId()} input={s} />;
        case 'statistics':
          return <Statistics key={createRandomId()} input={s} />;
        case 'tabbedcontent':
          return <TabbedContent key={createRandomId()} input={s} />;
        case 'tideform':
          return <TideForm key={createRandomId()} input={s} />;
        case 'tobtabbednavcards':
          return <TopTabbedNavCards key={createRandomId()} input={s} />;
        case 'toptabbednavcontent':
          return <TopTabbedNavContent key={createRandomId()} input={s} />;
        case 'table':
          return <Table key={createRandomId()} input={s} />;
        case 'tablemodal':
          return <TableModal key={createRandomId()} input={s} />;
        case 'toptabbednavcards':
          return <TopTabbedNavCards key={createRandomId()} input={s} />;
        case 'videoquote':
          return <VideoQuote key={createRandomId()} input={s} />;
        default:
          return null;
      }
    });
    return <div className="slices">{slice}</div>;
  }
}

SliceZone.propTypes = {
  allSlices: PropTypes.array.isRequired,
};
