import React, { useState } from 'react';
import PropTypes from 'prop-types';

import { StaticQuery, graphql } from 'gatsby';

import BulmaNavbar from 'react-bulma-components/lib/components/navbar';
import { nav, navBarBrand, navBarMenu, primaryNavContainer, burgerContainer } from './NavigationStyles';

import TinyTopNav from './TinyTopNav';
import Brand from './Brand';
import PrimaryNavLinks from './PrimaryNavLinks';
import SecondaryNavLinks from './SecondaryNavLinks';

const query = graphql`
  query {
    prismic {
      navigation(lang: "en-us", uid: "site-navigation") {
        announcement_link {
          ... on PRISMIC__ExternalLink {
            _linkType
            url
          }
        }
        announcement_pill_text
        announcement_text
        rel
        bottom_link {
          ... on PRISMIC__ExternalLink {
            _linkType
            url
          }
        }
        bottom_link_text
        brand_name
        community_mega_menu_community {
          community_image
          community_link {
            ... on PRISMIC__ExternalLink {
              _linkType
              url
            }
          }
          community_subtitle
          community_title
        }
        community_mega_menu_community_title
        community_mega_menu_featured_articles {
          featured_articles_image
          featured_articles_link {
            ... on PRISMIC__ExternalLink {
              _linkType
              url
            }
          }
          featured_articles_text
        }
        community_mega_menu_featured_title
        community_mega_menu_get_involved {
          get_involved_link {
            ... on PRISMIC__ExternalLink {
              _linkType
              url
            }
          }
          get_involved_text
        }
        community_mega_menu_get_involved_title
        navigation_image
        primary_navigation_end_links {
          primary_navigation_end_link {
            ... on PRISMIC__ExternalLink {
              _linkType
              url
            }
          }
          primary_navigation_end_link_text
        }
        primary_navigation_links {
          primary_navigation_link {
            ... on PRISMIC__ExternalLink {
              _linkType
              url
            }
          }
          primary_navigation_text
        }
        products_mega_menu_featured {
          featured_product_image
          featured_product_link {
            ... on PRISMIC__ExternalLink {
              _linkType
              url
            }
          }
          featured_product_subtitle
          featured_product_title
        }
        products_mega_menu_secondary {
          secondary_image
          secondary_link_1 {
            ... on PRISMIC__ExternalLink {
              _linkType
              url
            }
          }
          secondary_link_2 {
            ... on PRISMIC__ExternalLink {
              _linkType
              url
            }
          }
          secondary_link_3 {
            ... on PRISMIC__ExternalLink {
              _linkType
              url
            }
          }
          secondary_link_4 {
            ... on PRISMIC__ExternalLink {
              _linkType
              url
            }
          }
          secondary_link_5 {
            ... on PRISMIC__ExternalLink {
              _linkType
              url
            }
          }
          secondary_text_1
          secondary_text_2
          secondary_text_3
          secondary_text_4
          secondary_text_5
          secondary_title
        }
        products_mega_menu_title
        solutions_mega_menu {
          solutions_image
          solutions_link {
            ... on PRISMIC__ExternalLink {
              url
              _linkType
            }
          }
          solutions_title
          solutions_subtitle
        }
        solutions_bottom_link {
          ... on PRISMIC__ExternalLink {
            _linkType
            url
          }
        }
        solutions_bottom_link_text
        tiny_navigation_links {
          tiny_navigation_link {
            ... on PRISMIC__ExternalLink {
              _linkType
              url
            }
          }
          tiny_navigation_path
          tiny_navigation_text
          tiny_link_rel
        }
      }
    }
  }
`;

const RenderNavigation = ({ data, location }) => {
  const [isActive, setIsActive] = useState(false);
  const { navigation } = data.prismic;
  const activeClassMobile = isActive ? 'is-active-mobile' : null;
  const activeClass = isActive ? 'is-active' : null;
  return (
    <>
      {TinyTopNav(navigation)}
      <BulmaNavbar css={nav}>
        <BulmaNavbar.Brand css={navBarBrand}>
          {Brand(navigation)}

          <div css={burgerContainer}>
            <BulmaNavbar.Burger
              className={activeClass}
              onClick={() => {
                setIsActive(!isActive);
              }}
            >
              <span />
              <span />
              <span />
            </BulmaNavbar.Burger>
          </div>
        </BulmaNavbar.Brand>

        <BulmaNavbar.Menu className={activeClass} css={navBarMenu}>
          <BulmaNavbar.Container css={primaryNavContainer}>
            {PrimaryNavLinks(navigation, location)}
          </BulmaNavbar.Container>
          <BulmaNavbar.Container position="end">{SecondaryNavLinks(navigation)}</BulmaNavbar.Container>
        </BulmaNavbar.Menu>
      </BulmaNavbar>
    </>
  );
};

const Navigation = location => (
  <>
    <StaticQuery query={`${query}`} render={data => <RenderNavigation location={location} data={data} />} />
  </>
);

export default Navigation;

RenderNavigation.propTypes = {
  data: PropTypes.object.isRequired,
  location: PropTypes.object.isRequired,
};
