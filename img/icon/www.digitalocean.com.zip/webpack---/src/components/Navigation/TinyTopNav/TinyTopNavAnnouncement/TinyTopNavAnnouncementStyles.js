// Styles here will override Bulma styles
import { css } from '@emotion/core';
import arrow from '../../../../assets/images/chevron-right-grey.svg';

export const tinyNavAnnouncementPill = css`
  background-color: rgb(0, 215, 210);
  color: rgb(3, 27, 78) !important;
  cursor: default;
  font-family: 'Sailec-Medium', 'Helvetica', 'sans-serif';
  line-height: 1px;
  text-align: center;
  text-transform: uppercase;
  user-select: none;
  vertical-align: middle;
  border-radius: 5px;
  padding: 9px 8px;
  font-size: 9px !important;
  margin-right: 10px;
`;

export const tinyBarP = css`
  font-family: 'Sailec-Medium', 'Helvetica', 'sans-serif';
  font-size: 12px !important;
  margin: 1px 0 0 0;
  padding: 0px;
  ::after {
    content: '';
    padding: 7px;
    background: url(${arrow}) no-repeat center;
  }
`;
