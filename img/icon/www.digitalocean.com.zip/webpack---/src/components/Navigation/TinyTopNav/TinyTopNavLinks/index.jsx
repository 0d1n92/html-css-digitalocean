/* eslint-disable camelcase */
import React from 'react';

import BulmaNavbar from 'react-bulma-components/lib/components/navbar';
import { tinyNavBarItem } from '../TinyTopNavStyles';
import { createRandomId } from '../../../../util/createRandomId';
import { LazyLink } from '../../../../slices/atoms';

const TinyTopNavLinks = data => {
  const { tiny_navigation_links } = data;

  return tiny_navigation_links.map(item => (
    <BulmaNavbar.Item
      renderAs={LazyLink}
      css={tinyNavBarItem}
      url={item.tiny_navigation_link.url}
      key={createRandomId()}
      rel={item.tiny_link_rel === 'nofollow' ? 'nofollow' : null}
    >
      {item.tiny_navigation_text}
    </BulmaNavbar.Item>
  ));
};

export default TinyTopNavLinks;
