// Styles here will override Bulma styles
import { css } from '@emotion/core';
import media from 'css-in-js-media';
import arrow from '../../../assets/images/chevron-right-blue.svg';

// TINY TOP NAV

export const tinyNav = css`
  padding-top: 0px;
  min-height: 2rem;
  position: fixed;
  top: 0;
  width: 100%;

  ${media('< desktop')} {
    display: none;
  }
`;

export const tinyNavMenu = css`
  padding-top: 0;
  min-height: 2rem;
  border-bottom: 1px solid rgb(229, 232, 237);
  font-size: 12px !important;
`;

export const tinyNavBarItem = css`
  color: #5b6987 !important;
  cursor: pointer;
  font-family: 'Sailec-Medium', 'Helvetica', 'sans-serif';
  height: 40px;
  margin: 0;
  padding: 0;
  padding-left: 25px;

  :hover > p {
    color: #0069ff;
  }

  :hover p:after {
    background: url(${arrow}) no-repeat center;
  }
`;

export const tinyNavBarEnd = css`
  margin-right: 30px;
`;
