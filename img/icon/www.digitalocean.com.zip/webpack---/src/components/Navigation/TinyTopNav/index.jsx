/* eslint-disable camelcase */
import React from 'react';

import BulmaNavbar from 'react-bulma-components/lib/components/navbar';
import { tinyNav, tinyNavMenu, tinyNavBarEnd } from './TinyTopNavStyles';

import TinyTopNavAnnouncement from './TinyTopNavAnnouncement';
import TinyTopNavLinks from './TinyTopNavLinks';

const TinyTopNav = navigation => {
  return (
    <BulmaNavbar css={tinyNav}>
      <BulmaNavbar.Menu id="tinyNavMenu" css={tinyNavMenu}>
        {TinyTopNavAnnouncement(navigation)}
        <BulmaNavbar.Container css={tinyNavBarEnd} position="end">
          {TinyTopNavLinks(navigation)}
        </BulmaNavbar.Container>
      </BulmaNavbar.Menu>
    </BulmaNavbar>
  );
};

export default TinyTopNav;
