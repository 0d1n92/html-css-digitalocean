/* eslint-disable camelcase */
import React from 'react';

import BulmaNavbar from 'react-bulma-components/lib/components/navbar';
import { tinyNavBarItem } from '../TinyTopNavStyles';
import { tinyNavAnnouncementPill, tinyBarP } from './TinyTopNavAnnouncementStyles';
import { LazyLink } from '../../../../slices/atoms';

const TinyTopNavAnnouncement = data => {
  const { announcement_link, announcement_pill_text, announcement_text, rel } = data;
  return (
    <BulmaNavbar.Item
      className="g"
      css={tinyNavBarItem}
      renderAs={LazyLink}
      url={announcement_link && announcement_link.url}
      rel={rel === 'nofollow' ? 'nofollow' : null}
    >
      <span css={tinyNavAnnouncementPill}>{announcement_pill_text}</span>
      <p css={tinyBarP}>{announcement_text}</p>
    </BulmaNavbar.Item>
  );
};

export default TinyTopNavAnnouncement;
