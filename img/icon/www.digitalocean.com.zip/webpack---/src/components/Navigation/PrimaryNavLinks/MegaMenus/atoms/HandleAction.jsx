/* eslint-disable camelcase */
import React from 'react';
import PropTypes from 'prop-types';

// recursive function to remove all 'is-active' classes
const removeClass = activeDropdowns => {
  activeDropdowns[0].classList.remove('is-active');
  if (activeDropdowns && activeDropdowns[0]) removeClass(activeDropdowns);
};

const HandleClear = () => {
  // On click or keydown first find if there are any active (open) mega menus
  const activeDropdowns = document.getElementsByClassName('is-active');
  // If there are then use recursive function removeClass to remove 'is-active' from all of them
  if (activeDropdowns && activeDropdowns[0] && activeDropdowns.length >= 1) removeClass(activeDropdowns);
};

const HandleKeydown = e => {
  // find which mega menu was clicked on and assign it to dropdownLink
  const dropdownLink = e.target.closest('.is-mega');

  // if exit is hit clear all 'is-active' classes
  if (e.keyCode === 27) {
    HandleClear();
  }

  // if enter is hit close or open mega menu based on active state
  if (e.keyCode === 13) {
    if (!dropdownLink.classList.contains('is-active')) {
      HandleClear();
      dropdownLink.classList.add('is-active');
    } else {
      HandleClear();
    }
  }
};

const HandleClick = e => {
  // find which mega menu was clicked on and assign it to dropdownLink
  const dropdownLink = e.target.closest('.is-mega');

  // If it isn't active yet clear everything else and add active class
  if (!dropdownLink.classList.contains('is-active')) {
    HandleClear();
    dropdownLink.classList.add('is-active');
  } else {
    HandleClear();
  }
};

export { HandleClear, HandleKeydown, HandleClick };

HandleKeydown.propTypes = {
  e: PropTypes.node.isRequired,
};

HandleClick.propTypes = {
  e: PropTypes.node.isRequired,
};
