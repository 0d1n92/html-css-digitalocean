/* eslint-disable camelcase */
import React from 'react';

import BulmaColumns from 'react-bulma-components/lib/components/columns';
import BulmaNavbar from 'react-bulma-components/lib/components/navbar';
import { megaMenuColumns, megaMenuBorderRight, navTitle, megaMenuDropdown } from '../MegaMenuStyles';
import {
  dropdownButton,
  dropdownNavLink,
  primaryNavLink,
  primaryNavLinkBelowDesktop,
} from '../../PrimaryNavLinksStyles';

import { LargeIconLinks, ListLinks, ArticleLinks, HandleClick, HandleKeydown } from '../atoms';
import { LazyLink } from '../../../../../slices/atoms';

const CommunityMegaMenu = (item, navigation, currentPath) => {
  const { primary_navigation_text } = item;
  const {
    community_mega_menu_community_title,
    community_mega_menu_community,
    community_mega_menu_get_involved_title,
    community_mega_menu_get_involved,
    community_mega_menu_featured_title,
    community_mega_menu_featured_articles,
  } = navigation;

  return (
    <div css={dropdownButton} className="navbar-item has-dropdown is-mega" key={primary_navigation_text}>
      <div
        role="button"
        tabIndex="0"
        aria-pressed="false"
        onClick={e => {
          HandleClick(e);
        }}
        onKeyDown={e => {
          HandleKeydown(e);
        }}
        className={`navbar-link ${currentPath === 'community' && 'active'}`}
        css={dropdownNavLink}
      >
        {primary_navigation_text}
      </div>

      <BulmaNavbar.Item
        css={[primaryNavLink, primaryNavLinkBelowDesktop]}
        url={item.primary_navigation_link && item.primary_navigation_link.url}
        key={item.primary_navigation_text}
        renderAs={LazyLink}
      >
        {item.primary_navigation_text}
      </BulmaNavbar.Item>

      <div id="communityMegaDropdown" className="navbar-dropdown" css={megaMenuDropdown}>
        <BulmaColumns css={megaMenuColumns}>
          <BulmaColumns.Column css={megaMenuBorderRight} size={4}>
            <h1 css={navTitle} className="title is-6 is-mega-menu-title">
              {community_mega_menu_community_title}
            </h1>
            {LargeIconLinks(community_mega_menu_community)}
          </BulmaColumns.Column>
          <BulmaColumns.Column css={megaMenuBorderRight} size={4}>
            <h1 css={navTitle} className="title is-6 is-mega-menu-title">
              {community_mega_menu_get_involved_title}
            </h1>
            {ListLinks(community_mega_menu_get_involved)}
          </BulmaColumns.Column>
          <BulmaColumns.Column size={4}>
            <h1 css={navTitle} className="title is-6 is-mega-menu-title">
              {community_mega_menu_featured_title}
            </h1>
            {ArticleLinks(community_mega_menu_featured_articles)}
          </BulmaColumns.Column>
        </BulmaColumns>
      </div>
    </div>
  );
};

export default CommunityMegaMenu;
