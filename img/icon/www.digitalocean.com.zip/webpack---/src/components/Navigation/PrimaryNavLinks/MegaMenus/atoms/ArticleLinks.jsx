/* eslint-disable camelcase */
import React from 'react';
import PropTypes from 'prop-types';

import BulmaNavbar from 'react-bulma-components/lib/components/navbar';
import { megaMenuArticleContainer, megaMenuArticleImg, megaMenuArticleText } from '../MegaMenuStyles';
import { LazyLink, LazyImage } from '../../../../../slices/atoms';

const ArticleLinks = data =>
  // Mapping through the Community Mega Menu data
  data.map(item => (
    <BulmaNavbar.Item
      css={megaMenuArticleContainer}
      url={item.featured_articles_link && item.featured_articles_link.url}
      key={item.featured_articles_text}
      renderAs={LazyLink}
    >
      <LazyImage
        css={megaMenuArticleImg}
        src={item.featured_articles_image.url}
        alt={item.featured_articles_image.alt || item.featured_articles_text || 'Article image'}
      />
      <p css={megaMenuArticleText}> {item.featured_articles_text}</p>
    </BulmaNavbar.Item>
  ));

export default ArticleLinks;

ArticleLinks.propTypes = {
  data: PropTypes.node.isRequired,
};
