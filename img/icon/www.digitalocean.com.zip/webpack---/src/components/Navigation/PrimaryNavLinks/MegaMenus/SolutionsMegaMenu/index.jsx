/* eslint-disable camelcase */
import React from 'react';

import BulmaColumns from 'react-bulma-components/lib/components/columns';
import BulmaNavbar from 'react-bulma-components/lib/components/navbar';
import rightArrow from '../../../../../assets/images/chevron-right-blue.svg';

import {
  dropdownButton,
  dropdownNavLink,
  primaryNavLink,
  primaryNavLinkBelowDesktop,
} from '../../PrimaryNavLinksStyles';

import {
  megaMenuColumns,
  megaMenuDropdown,
  solutionsMegaMenu,
  megaMenuHr,
  megaMenuAllLink,
  megaMenuAllLinkA,
  megaMenuArrow,
} from '../MegaMenuStyles';

import { LargeIconLinks, HandleClick, HandleKeydown } from '../atoms';
import { LazyLink, LazyImage } from '../../../../../slices/atoms';

const SolutionsMegaMenu = (item, navigation, currentPath) => {
  const { primary_navigation_text } = item;
  const { solutions_mega_menu, solutions_bottom_link, solutions_bottom_link_text } = navigation;

  return (
    <div css={dropdownButton} className="navbar-item has-dropdown is-mega" key={primary_navigation_text}>
      <div
        role="button"
        tabIndex="0"
        aria-pressed="false"
        onClick={e => {
          HandleClick(e);
        }}
        onKeyDown={e => {
          HandleKeydown(e);
        }}
        className={`navbar-link ${currentPath === 'solutions' && 'active'}`}
        css={dropdownNavLink}
      >
        {primary_navigation_text}
      </div>

      <BulmaNavbar.Item
        css={[primaryNavLink, primaryNavLinkBelowDesktop]}
        url={item.primary_navigation_link && item.primary_navigation_link.url}
        key={item.primary_navigation_text}
        renderAs={LazyLink}
      >
        {item.primary_navigation_text}
      </BulmaNavbar.Item>

      <div id="solutionsMegaDropdown" className="navbar-dropdown" css={megaMenuDropdown}>
        <BulmaColumns css={megaMenuColumns}>
          <BulmaColumns.Column css={solutionsMegaMenu} size={12}>
            {LargeIconLinks(solutions_mega_menu)}
          </BulmaColumns.Column>
        </BulmaColumns>

        <hr css={megaMenuHr} className="navbar-divider" />

        <div css={megaMenuAllLink} className="navbar-content">
          <div className="level is-mobile">
            <LazyLink css={megaMenuAllLinkA} url={solutions_bottom_link && solutions_bottom_link.url}>
              {solutions_bottom_link_text} {<LazyImage css={megaMenuArrow} src={rightArrow} alt="arrow" />}
            </LazyLink>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SolutionsMegaMenu;
