/* eslint-disable camelcase */
import React from 'react';

import BulmaColumns from 'react-bulma-components/lib/components/columns';
import BulmaNavbar from 'react-bulma-components/lib/components/navbar';
import rightArrow from '../../../../../assets/images/chevron-right-blue.svg';
import {
  dropdownButton,
  dropdownNavLink,
  primaryNavLink,
  primaryNavLinkBelowDesktop,
} from '../../PrimaryNavLinksStyles';
import {
  megaMenuColumns,
  megaMenuBorderRight,
  navTitle,
  megaMenuHr,
  megaMenuDropdown,
  megaMenuAllLink,
  megaMenuAllLinkA,
  megaMenuArrow,
} from '../MegaMenuStyles';

import { LargeIconLinks, SmallIconHeaderLinks, HandleClick, HandleKeydown } from '../atoms';
import { LazyLink, LazyImage } from '../../../../../slices/atoms';

const ProductsMegaMenu = (item, navigation, currentPath) => {
  const { primary_navigation_text } = item;
  const {
    products_mega_menu_title,
    products_mega_menu_featured,
    products_mega_menu_secondary,
    bottom_link_text,
    bottom_link,
  } = navigation;

  return (
    <div css={dropdownButton} className="navbar-item has-dropdown is-mega" key={primary_navigation_text}>
      <div
        role="button"
        tabIndex="0"
        aria-pressed="false"
        onClick={e => {
          HandleClick(e);
        }}
        onKeyDown={e => {
          HandleKeydown(e);
        }}
        className={`navbar-link ${currentPath === 'products' && 'active'}`}
        css={dropdownNavLink}
      >
        {primary_navigation_text}
      </div>

      <BulmaNavbar.Item
        css={[primaryNavLink, primaryNavLinkBelowDesktop]}
        url={item.primary_navigation_link && item.primary_navigation_link.url}
        key={item.primary_navigation_text}
        renderAs={LazyLink}
      >
        {item.primary_navigation_text}
      </BulmaNavbar.Item>

      <div id="productsMegaDropdown" className="navbar-dropdown" css={megaMenuDropdown}>
        <BulmaColumns css={megaMenuColumns}>
          <BulmaColumns.Column css={megaMenuBorderRight} size={4}>
            <h1 css={navTitle} className="title is-mega-menu-title">
              {products_mega_menu_title}
            </h1>
            {LargeIconLinks(products_mega_menu_featured)}
          </BulmaColumns.Column>
          <BulmaColumns.Column>
            <BulmaColumns>{SmallIconHeaderLinks(products_mega_menu_secondary)}</BulmaColumns>
          </BulmaColumns.Column>
        </BulmaColumns>

        <hr css={megaMenuHr} className="navbar-divider" />

        <div css={megaMenuAllLink} className="navbar-content">
          <div className="level is-mobile">
            <LazyLink css={megaMenuAllLinkA} url={bottom_link && bottom_link.url}>
              {bottom_link_text} {<LazyImage css={megaMenuArrow} src={rightArrow} alt="arrow" />}
            </LazyLink>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductsMegaMenu;
