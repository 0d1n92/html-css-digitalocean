/* eslint-disable camelcase */
/* eslint-disable array-callback-return */
import React from 'react';
import PropTypes from 'prop-types';

import BulmaNavbar from 'react-bulma-components/lib/components/navbar';

import { ProductsMegaMenu, CommunityMegaMenu, SolutionsMegaMenu } from './MegaMenus';

import { primaryNavLink } from './PrimaryNavLinksStyles';

import { LazyLink } from '../../../slices/atoms';
import { HandleClear } from './MegaMenus/atoms';

const PrimaryNavLinks = (navigation, location) => {
  const { primary_navigation_links } = navigation;

  const determineMegaMenuActiveState = () => {
    const currentPaths =
      location && location.location && location.location.pathname.split('/').filter(path => path !== '');
    if ((currentPaths && currentPaths[0] === 'solutions') || (currentPaths && currentPaths[0] === 'business')) {
      return 'solutions';
    }
    if (currentPaths && currentPaths[0] === 'products' && currentPaths && currentPaths[1] !== 'marketplace') {
      return 'products';
    }
    if ((currentPaths && currentPaths[0] === 'open-source') || (currentPaths && currentPaths[0] === 'hatch')) {
      return 'community';
    }
    return null;
  };

  const currentPath = determineMegaMenuActiveState();

  const checkForMegaMenu = item => {
    switch (item.primary_navigation_text) {
      case 'Products': {
        return ProductsMegaMenu(item, navigation, currentPath);
      }
      case 'Community': {
        return CommunityMegaMenu(item, navigation, currentPath);
      }
      case 'Solutions': {
        return SolutionsMegaMenu(item, navigation, currentPath);
      }
      default:
        return (
          <BulmaNavbar.Item
            css={primaryNavLink}
            url={item.primary_navigation_link && item.primary_navigation_link.url}
            key={item.primary_navigation_text}
            renderAs={LazyLink}
            activeStyle={{ borderBottom: '2px solid #0069ff', padding: '20px 12px 18px' }}
            onKeyDown={() => {
              HandleClear();
            }}
          >
            {item.primary_navigation_text}
          </BulmaNavbar.Item>
        );
    }
  };

  return primary_navigation_links.map(checkForMegaMenu);
};

export default PrimaryNavLinks;

PrimaryNavLinks.propTypes = {
  navigation: PropTypes.node.isRequired,
};
