/* eslint-disable camelcase */
import React from 'react';
import PropTypes from 'prop-types';

import BulmaColumns from 'react-bulma-components/lib/components/columns';
import {
  navTitle,
  smallIconContainer,
  smallIconImg,
  smallIconHeadlineContainer,
  smallIconLink,
  megaMenuColumn,
} from '../MegaMenuStyles';
import { LazyLink, LazyImage } from '../../../../../slices/atoms';

const SmallIconHeaderLinks = data =>
  data.map(item => (
    <BulmaColumns.Column css={megaMenuColumn} size={3} key={item.secondary_title}>
      <div css={smallIconContainer} className="navbar-content">
        <div css={smallIconHeadlineContainer}>
          <LazyImage css={smallIconImg} src={item.secondary_image.url} alt={`${item.secondary_title} icon`} />
          <h1 css={navTitle} className="title is-6 is-mega-menu-title">
            {item.secondary_title}
          </h1>
        </div>
        {item.secondary_link_1 ? (
          <LazyLink
            css={smallIconLink}
            className="navbar-item "
            url={item.secondary_link_1.url}
            key={item.secondary_text_1}
          >
            {item.secondary_text_1}
          </LazyLink>
        ) : null}
        {item.secondary_link_2 ? (
          <LazyLink
            css={smallIconLink}
            className="navbar-item "
            url={item.secondary_link_2.url}
            key={item.secondary_text_2}
          >
            {item.secondary_text_2}
          </LazyLink>
        ) : null}
        {item.secondary_link_3 ? (
          <LazyLink
            css={smallIconLink}
            className="navbar-item "
            url={item.secondary_link_3.url}
            key={item.secondary_text_3}
          >
            {item.secondary_text_3}
          </LazyLink>
        ) : null}
        {item.secondary_link_4 ? (
          <LazyLink
            css={smallIconLink}
            className="navbar-item "
            url={item.secondary_link_4.url}
            key={item.secondary_text_4}
          >
            {item.secondary_text_4}
          </LazyLink>
        ) : null}
        {item.secondary_link_5 ? (
          <LazyLink
            css={smallIconLink}
            className="navbar-item "
            url={item.secondary_link_5.url}
            key={item.secondary_text_5}
          >
            {item.secondary_text_5}
          </LazyLink>
        ) : null}
      </div>
    </BulmaColumns.Column>
  ));

export default SmallIconHeaderLinks;

SmallIconHeaderLinks.propTypes = {
  data: PropTypes.node.isRequired,
};
