/* eslint-disable camelcase */
import React from 'react';
import PropTypes from 'prop-types';

import BulmaNavbar from 'react-bulma-components/lib/components/navbar';
import BulmaHeading from 'react-bulma-components/lib/components/heading';
import {
  largeIconLink,
  largeIconImg,
  largeIconTitle,
  largeIconSubtitle,
  megaMenuLargeIconLinkContainer,
} from '../MegaMenuStyles';
import { LazyLink, LazyImage } from '../../../../../slices/atoms';

const LargeIconLinks = data =>
  // Mapping through the Featured Product Mega Menu data or the Community Mega Menu data
  data.map(item => {
    // Featured Product image variables
    const featuredProductImg = item.featured_product_image && item.featured_product_image.url;
    const featuredProductAlt = item.featured_product_image && item.featured_product_image.alt;
    // Community image variables
    const communityImg = item.community_image && item.community_image.url;
    const communityAlt = item.community_image && item.community_image.alt;
    // Solutions image variables
    const solutionImg = item.solutions_image && item.solutions_image.url;
    const solutionAlt = item.solutions_image && item.solutions_image.alt;

    return (
      <BulmaNavbar.Item
        css={megaMenuLargeIconLinkContainer}
        url={
          (item.solutions_link && item.solutions_link.url) ||
          (item.featured_product_link && item.featured_product_link.url) ||
          (item.community_link && item.community_link.url)
        }
        key={item.featured_product_title || item.community_title}
        renderAs={LazyLink}
      >
        <div css={largeIconLink} className="content">
          <LazyImage
            css={largeIconImg}
            src={solutionImg || featuredProductImg || communityImg}
            alt={
              solutionAlt ||
              item.solutions_title ||
              featuredProductAlt ||
              item.featured_product_title ||
              communityAlt ||
              item.community_title ||
              'Featured Product icon'
            }
          />
          <div>
            <BulmaHeading css={largeIconTitle}>
              {item.solutions_title || item.featured_product_title || item.community_title}
            </BulmaHeading>
            <span css={largeIconSubtitle}>
              {item.solutions_subtitle || item.featured_product_subtitle || item.community_subtitle}
            </span>
          </div>
        </div>
      </BulmaNavbar.Item>
    );
  });

export default LargeIconLinks;

LargeIconLinks.propTypes = {
  data: PropTypes.node.isRequired,
};
