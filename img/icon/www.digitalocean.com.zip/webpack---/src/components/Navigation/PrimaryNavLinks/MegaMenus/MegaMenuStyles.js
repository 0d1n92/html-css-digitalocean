// Styles here will override Bulma styles
import { css } from '@emotion/core';
import media, { setBreakPoints } from 'css-in-js-media';

setBreakPoints({ desktop: 1024, largeDesktop: 1710, tablet: 840 });

// SOLUTIONS MEGA MENU

export const solutionsMegaMenu = css`
  max-height: 350px;
  display: flex;
  flex-direction: column;
  flex-wrap: wrap;
  margin-top: 24px !important;
  ${media('< largeDesktop')} {
    max-height: 400px;
    margin: 0 auto;
  }
  ${media('< desktop')} {
    max-height: 500px;
    margin: 0 auto;
  }

  ${media('< tablet')} {
    max-height: 1000px;
    margin: 24px auto;
  }
`;

// PRODUCTS MEGA MENU

export const smallIconContainer = css`
  margin-left: 10px;

  ${media('< tablet')} {
    margin-bottom: 20px;
  }
`;

export const smallIconImg = css`
  margin-top: 40px;

  ${media('< desktop')} {
    margin-right: 5px;
    margin-top: -5px;
  }
`;

export const smallIconHeadlineContainer = css`
  display: flex;
  margin-top: 10px;

  > h1.is-6 {
    margin-bottom: 10px !important;
  }

  ${media('< desktop')} {
    margin-bottom: 5px;
  }
`;

export const smallIconLink = css`
  color: hsl(221, 19%, 44%);
  font-size: 14px !important;
  font-family: 'Sailec-Regular', 'Helvetica', 'san-serif' !important;
  margin-left: 15px;
  padding-bottom: 0 !important;
`;

export const megaMenuLargeIconLinkContainer = css`
  margin-top: 20px;

  ${media('< desktop')} {
    margin-left: 40px;
  }
`;

// COMMUNITY MEGA MENU

export const megaMenuListLink = css`
  color: hsl(221, 19%, 44%) !important;
  font-family: 'Sailec-Regular', 'Helvetica', 'sans-serif';
  font-size: 14px !important;
  line-height: 1.2;
  padding: 8px 0 8px 50px !important;

  ${media('< desktop')} {
    font-size: 12px;
    margin-left: 40px;
    padding: 5px 0 !important;
  }
`;

export const megaMenuArticleContainer = css`
  display: flex;
  margin: 20px 0 20px 50px !important;
  padding: 0 !important;
  white-space: normal !important;

  :first-of-type {
    margin-top: 30px !important;
  }

  :hover p {
    color: #0069ff !important;
  }

  ${media('< desktop')} {
    align-items: center;
    display: flex;

    margin-top: 0 !important;

    :first-of-type {
      margin-top: 0 !important;
    }
  }
`;

export const megaMenuArticleText = css`
  color: #5b6987 !important;
  font-family: 'Sailec-Regular', 'Helvetica', 'sans-serif';
  line-height: 1.5;
  padding-left: 20px;

  ${media('< desktop')} {
    font-size: 13px !important;
    line-height: 1.5em !important;
    max-width: 170px;
    padding-left: 10px;
  }
`;

export const megaMenuArticleImg = css`
  min-width: 70px;
  min-height: 70px;

  ${media('< desktop')} {
    min-width: 50px;
    min-height: 50px;
  }
`;

// SOLUTIONS MEGA MENU, PRODUCTS MEGA MENU, & COMMUNITY MEGA MENU

export const megaMenuColumns = css`
  flex-direction: row;
  flex-wrap: nowrap !important;
  margin: 0 auto;
  max-width: 1200px;
  min-height: 460px;

  > div {
    padding: 0 !important;

    > h1 {
      padding: 0 0 0 30px !important;
    }
  }

  ${media('< desktop')} {
    > div {
      margin-top: 10px;
    }

    a.navbar-item {
      padding: 0 20px 20px 0;
    }
  }

  ${media('< tablet')} {
    > div {
      margin-top: 30px;
    }
  }
`;

export const megaMenuBorderRight = css`
  border-right: 1px solid hsl(218, 18%, 91%);
  padding: 0 0 30px 0;
`;

export const navTitle = css`
  color: #031b4e !important;
  font-family: 'Sailec-Bold', 'Helvetica', 'san-serif';
  font-size: 10px !important;
  font-weight: 500;
  letter-spacing: 1px !important;
  margin-bottom: 20px !important;
  margin-top: 45px;
  padding-left: 30px;
  text-transform: uppercase;

  ${media('< desktop')} {
    margin-bottom: 5px;
    margin-top: 0;
    padding-left: 0px !important;
  }

  ${media('< tablet')} {
    margin-bottom: 5px !important;
  }
`;

export const largeIconLink = css`
  display: flex;
  height: 45px;

  div:hover {
    h1,
    span {
      color: #006aff !important;
    }
  }
`;

export const largeIconImg = css`
  height: 40px;
  margin-top: 2px;
  max-height: 40px !important;
  max-width: 40px;
`;

export const largeIconTitle = css`
  color: #031b4e !important;
  font-family: 'Sailec-Regular', 'Helvetica', 'sans-serif' !important;
  font-size: 16px !important;
  font-weight: bold;
  letter-spacing: 0 !important;
  margin-left: 15px;
  margin-top: 2px;
  margin-bottom: 2px !important;

  ${media('< desktop')} {
    font-size: 14px !important;
    margin-left: 5px;
  }
`;

export const largeIconSubtitle = css`
  color: hsl(221, 19%, 44%) !important;
  font-size: 16px !important;
  font-family: 'Sailec-Regular', 'Helvetica', 'san-serif' !important;
  margin-left: 15px;

  ${media('< desktop')} {
    font-size: 12px !important;
    margin-left: 5px;
  }
`;

export const megaMenuHr = css`
  background-color: hsl(218, 18%, 91%);
  height: 1px;
  margin-top: -14px;
`;

export const megaMenuDropdown = css`
  box-shadow: 0 2px 4px rgba(3, 27, 78, 0.1);
  padding-bottom: 0.8rem;
  padding-top: 0;
  margin-top: -1px;

  ${media('< desktop')} {
    box-shadow: none;
  }
`;

export const megaMenuAllLink = css`
  padding-top: 8px;
  padding-bottom: 4px;
  text-align: center;

  ${media('< desktop')} {
    display: none;
  }
`;

export const megaMenuAllLinkA = css`
  color: hsl(215, 100%, 50%) !important;
  font-family: 'Sailec-Regular', 'Helvetica', 'san-serif' !important;
  font-size: 14px !important;
  text-align: center;
`;

export const megaMenuArrow = css`
  color: hsl(218, 18%, 91%) !important;
  margin-bottom: -3px;
  max-height: 15px !important;
  max-width: 15px;
`;

export const megaMenuColumn = css`
  margin-right: 30px;
  padding: 0px;
  padding-left: 15px;

  :nth-of-type(4n),
  :nth-of-type(5n) {
    margin-top: -50px;
  }

  ${media('< desktop')} {
    margin-right: 0;

    :nth-of-type(4n),
    :nth-of-type(5n) {
      margin-top: 0px;
    }
  }
`;
