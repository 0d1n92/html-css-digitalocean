// Styles here will override Bulma styles
import { css } from '@emotion/core';
import media, { setBreakPoints } from 'css-in-js-media';

setBreakPoints({ desktop: 1024 });

// MAIN NAV

export const mainNav = css`
  box-shadow: rgba(3, 27, 78, 0.1) 0px 2px 4px;
  height: 65px;
  position: fixed;
  top: 41px;
  width: 100%;
  z-index: 20;
`;

export const mainNavContainer = css`
  color: hsl(221, 93%, 16%) !important;
  margin-left: 50px;
  margin-top: 8px;
  padding: 0px;
  z-index: 20;
`;

export const primaryNavLink = css`
  color: hsl(221, 93%, 16%) !important;
  background-color: transparent !important;
  font-family: 'Sailec-Medium', 'Helvetica', 'san-serif';
  font-size: 14px !important;
  padding: 20px 12px;

  ${media('< desktop')} {
    font-size: 18px !important;
    border-bottom: 1px solid hsl(218, 18%, 91%);
    margin-bottom: 10px;
    margin-left: 15px;
    margin-right: 15px;
    padding: 5px 0 15px 0;
  }
`;

export const primaryNavLinkBelowDesktop = css`
  ${media('>= desktop')} {
    display: none;
  }
`;

export const dropdownButton = css`
  outline: none;
`;

export const dropdownNavLink = css`
  background-color: transparent !important;
  color: hsl(221, 93%, 16%) !important;
  font-family: 'Sailec-Medium', 'Helvetica', 'san-serif';
  font-size: 14px !important;

  &.active {
    border-bottom: 2px solid rgb(0, 105, 255);
  }

  ${media('< desktop')} {
    display: none;
  }
`;
