/* eslint-disable camelcase */
import React from 'react';
import PropTypes from 'prop-types';

import BulmaNavbar from 'react-bulma-components/lib/components/navbar';
import { megaMenuListLink } from '../MegaMenuStyles';
import { LazyLink } from '../../../../../slices/atoms';

const ListLinks = data =>
  // Mapping through the Community Mega Menu data
  data.map(item => (
    <BulmaNavbar.Item
      css={megaMenuListLink}
      url={item.get_involved_link && item.get_involved_link.url}
      key={item.get_involved_text}
      renderAs={LazyLink}
    >
      {item.get_involved_text}
    </BulmaNavbar.Item>
  ));

export default ListLinks;

ListLinks.propTypes = {
  data: PropTypes.node.isRequired,
};
