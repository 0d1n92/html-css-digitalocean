// Styles here will override Bulma styles
import { css } from '@emotion/core';
import media, { setBreakPoints } from 'css-in-js-media';

setBreakPoints({ desktop: 1024 });

// MAIN NAV

export const nav = css`
  height: 65px;
  position: fixed;
  z-index: 30;
  width: 100%;
  top: 41px;
  box-shadow: rgba(3, 27, 78, 0.1) 0px 2px 4px;
  outline: none;

  ${media('< desktop')} {
    background: transparent;
    box-shadow: none;
    position: relative;
    top: 0;
  }

  .is-active {
    margin: 0;
    border-radius: 8px;
    outline: none;
  }

  .navbar-end {
    ${media('< desktop')} {
      justify-content: center;
      align-items: center;
      display: flex;
    }
  }
`;

export const navBarBrand = css`
  align-items: center;
  min-height: 100%;
  background: #fff;
  ${media('< desktop')} {
    box-shadow: 0px 2px 4px rgba(1, 14, 40, 0.05);
  }
`;

export const navBarMenu = css`
  &.is-active {
    ${media('< desktop')} {
      margin: 5px;
    }
  }
`;

export const primaryNavContainer = css`
  padding: 0;
  margin-left: 40px;
  margin-top: 4px;
  margin-bottom: -1px;
  color: 'hsl(221, 93%, 16%) !important';
  z-index: 20;

  ${media('< desktop')} {
    margin-left: 5px;
    margin-top: 5px;
  }
`;

export const burgerContainer = css`
  .navbar-burger {
    :hover {
      background: none;
    }
    span {
      height: 2px !important;
      background-color: #5b6987;
      border-radius: 100px;
      width: 20px !important;
    }
  }
  cursor: pointer;
  display: none;
  height: 3.25rem;
  position: relative;
  width: 3.25rem;
  margin-left: auto;
  right: 10px;

  ${media('< desktop')} {
    display: block;
  }
`;
