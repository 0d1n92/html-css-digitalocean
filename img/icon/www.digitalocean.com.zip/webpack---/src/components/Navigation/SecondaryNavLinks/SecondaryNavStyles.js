// Styles here will override Bulma styles
import { css } from '@emotion/core';
import media from 'css-in-js-media';

export const secondaryNavLink = css`
  border-radius: 5px;
  font-family: 'Sailec-Bold', 'Helvetica', 'san-serif';
  font-size: 14px;
  padding: 18px 16px 14px;
  margin-right: 16px;
  margin-top: 15px;

  :last-of-type {
    margin-right: 28px;
  }

  ${media('< desktop')} {
    width: 95vw;
    padding: 22px 20px 20px 20px;
    margin: 20px 5vw;
  }
`;
