import React from 'react';
import PropTypes from 'prop-types';

import { buttonLink } from './ButtonLinkStyles';
import { LazyLink } from '../../../../slices/atoms';

const ButtonLink = ({ linkTo, children, className }) => (
  <LazyLink css={buttonLink} className={className} url={linkTo}>
    {children}
  </LazyLink>
);

export default ButtonLink;

ButtonLink.propTypes = {
  linkTo: PropTypes.string.isRequired,
  className: PropTypes.string.isRequired,
  children: PropTypes.node.isRequired,
};
