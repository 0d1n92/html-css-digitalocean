// Styles here will override Bulma styles
import { css } from '@emotion/core';

export const buttonLink = css`
  :hover {
    background: hsl(215, 100%, 50%) !important;
    color: hsl(0, 0%, 100%) !important;
  }
  transition: background-color 0.25s linear, border-color 0.25s linear, color 0.25s linear;
`;
