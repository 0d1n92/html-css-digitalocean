/* eslint-disable camelcase */
import React from 'react';

import BulmaButton from 'react-bulma-components/lib/components/button';
import { secondaryNavLink } from './SecondaryNavStyles';

import ButtonLink from './ButtonLink';

const SecondaryNavLinks = navigation => {
  const { primary_navigation_end_links } = navigation;

  return primary_navigation_end_links.map((item, i) => (
    <BulmaButton
      css={secondaryNavLink}
      renderAs={ButtonLink}
      linkTo={item.primary_navigation_end_link && item.primary_navigation_end_link.url}
      color="primary"
      outlined={primary_navigation_end_links.length !== i + 1}
      key={item.primary_navigation_end_link_text}
    >
      {item.primary_navigation_end_link_text}
    </BulmaButton>
  ));
};

export default SecondaryNavLinks;
