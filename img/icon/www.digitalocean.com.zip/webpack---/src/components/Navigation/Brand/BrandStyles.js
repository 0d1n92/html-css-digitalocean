// Styles here will override Bulma styles
import { css } from '@emotion/core';
import media from 'css-in-js-media';

// BRAND LOGO STYLES

export const logo = css`
  padding-left: 30px;
  padding-top: 7px;
  z-index: 20;

  div {
    width: 100%;
    height: 30px;
  }

  ${media('< desktop')} {
    padding-left: 20px;
    padding-top: 15px;
  }
`;

export const logoImg = css`
  height: 29px;
  max-height: 29px;
  width: 172px;

  ${media('< desktop')} {
    margin-top: 5px;
    margin-bottom: 10px;
  }
`;
