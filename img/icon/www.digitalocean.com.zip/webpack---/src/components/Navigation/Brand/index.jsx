/* eslint-disable camelcase */
/* eslint-disable array-callback-return */
import React from 'react';

import BulmaNavbar from 'react-bulma-components/lib/components/navbar';
import { logo, logoImg } from './BrandStyles';
import { LazyLink } from '../../../slices/atoms';

const Brand = navigation => {
  const { navigation_image } = navigation;

  return (
    <BulmaNavbar.Item renderAs={LazyLink} css={logo} url="https://www.digitalocean.com">
      <img css={logoImg} src={navigation_image.url} alt="DigitalOcean logo" />
    </BulmaNavbar.Item>
  );
};

export default Brand;
