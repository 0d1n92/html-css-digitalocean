// Styles here will override Bulma styles
import { css } from '@emotion/core';
import media from 'css-in-js-media';

export const styledCardsSection = css`
  background-repeat: repeat;
  background-size: auto;
`;

export const styledCardsContainer = css`
  max-width: 870px;

  h2 {
    color: #031b4e;
    font-size: 44px;
    text-align: center;
  }

  ${media('< desktop')} {
    h2,
    p {
      margin-left: 20px;
      margin-right: 20px;
      text-align: center;
    }
  }
`;

export const styledHeading = css`
  margin: 0 auto;
  text-align: center;
`;

export const styledSubtitle = css`
  margin: 20px auto 80px auto !important;
  max-width: 670px;
  text-align: center;
`;

export const styledParentTile = css`
  flex-wrap: wrap;
  justify-content: space-between;
  max-width: 870px;
  margin-top: 32px;

  ${media('< desktop')} {
    flex-direction: column;
    margin-left: 0px;
    margin-right: 0px;
  }

  .tile {
    flex-grow: 0;
    padding: 0;
    margin-bottom: 30px;
  }
`;

export const styledCardBox = css`
  background: #fff;
  border: 1px solid #e5e8ed;
  border-radius: 0;
  box-shadow: 0px 2px 4px rgba(1, 14, 40, 0.05);
  box-sizing: border-box;
  height: 290px;
  padding: 30px;
  width: 270px;
  cursor: pointer;
  transition: all 0.5s ease;

  :hover {
    box-shadow: 0px 10px 20px rgba(1, 14, 40, 0.05);
    transform: scale(1.01);
  }

  ${media('<= desktop')} {
    width: 100%;
  }

  :hover ul {
    visibility: visible;
    opacity: 1;
    cursor: pointer;
  }
`;

export const styledLinksOnly = css`
  height: 235px;
  list-style: none;
  display: flex;
  text-align: center;
  align-content: center;
  justify-content: center;
  flex-direction: column;

  li {
    padding: 10px;

    :hover {
      background: #f2f8ff !important;
      border-radius: 20px;
    }

    a {
      width: 100%;
      font-weight: 600;
      color: #0069ff;
    }
  }
`;

export const styledCardContent = css`
  position: relative;
  height: 100%;

  ${media('<= desktop')} {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
  }

  p {
    color: #031b4e;
    font-size: 16px;
    line-height: 26px;
  }
`;

export const styledIcon = css`
  margin-bottom: 20px;
`;

export const styledLinks = css`
  visibility: hidden;
  opacity: 0;
  position: relative;
  top: -230px;
  background: #fff;
  height: 240px;
  list-style: none;
  display: flex;
  text-align: center;
  align-content: center;
  justify-content: center;
  flex-direction: column;
  transition: all 0.5s ease;

  li {
    display: flex;
    text-align: center;
    align-content: center;
    justify-content: center;
    margin: 8px 0;

    a {
      padding: 12px 10px 8px 10px;
      width: 100%;
      font-weight: 600;
      color: #0069ff;
      :hover {
        background: #f2f8ff !important;
        border-radius: 20px;
      }
    }
  }
`;
