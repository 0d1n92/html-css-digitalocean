/* eslint-disable camelcase */
import React from 'react';
import PropTypes from 'prop-types';

import BulmaBox from 'react-bulma-components/lib/components/box';
import BulmaContainer from 'react-bulma-components/lib/components/container';
import BulmaSection from 'react-bulma-components/lib/components/section';
import BulmaTile from 'react-bulma-components/lib/components/tile';

import { Heading, LazyLink, LazyImage } from '../atoms';

import {
  styledCardsSection,
  styledCardsContainer,
  styledHeading,
  styledSubtitle,
  styledParentTile,
  styledCardBox,
  styledLinksOnly,
  styledCardContent,
  styledIcon,
  styledLinks,
} from './CardsHoverLinksStyles';

const renderLink = (data, text) =>
  data && data.url ? (
    <li key={data.text}>
      <LazyLink url={data.url}>{text}</LazyLink>
    </li>
  ) : null;

const renderCard = card => {
  const {
    card_icon,
    card_title,
    card_text,
    link_1_text,
    link_1,
    link_2_text,
    link_2,
    link_3_text,
    link_3,
    link_4_text,
    link_4,
    link_only_card,
  } = card;

  return (
    <BulmaTile key={card_title ? card_title[0].text : null} kind="parent">
      <BulmaBox css={styledCardBox}>
        {link_only_card === 'true' ? null : (
          <div css={styledCardContent}>
            <LazyImage src={card_icon.url} alt={card_icon.alt || 'card icon'} css={styledIcon} />
            <Heading className="h5 darkblue" renderAs="h5">
              {card_title[0].text}
            </Heading>
            <p>{card_text}</p>
          </div>
        )}
        <ul css={link_only_card === 'true' ? styledLinksOnly : styledLinks}>
          {renderLink(link_1, link_1_text)}
          {renderLink(link_2, link_2_text)}
          {renderLink(link_3, link_3_text)}
          {renderLink(link_4, link_4_text)}
        </ul>
      </BulmaBox>
    </BulmaTile>
  );
};

const CardsHoverLinks = ({ input }) => {
  const { title1, subtitle, background_image, background_color } = input.primary;
  return (
    <BulmaSection
      css={styledCardsSection}
      style={{
        backgroundImage: `url(${background_image && background_image.url ? background_image.url : null})`,
        backgroundColor: `${background_color}`,
      }}
      id="testCardsHoverLinksSection"
    >
      <BulmaContainer css={styledCardsContainer}>
        <Heading css={styledHeading} className="h2 darkblue" renderAs="h2">
          {title1[0].text}
        </Heading>
        <Heading css={styledSubtitle} subtitle className="medium darkgrey" renderAs="p">
          {subtitle}
        </Heading>
        <BulmaTile css={styledParentTile} id="testCardsHoverLinksCards">
          {input.fields.map(card => renderCard(card))}
        </BulmaTile>
      </BulmaContainer>
    </BulmaSection>
  );
};

export default CardsHoverLinks;

CardsHoverLinks.propTypes = {
  input: PropTypes.object.isRequired,
};
