// Styles here will override Bulma styles
import { css } from '@emotion/core';
import styled from '@emotion/styled';
import media from 'css-in-js-media';

export const styledSection = css`
  ${media('< desktop')} {
    margin-top: 60px;
  }
`;

export const styledHeading = css`
  text-align: center;

  ${media('< desktop')} {
    width: 90%;
    margin: 0 auto 20px auto;
  }
`;

export const styledColumns = css`
  max-width: 1200px;
  margin: auto;
  ${media('< desktop')} {
    margin: 0 auto;
    flex-direction: column;
    align-items: center;
  }
`;

export const styledColumn = css`
  display: flex;
  align-items: center;
  text-align: left;

  ${media('< desktop')} {
    margin: 0 auto;
    flex-direction: column;
    align-items: center;
  }
`;

export const styledHeadingColumn = css`
  display: flex;
  text-align: left;
  flex-direction: column;
  align-items: center;
  margin-right: 20px;

  ${media('< desktop')} {
    text-align: center;
    margin-bottom: 20px;
  }
`;

export const StyledSideBar = styled.div`
  .subtitle {
    text-align: left;
  }

  .title {
    line-height: 135%;
    max-width: 340px;
    margin-top: 10px;
    margin-bottom: 32px !important;
  }

  ${media('< desktop')} {
    .subtitle {
      text-align: center;
    }
  }
`;

export const StyledItemsList = styled.ul`
  list-style: none;
`;

export const StyledItem = styled.li`
  display: flex;
  align-items: flex-start;
  min-height: 160px;
  margin-top: 40px;
  border-bottom: 1px solid rgb(229, 232, 237);

  &:first-of-type {
    margin-top: 18px;
  }

  &:last-of-type {
    border-bottom: none;
  }

  figure {
    align-self: flex-start;
    margin-top: 0px;
    margin-left: 0px;
    margin-right: 15px;
  }

  .image img {
    width: auto;
    height: 100%;
  }

  ${media('< desktop')} {
    flex-direction: column;
    text-align: center;

    figure {
      margin-left: auto;
      margin-right: auto;
    }
  }
`;

export const StyledItemContent = styled.div`
  display: flex;
  flex-direction: column;
  margin-left: 5px;

  .title {
    text-align: left;
    margin: 0;
  }

  ${media('< desktop')} {
    .title {
      text-align: center;
      margin: 0;
    }

    p {
      width: 80%;
      margin: 15px auto;
    }
  }
`;

export const styledTitle = css`
  text-align: left;

  ${media('< desktop')} {
    text-align: center;
    margin-top: 10px;
  }
`;

export const StyledText = styled.div`
  ${media('< desktop')} {
    text-align: center;
  }

  a {
    color: #0069ff;
    font-family: 'Sailec-Regular', 'Helvetica', 'sans-serif';
    font-style: normal;

    :hover {
      color: #1633ff !important;
    }
  }
`;

export const StyledRichText = styled.div`
  p {
    color: ${props => (props.color ? props.color : props.defaultColor)};
  }
`;
