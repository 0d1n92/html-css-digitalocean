/* eslint-disable camelcase */
import React from 'react';
import PropTypes from 'prop-types';
import { RichText } from 'prismic-reactjs';

import BulmaContainer from 'react-bulma-components/lib/components/container';
import BulmaSection from 'react-bulma-components/lib/components/section';
import BulmaColumns from 'react-bulma-components/lib/components/columns';

import { linkResolver } from '../../util/linkResolver';

import { createRandomId } from '../../util/createRandomId';
import { Heading, Button, LazyLink, LazyImage } from '../atoms';

import {
  styledSection,
  styledHeading,
  styledHeadingColumn,
  styledColumns,
  StyledSideBar,
  StyledItemsList,
  StyledItem,
  StyledItemContent,
  StyledRichText,
} from './FeaturesListStyles';

const renderHeading = (text, atts) => (
  <Heading {...atts} css={atts && atts.css ? (styledHeading, atts.css) : null}>
    {text.text}
  </Heading>
);

const renderList = (item, itemTitleColor, itemTextColor, defaultTextColor) => {
  const { item_icon, item_title, item_text } = item;

  return (
    <StyledItem key={createRandomId()}>
      {item_icon && item_icon.url && <LazyImage data-testid="item_icon" src={item_icon.url} size={24} bulma />}
      <StyledItemContent>
        {renderHeading(item_title[0], {
          style: itemTitleColor ? { color: itemTitleColor } : null,
          className: defaultTextColor === 'light' ? 'h4 white light' : 'h4 darkblue light',
          'data-testid': 'item_title',
        })}
        <StyledRichText
          color={itemTextColor || null}
          defaultColor={defaultTextColor === 'light' ? '#fff' : '#5b6987'}
          data-testid="item_text"
        >
          <RichText render={item_text} linkResolver={linkResolver} />
        </StyledRichText>
      </StyledItemContent>
    </StyledItem>
  );
};

const FeaturesList = ({ input }) => {
  const {
    text_color,
    heading,
    heading_color,
    subheading,
    subheading_color,
    background_image,
    background_color,
    item_title_color,
    item_text_color,
    cta_button_text,
    cta_button_url,
  } = input.primary;

  return (
    <BulmaSection
      css={styledSection}
      style={{
        backgroundImage: `url(${(background_image && background_image.url) || null})`,
        backgroundColor: `${background_color || '#fff'}`,
      }}
    >
      <BulmaContainer>
        <BulmaColumns css={styledColumns}>
          {((heading && heading[0].text) || (subheading && subheading[0].text)) && (
            <BulmaColumns.Column css={styledHeadingColumn} size={4}>
              <StyledSideBar data-testid="sidebar">
                {heading &&
                  heading[0].text &&
                  renderHeading(heading[0], {
                    style: { color: heading_color || null },
                    className: text_color === 'light' ? 'h2 white' : 'h2 darkblue',
                    renderAs: 'h2',
                    'data-testid': 'sidebar_heading',
                  })}
                {subheading &&
                  subheading[0].text &&
                  renderHeading(subheading[0], {
                    style: { color: subheading_color || null },
                    className: text_color === 'light' ? 'medium white' : 'medium darkgrey',
                    subtitle: true,
                    renderAs: 'p',
                    'data-testid': 'sidebar_subheading',
                  })}
                {cta_button_text && (
                  <Button color="primary" url={cta_button_url.url} renderAs={LazyLink}>
                    {cta_button_text}
                  </Button>
                )}
              </StyledSideBar>
            </BulmaColumns.Column>
          )}
          <BulmaColumns.Column>
            <StyledItemsList data-testid="FeatureList">
              {input.fields.map(item => renderList(item, item_title_color, item_text_color, text_color))}
            </StyledItemsList>
          </BulmaColumns.Column>
        </BulmaColumns>
      </BulmaContainer>
    </BulmaSection>
  );
};

export default FeaturesList;

FeaturesList.propTypes = {
  input: PropTypes.object.isRequired,
};
