/* eslint-disable camelcase */
import React from 'react';
import PropTypes from 'prop-types';

import BulmaContainer from 'react-bulma-components/lib/components/container';
import BulmaSection from 'react-bulma-components/lib/components/section';

import { css } from '@emotion/core';

import { Heading, TabsContainer, Tab } from '../atoms';

import { styledSubheading, styledHeadingContainer } from './TabbedContentStyles';

const renderHeading = (text, atts) => <Heading {...atts}>{text.text}</Heading>;

const TabbedContent = ({ input }) => {
  const {
    heading,
    subheading,
    background_image,
    background_color,
    text_color,
    heading_color,
    subheading_color,
  } = input.primary;

  return (
    <BulmaSection
      css={css`
        background-image: url(${background_image ? background_image.url : ''});
        background-color: ${background_color};
      `}
    >
      <BulmaContainer css={styledHeadingContainer}>
        {heading && heading[0]
          ? renderHeading(heading[0], {
              renderAs: 'h2',
              className: `${text_color === 'light' && !heading_color ? 'h2 white' : 'h2 darkblue'}`,
              style: { color: heading_color },
            })
          : null}
        {subheading && subheading[0]
          ? renderHeading(subheading[0], {
              renderAs: 'p',
              className: `${text_color === 'light' && !subheading_color ? 'white medium' : 'darkgrey medium'}`,
              style: { color: subheading_color },
              subtitle: true,
              css: styledSubheading,
            })
          : null}
      </BulmaContainer>

      <TabsContainer text_color={text_color}>
        {input.fields.map(item => (
          <Tab
            key={`tabbed-content-${item.tab_label[0].text}`}
            label={item.tab_label[0].text}
            content={[item.content1, item.content2, item.content3, item.content4]}
            label_color={item.label_color}
            content_color={item.content_color}
          />
        ))}
      </TabsContainer>
    </BulmaSection>
  );
};

export default TabbedContent;

TabbedContent.propTypes = {
  input: PropTypes.object.isRequired,
};
