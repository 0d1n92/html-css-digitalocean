import { css } from '@emotion/core';

export const styledSubheading = css`
  max-width: 1150px;
  margin: 0 auto;
`;

export const styledHeadingContainer = css`
  text-align: center;
  margin: 0 auto 70px auto;
`;
