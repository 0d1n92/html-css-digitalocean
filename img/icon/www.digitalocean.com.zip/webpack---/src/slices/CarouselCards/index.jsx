/* eslint-disable camelcase */
import React from 'react';
import PropTypes from 'prop-types';
import Media from 'react-media';
import { RichText } from 'prismic-reactjs';

import BulmaBox from 'react-bulma-components/lib/components/box';
import BulmaContainer from 'react-bulma-components/lib/components/container';
import BulmaSection from 'react-bulma-components/lib/components/section';

import { linkResolver } from '../../util/linkResolver';

import { Heading, Button, Carousel, LazyLink, LazyImage } from '../atoms';

import {
  styledCardsSection,
  styledCardsContainer,
  styledHeading,
  styledSubtitle,
  styledCards,
  styledCardBox,
  styledCardContent,
  StyledCardText,
  styledButton,
} from './CarouselCardsStyles';
import { createRandomId } from '../../util/createRandomId';

const renderCardText = (text, text_color) =>
  text_color ? (
    <StyledCardText>
      <RichText render={text} linkResolver={linkResolver} />
    </StyledCardText>
  ) : (
    <RichText render={text} linkResolver={linkResolver} />
  );

const renderCard = card => {
  const { image, title1, title_color, text, text_color } = card;

  return (
    <BulmaBox css={styledCardBox} renderAs="div" key={createRandomId()}>
      <div css={styledCardContent}>
        {image && image.url ? <LazyImage src={image.url} alt={image.alt || 'icon'} /> : null}
        {title1 && title1[0] ? (
          <Heading style={title_color ? { color: title_color } : null} className="h5 darkblue" renderAs="h5">
            {title1[0].text}
          </Heading>
        ) : null}
        {text && text[0] ? renderCardText(text, text_color) : null}
      </div>
    </BulmaBox>
  );
};

const renderCardContent = (fields, cardsPerPage, content_alignment, subheading) => {
  const amountOfPages = Math.ceil(fields.length / cardsPerPage);

  const cardContent = [];

  for (let i = 0; i < amountOfPages; i += 1) {
    const cards = [];
    for (let j = 0; j < cardsPerPage; j += 1) {
      if (i * cardsPerPage + j < fields.length) {
        cards.push(fields[i * cardsPerPage + j]);
      }
    }
    cardContent.push(
      <div
        id="testCards"
        css={styledCards}
        style={{
          gridTemplateColumns: `repeat(${cardsPerPage}, ${
            cardsPerPage === 4 ? 'minmax(206px, 1fr)' : 'minmax(220px, 1fr)'
          })`,
          textAlign: `${content_alignment === 'center' ? 'center' : 'left'}`,
          marginTop: `${!subheading ? '64px' : '0'}`,
        }}
        key={createRandomId()}
      >
        {cards.map(card => renderCard(card))}
      </div>,
    );
  }
  return cardContent;
};

const renderCards = (matches, fields, content_alignment, subheading, text_color) => {
  if (matches.small) {
    return (
      <Carousel id="testCarouselCards" selectColor={text_color === 'light' ? '#fff' : '#1633ff'} key={createRandomId()}>
        {renderCardContent(fields, 1, content_alignment, subheading)}
      </Carousel>
    );
  }
  if (matches.medium) {
    return (
      <Carousel id="testCarouselCards" selectColor={text_color === 'light' ? '#fff' : '#1633ff'} key={createRandomId()}>
        {renderCardContent(fields, 3, content_alignment, subheading)}
      </Carousel>
    );
  }
  return (
    <Carousel id="testCarouselCards" selectColor={text_color === 'light' ? '#fff' : '#1633ff'} key={createRandomId()}>
      {renderCardContent(fields, 4, content_alignment, subheading)}
    </Carousel>
  );
};

const CarouselCards = ({ input }) => {
  const {
    text_color,
    heading,
    heading_color,
    subheading,
    subheading_color,
    background_image,
    background_color,
    content_alignment,
    cta_button_text,
    cta_button_link,
  } = input.primary;
  const { fields } = input;

  const isMobile = global.window ? window.matchMedia('(max-width: 1024px').matches : false;

  return (
    <BulmaSection
      id="testCarouselCardsSection"
      css={styledCardsSection}
      style={
        background_image && background_image.url
          ? { backgroundImage: `url(${background_image.url})` }
          : { backgroundColor: `${background_color || '#f3f5f9'}` }
      }
    >
      <BulmaContainer css={styledCardsContainer}>
        {heading && heading[0].text ? (
          <Heading
            style={heading_color ? { color: heading_color } : null}
            css={styledHeading}
            className={text_color === 'light' ? 'h2 white' : 'h2 darkblue'}
            renderAs="h2"
          >
            {heading[0].text}
          </Heading>
        ) : null}
        {subheading && subheading[0].text ? (
          <Heading
            style={subheading_color ? { color: subheading_color } : null}
            css={styledSubtitle}
            subtitle
            className={text_color === 'light' ? 'medium white' : 'medium darkgrey'}
            renderAs="p"
          >
            {subheading[0].text}
          </Heading>
        ) : null}

        <Media
          queries={{
            small: '(max-width: 1024px) and (max-width: 760px)',
            medium: '(min-width: 1024px) and (max-width: 1396px)',
            large: '(min-width: 1396px)',
          }}
          defaultMatches={{ large: !isMobile }}
        >
          {matches => renderCards(matches, fields, content_alignment, subheading, text_color)}
        </Media>

        {cta_button_link && cta_button_link.url ? (
          <Button
            css={styledButton}
            color={text_color === 'light' ? 'white' : 'primary'}
            outlined
            renderAs={LazyLink}
            url={cta_button_link.url}
          >
            {cta_button_text}
          </Button>
        ) : null}
      </BulmaContainer>
    </BulmaSection>
  );
};

export default CarouselCards;

CarouselCards.propTypes = {
  input: PropTypes.object.isRequired,
};
