/* eslint-disable camelcase */
import React, { useState, useEffect, useRef } from 'react';
import PropTypes from 'prop-types';

import BulmaSection from 'react-bulma-components/lib/components/section';
import BulmaContainer from 'react-bulma-components/lib/components/container';

import { css } from '@emotion/core';

import { Carousel, Heading } from '../atoms';

import {
  styledArrowsContainer,
  styledHeading,
  styledSubHeading,
  styledCustomerStoryCarouselSection,
  StyledSingleQuote,
  StyledCustomerStoryCarousel,
  StyledCustomerStoryContent,
  StyledCustomerImageContainer,
} from './CustomerStoryCarouselStyles';

const renderContent = fields =>
  fields.map(field => (
    <StyledCustomerImageContainer>
      <img alt="customer-story" src={field.customer_story_image && field.customer_story_image.url} />
    </StyledCustomerImageContainer>
  ));

const CustomerStoryCarousel = ({ input }) => {
  const { background_color, background_image, text_color, heading, heading_color, subheading1 } = input.primary;

  const ref = useRef(null);
  const [selected, setSelected] = useState(0);

  const externalSetSelected = value => {
    setSelected(value);
  };

  const handleClick = direction => {
    if (direction === 'right') ref.current.changeSelected(ref.current.selected + 1);
    if (direction === 'left') ref.current.changeSelected(ref.current.selected - 1);
  };

  return (
    <BulmaSection
      css={css`
        ${styledCustomerStoryCarouselSection}
        ${background_image ? `background-image: url(${background_image.url});` : null};
        background-color: ${background_color};
      `}
    >
      <BulmaContainer>
        <StyledCustomerStoryCarousel backgroundColor={background_color}>
          <StyledCustomerStoryContent>
            {heading && heading[0].text && (
              <Heading
                renderAs="h2"
                className={text_color === 'light' ? 'h2 white' : 'h2 darkblue'}
                css={css`
            ${styledHeading}
              color: ${heading_color} !important;
            `}
              >
                {heading[0].text}
              </Heading>
            )}
            {subheading1 && subheading1[0].text && (
              <Heading
                className={text_color === 'light' ? 'large grey subtitle' : 'large darkblue subtitle'}
                css={styledSubHeading}
              >
                {subheading1}
              </Heading>
            )}
            <div css={styledArrowsContainer}>
              <button
                type="button"
                onClick={() => {
                  handleClick('left');
                  if (selected > 0) return setSelected(selected - 1);
                }}
              >
                <svg
                  className={selected <= 0 ? 'grey left selected' : 'left selected'}
                  width="38"
                  height="10"
                  viewBox="0 0 45 10"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M43.75 4.75H1.25"
                    stroke="#0069FF"
                    strokeWidth="1.5"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                  <path
                    d="M40 8.5L43.75 4.75L40 1"
                    stroke="#0069FF"
                    strokeWidth="1.5"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
              </button>

              <button
                type="button"
                onClick={() => {
                  handleClick('right');
                  if (selected < input.fields.length - 1) return setSelected(selected + 1);
                }}
              >
                <svg
                  className={selected !== input.fields.length - 1 ? 'right selected' : 'grey right selected'}
                  width="45"
                  height="10"
                  viewBox="0 0 45 10"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    d="M43.75 4.75H1.25"
                    stroke="#0069FF"
                    strokeWidth="1.5"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                  <path
                    d="M40 8.5L43.75 4.75L40 1"
                    stroke="#0069FF"
                    strokeWidth="1.5"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                </svg>
              </button>
            </div>
          </StyledCustomerStoryContent>
          {input.fields.length > 1 ? (
            <Carousel
              externalSetSelected={externalSetSelected}
              ref={ref}
              hideArrows
              customerStory
              fadeIn
              text_color={text_color}
              selectColor={text_color === 'light' ? '#fff' : '#0069ff'}
              id="customer-story-carousel"
              type="testimonial"
              fields={input.fields}
            >
              {renderContent(input.fields, text_color)}
            </Carousel>
          ) : (
            <StyledSingleQuote>{renderContent(input.fields, text_color)}</StyledSingleQuote>
          )}
        </StyledCustomerStoryCarousel>
      </BulmaContainer>
    </BulmaSection>
  );
};

export default CustomerStoryCarousel;

CustomerStoryCarousel.propTypes = {
  input: PropTypes.object.isRequired,
};

renderContent.propTypes = {
  fields: PropTypes.array.isRequired,
};
