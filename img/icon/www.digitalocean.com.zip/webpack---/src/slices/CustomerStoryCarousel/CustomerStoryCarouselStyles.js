// Styles here will override Bulma styles
import { css } from '@emotion/core';
import styled from '@emotion/styled';
import media from 'css-in-js-media';

export const StyledCustomerStoryCarousel = styled.div`
  display: flex;
  flex-direction: row;

  .columns {
    .selected {
      background: ${props => props.backgroundColor} !important;
      box-shadow: none;
      border: none;
    }
  }

  #customer-story-carousel {
    margin-right: -175px;
    margin-top: 0px;
    max-width: 800px;
  }

  ${media('< desktop')} {
    display: flex;
    flex-direction: column;

    #customer-story-carousel {
      margin-right: auto !important;
      max-width: 100vw;
    }

    .carousel-select-container {
      display: flex;
      flex-direction: column;
    }

    .button-container {
      margin: auto;
    }

    .columns {
      .selected {
        width: 94vw !important;
      }
    }
  }

  ${media('< tablet')} {
    #customer-story-carousel {
      margin-right: auto !important;
      max-width: 80vw;
    }
  }
`;

export const styledCustomerStoryCarouselSection = css`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
`;

export const styledHeading = css`
  text-align: left;
  margin-left: 0px !important;
`;

export const styledSubHeading = css`
  text-align: left;
  margin-left: 0px !important;
  width: 92%;

  p {
    width: 90%;
    margin-top: 0;
    margin-bottom: 36px !important;
  }

  ${media('< desktop')} {
    margin: auto !important;
    text-align: center;
    width: 100%;

    p {
      width: 100%;
    }
  }
`;

export const styledQuoteContainer = css`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: flex-start;
  max-width: 770px;
  height: auto;
  margin: 64px;

  figure {
    max-width: 150px;
    height: auto;
    img {
      max-width: 150px;
      margin-bottom: 10px;
    }
  }

  p.quote {
    font-size: 24px;
  }
`;

export const styledCustomerStoryCarouselContent = css`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  text-align: center;
`;

export const StyledSingleQuote = styled.div`
  width: 870px;

  ${media('< desktop')} {
    width: 90vw;
  }

  div {
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0;
    width: 100%;
    max-width: 100%;
  }
`;

export const StyledCustomerStoryContent = styled.div`
  overflow: hidden;
  display: flex;
  justify-content: center;
  flex-direction: column;
`;

export const StyledCustomerStoryInfo = styled.div`
  position: absolute;
  width: 335px;
  height: 250px;
  background-color: white;
  max-width: 100vw;
  -webkit-animation: fade-in 1.2s cubic-bezier(0.39, 0.575, 0.565, 1) both;
  animation: fade-in 1.2s cubic-bezier(0.39, 0.575, 0.565, 1) both;
  left: 20%;
  bottom: 0;
`;

export const StyledCustomerStoryGrandparent = styled.div`
  position: relative;
`;

export const StyledCustomerStoryLeftSideContent = styled.div``;

export const StyledCustomerImageContainer = styled.div`
  img {
    max-width: 475px;
    max-height: 400px;
    margin-left: 125px;
    border-radius: 5px;
  }

  ${media('< desktop')} {
    img {
      width: auto;
      height: 280px;
      align-self: center;
      justify-self: center;
      margin-left: 60px;
    }
  }

  ${media('< tablet')} {
    img {
      margin-left: -80px;
    }
  }
`;

export const styledArrowsContainer = css`
  button {
    background: none;
    border: none;
    width: fit-content;
    padding: 0;
    outline: none;
    cursor: pointer;
  }

  display: flex;
  margin-top: 24px;

  .grey {
    opacity: 0.4 !important;
  }

  .left {
    opacity: 1;
    transform: rotate(180deg);
  }

  .right {
    opacity: 1;
    margin-left: 5px;
  }

  ${media('< desktop')} {
    justify-content: center;
    margin-bottom: 32px;
  }
`;
