// Styles here will override Bulma styles
import { css } from '@emotion/core';
import styled from '@emotion/styled';
import media from 'css-in-js-media';

export const styledSection = css`
  background-position: bottom;
  background-size: cover;
`;

export const styledHeading = css`
  text-align: center;
`;

export const styledSubheading = css`
  text-align: center;
  margin: 16px auto 64px auto !important;
`;

export const StyledContent = styled.div`
  max-width: 870px;
  margin: 0 auto;
  justify-content: center;
  text-align: ${props => (props.contentTextAlignment ? props.contentTextAlignment : 'center')};
  display: flex;
  flex-direction: column;

  a {
    font-family: 'Sailec-Regular';
  }

  h1,
  h2,
  h3,
  h4,
  h5,
  h6 {
    color: #031b4e;
  }

  h3 {
    margin: 32px 0 0 0;
  }

  a {
    font-family: 'Sailec-Regular';
    color: #0069ff;
    text-align: center;
    :hover {
      color: #1633ff !important;
    }
  }

  h4 {
    font-family: 'Sailec-Light';
    font-weight: normal;
    font-size: 24px;
    line-height: 150%;
    color: rgba(3, 27, 78, 0.7);
  }

  p {
    img {
      max-width: 100%;
      margin: 20px 0;
    }

    strong {
      font-weight: 600;
      font-family: 'Sailec-Regular';
    }

    a {
      color: hsl(215, 100%, 50%);
    }
  }

  ul,
  ol {
    color: #5b6987;
    font-family: 'Sailec-Light';
    margin-block-start: 0;
    margin-block-end: 0;
    margin-inline-start: 0px;
    margin-inline-end: 0px;
    padding-inline-start: 17px;

    li {
      font-style: normal;
      font-weight: normal;
      font-size: 16px;
      line-height: 26px;
      color: #5b6987;
    }
  }

  ${media('< desktop')} {
    align-items: center !important;
    text-align: center;
    margin: 20px;
  }
`;

export const styledVideoContainer = css`
  max-width: 870px;
  margin: 0 auto;
  margin-top: 64px;
  margin-bottom: 32px;
`;

export const styledImageContainer = css`
  margin-top: 20px;
  display: flex;
  align-items: center;
  flex-direction: column;
  p {
    margin-top: 40px !important;
    font-size: 20px;
    text-align: center;
  }
  img {
    width: 100%;
    max-width: 870px;
    margin-bottom: 16px;
  }
`;
