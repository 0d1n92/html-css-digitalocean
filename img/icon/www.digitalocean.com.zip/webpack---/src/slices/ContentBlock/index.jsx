/* eslint-disable camelcase */
import React from 'react';
import PropTypes from 'prop-types';
import { Helmet } from 'react-helmet';
import { RichText } from 'prismic-reactjs';

import BulmaContainer from 'react-bulma-components/lib/components/container';
import BulmaSection from 'react-bulma-components/lib/components/section';

import { linkResolver } from '../../util/linkResolver';
import { Heading, LazyImage } from '../atoms';
import {
  styledSection,
  styledHeading,
  styledSubheading,
  styledImageContainer,
  styledVideoContainer,
  StyledContent,
} from './ContentBlockStyles';

const renderVideo = wistiaId => (
  <>
    <Helmet>
      <script src={`https://fast.wistia.com/embed/medias/${wistiaId}.jsonp`} async />
      <script src="https://fast.wistia.com/assets/external/E-v1.js" async />
    </Helmet>
    <div css={styledVideoContainer}>
      <div
        id="testContentBlockVideo"
        className="wistia_responsive_padding"
        css={{
          padding: '56.25% 0 0 0',
          position: 'relative',
        }}
      >
        <div
          className="wistia_responsive_wrapper"
          css={{
            height: '100%',
            left: '0',
            position: 'absolute',
            top: '0',
            width: '100%',
          }}
        >
          <div
            className={`wistia_embed wistia_async_${wistiaId} videoFoam=true autoPlay=false`}
            css={{ height: '100%', position: 'relative', width: '100%' }}
          >
            <div
              className="wistia_swatch"
              css={{
                height: '100%',
                left: '0',
                opacity: '0',
                overflow: 'hidden',
                position: 'absolute',
                top: '0',
                transition: 'opacity 200ms',
                width: '100%',
              }}
            >
              <img
                src={`https://fast.wistia.com/embed/medias/${wistiaId}/swatch`}
                css={{
                  filter: 'blur(5px)',
                  height: '100%',
                  objectFit: 'contain',
                  width: '100%',
                }}
                alt="video"
                aria-hidden="true"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  </>
);

const ContentBlock = ({ input }) => {
  const {
    text_color,
    heading,
    heading_color,
    subheading,
    subheading_color,
    background_image,
    background_color,
    content,
    content_text_alignment,
    image,
    wistia_id,
    target_name,
  } = input.primary;

  return (
    <>
      <div id={target_name} />
      <BulmaSection
        id="testContentBlockSection"
        css={styledSection}
        style={{
          backgroundImage: `${background_image && background_image.url ? `url(${background_image.url})` : null}`,
          backgroundColor: background_color,
          paddingTop: `${!heading && !subheading && !wistia_id && !image ? '64px' : null}`,
          paddingBottom: `${!heading && !subheading && !wistia_id && !image ? '64px' : null}`,
        }}
      >
        <BulmaContainer>
          {heading && heading[0].text ? (
            <Heading
              style={{
                color: heading_color || null,
                marginBottom: !subheading ? '64px' : '0',
              }}
              css={styledHeading}
              className={text_color === 'light' ? 'h2 white' : 'h2 darkblue'}
              renderAs="h2"
            >
              {heading[0].text}
            </Heading>
          ) : null}
          {subheading && subheading[0].text ? (
            <Heading
              style={subheading_color ? { color: subheading_color } : null}
              css={styledSubheading}
              className={text_color === 'light' ? 'medium white subtitle' : 'medium darkgrey subtitle'}
            >
              {subheading}
            </Heading>
          ) : null}
          {wistia_id !== null && wistia_id !== undefined ? renderVideo(wistia_id) : null}
          {image && image.url ? (
            <div css={styledImageContainer}>
              <LazyImage id="testContentBlockImage" src={image.url} alt={image.alt || 'content image'} />
              {image.alt ? (
                <Heading subtitle className={text_color === 'light' ? 'medium white' : 'medium darkgrey'} renderAs="p">
                  {image.alt}
                </Heading>
              ) : null}
            </div>
          ) : null}
          {content && content[0] && content[0].text ? (
            <BulmaContainer id="testContentBlockContent">
              <StyledContent contentTextAlignment={content_text_alignment}>
                <RichText render={content} linkResolver={linkResolver} />
              </StyledContent>
            </BulmaContainer>
          ) : null}
        </BulmaContainer>
      </BulmaSection>
    </>
  );
};

export default ContentBlock;

ContentBlock.propTypes = {
  input: PropTypes.object.isRequired,
};
