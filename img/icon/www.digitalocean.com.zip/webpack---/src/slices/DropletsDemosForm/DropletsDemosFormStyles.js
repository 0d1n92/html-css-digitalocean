import { css } from '@emotion/core';
import media from 'css-in-js-media';
import styled from '@emotion/styled';

export const styledSubHeading = css`
  display: flex;
  margin: 0 auto;
  max-width: 820px;
  text-align: center;
  p {
    margin-top: 0;
    margin-bottom: 36px !important;
  }
`;

export const StyledForm = styled.form`
  .form-wrapper {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    margin-top: 36px;
    text-align: left;

    .form-item-full-width {
      margin-bottom: 16px;
      position: relative;
      text-align: center;
      width: 100%;

      &.is-required:before {
        content:"";
        background: url(https://images.prismic.io/www-static/50bfb6e8-d754-4e9f-ade8-b9a08d1ab626_asterik-blue.svg?auto=compress,format);
        background-size: 10px;
        fill:#0069ff;
        width:10px;
        height:10px;
        background-repeat:no-repeat;
        position:absolute;
        top:20px;
        right:16px;
        -webkit-transform-origin:center center;
        transform-origin:center center;
        pointer-events:none;
        z-index:2;
      }

      &.is-required.text-area:before {
        top: 35px;
      }

      &.select.is-required:after, &.select:after {
        content: "";
        position: absolute;
        top: 25px;
        -webkit-transform: translateY(-50%);
        transform: translateY(-50%);
        right: 16px;
        background: url(https://images.prismic.io/www-static/ab28bfed-9412-44c9-b247-6497457a88d4_arrow-down-gray-e67c5162.svg?auto=compress,format);
        fill: rgba(3,27,78,.75);
        width: 12px;
        height: 12px;
        background-repeat: no-repeat;
        background-size: contain;
        pointer-events: none;
        right: 40px;
        z-index: 2;
      }

      &.select:after {
        right: 15px;
      }

       input, select {
        width: 100%;
        height: 48px;
        background: #FFF;
        border: 1px solid #e5e8ed;
        box-sizing: border-box;
        border-radius: 3px;
        margin-bottom: 8px;
        font-family: 'Sailec-Regular';
        font-size: 16px;
        padding: 16px;
        color: #5b6987;
        :focus {
          border-color: #0069ff;
          outline: #0069ff;
        }
      }

      textarea {
        color: #5b6987;
        border: 1px solid #e5e8ed;
        font-family: 'Sailec-Regular';
        font-size: 16px;
        overflow: auto;
        vertical-align: top;
        resize: vertical;
        margin: 25px 0;
        min-height: 80px;
        height: auto;
        text-indent: 10px;
        width: 100%;
      }

      textarea::placeholder {
        color: #5b6987;
      }

      select::-ms-expand {
        display: none;
      }

      select {
        -webkit-appearance: none;
        -moz-appearance: none;      
        appearance: none;
        padding: 2px 30px 2px 2px;
        text-indent: 10px;
      }

      span.error-text {
        color: #ca0c0c;
        display: inline-block;
        float: left;
        font-family: 'Sailec-Regular';
        font-size: 12px;
        margin-bottom: 16px;
        text-align: left;
      }

      .react-datepicker-wrapper {
        width: 100%;
      }
    }

    .form-item-half-width.margin-right {
      margin-right: 1%;

      ${media('< tablet')} { 
        margin-right: 0;
      }
    }

    .form-item-half-width.margin-left {
      margin-left: 1%;

      ${media('< tablet')} { 
        margin-left: 0;
      }
    }

    .form-item-half-width {
      margin-bottom: 16px;
      position: relative;
      width: 49%;

      &.is-required:before {
        content:"";
        background: url(https://images.prismic.io/www-static/50bfb6e8-d754-4e9f-ade8-b9a08d1ab626_asterik-blue.svg?auto=compress,format);
        background-size: 10px;
        fill:#0069ff;
        width:10px;
        height:10px;
        background-repeat:no-repeat;
        position:absolute;
        top:20px;
        right:16px;
        -webkit-transform-origin:center center;
        transform-origin:center center;
        pointer-events:none;
        z-index:2;
      }

      &.select.is-required:after, &.select:after {
        content: "";
        position: absolute;
        top: 25px;
        -webkit-transform: translateY(-50%);
        transform: translateY(-50%);
        right: 16px;
        background: url(https://images.prismic.io/www-static/ab28bfed-9412-44c9-b247-6497457a88d4_arrow-down-gray-e67c5162.svg?auto=compress,format);
        fill: rgba(3,27,78,.75);
        width: 12px;
        height: 12px;
        background-repeat: no-repeat;
        background-size: contain;
        pointer-events: none;
        right: 40px;
        z-index: 2;
      }

      &.select:after {
        right: 15px;
      }

       input, select {
        width: 100%;
        height: 48px;
        background: #FFF;
        border: 1px solid #e5e8ed;
        box-sizing: border-box;
        border-radius: 3px;
        margin-bottom: 8px;
        font-family: 'Sailec-Regular';
        font-size: 16px;
        padding: 16px;
        color: #5b6987;
        :focus {
          border-color: #0069ff;
          outline: #0069ff;
        }
      }

      select::-ms-expand {
        display: none;
      }

      select {
        -webkit-appearance: none;
        -moz-appearance: none;      
        appearance: none;
        padding: 2px 30px 2px 2px;
        text-indent: 10px;
      }

      input[type="text"]::-webkit-input-placeholder { 
        color: #5b6987;
      }

      input[type="text"]::-moz-placeholder {
        color: #5b6987;
        opacity:  1;
      }

      input[type="text"]:-ms-input-placeholder { 
        color: #5b6987;
      }

      input[type="text"]::-ms-input-placeholder { 
        color: #5b6987;
      }

      input[type="text"]::placeholder {
        color: #5b6987;
      }

      input.error-border, select.error-border {
        border: solid 1px #ca0c0c;
      }
      input[type='submit'] {
        background: #0069ff;
        border: none;
        line-height: 100%;
        font-family: 'Sailec-Bold';
        color: #fff;
        padding: 17px;
        cursor: pointer;
        margin-bottom: 0;
      }
      span.error-text {
        color: #ca0c0c;
        display: inline-block;
        font-family: 'Sailec-Regular';
        font-size: 12px;
        margin-bottom: 16px;
        text-align: left;
      }

      ${media('< tablet')} { 
        width: 100%;
        margin-right: 0;
        margin-left: 0;
      }
    }
  }
  .hide-error {
    display: none;
  }
  .show-error {
    display: block;
  }

  .terms-of-service {
    font-size: 14px;
    text-align: center;

    a {
      color: #0069ff;
      text-decoration:underline;
    }
  }
`;

export const styledFormReady = css`
  display: inline-block;

  &.is-none {
    display: none;
  }

  .error-text {
    display: none;
    color: #ca0c0c;
    font-family: 'Sailec-Regular';
    font-size: 16px;
    margin-bottom: 16px;
    text-align: center;
  }

  .error-text.show {
    display: block;
  }
`;

export const StyledThankYouWrapper = styled.div`
  display: flex;
  flex-wrap: wrap;
  justify-content: center;

  a {
    border: 1px solid #0069ff;
    border-radius: 5px;
    color: #0069ff;
    cursor: pointer;
    display: inline-block;
    font-family: 'Sailec-Regular';
    font-size: 16px;
    font-weight: 400;
    height: 48px;
    line-height: 48px;
    padding: 0 32px;
    text-align: center;
    text-decoration: none;
    -webkit-transition: background-color .25s ease,border .25s ease,color .25s ease;
    transition: background-color .25s ease,border .25s ease,color .25s ease;
    vertical-align: middle;
    white-space: nowrap;
    margin: 0 20px;
  }

  a:hover {
    background-color: rgba(0,105,255,.1) !important;
  }

  p {
    color: #031b4e;
    font-family: 'Sailec-Light';
    font-size: 20px;
    line-height: 150%;
  }

  &.is-none {
    display: none;
  }

  &.is-block {
    display: block;
    text-align: center;
  }
`;

export const StyledFaq = styled.div`
  display: flex;
  flex-wrap: wrap;
  justify-content: center;
  margin-top: 80px;

  h2 {
    text-align: center;
    width: 100%;
  }

  span {
    display: inline-block;
    text-align: left;
    width: 100%;
  }
`;

export const styledCardContent = css`
  position: relative;
  height: 100%;

  .title {
    margin-top: 15px;
  }

  img {
    max-width: 120px;
    margin-bottom: 10px;
  }

  ${media('<= desktop')} {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
  }
`;
