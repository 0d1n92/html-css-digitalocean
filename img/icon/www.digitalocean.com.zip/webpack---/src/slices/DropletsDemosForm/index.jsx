/* eslint-disable camelcase */
import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { useForm } from 'react-hook-form';
import DatePicker from 'react-datepicker';

import BulmaContainer from 'react-bulma-components/lib/components/container';
import BulmaSection from 'react-bulma-components/lib/components/section';

import { Heading } from '../atoms';
import 'react-datepicker/dist/react-datepicker.css';

import {
  StyledFaq,
  StyledForm,
  styledSubHeading,
  styledFormReady,
  StyledThankYouWrapper,
} from './DropletsDemosFormStyles';

const renderHeading = (text, atts) => <Heading {...atts}>{text.text}</Heading>;

const DropletsDemosForm = ({ input }) => {
  const {
    approved_talk_description_placeholder,
    approved_talk_title_placeholder,
    audience_level_placeholder,
    company_placeholder,
    email_placeholder,
    event_attendance_placeholder,
    event_city_placeholder,
    event_country_placeholder,
    event_name_placeholder,
    first_name_placeholder,
    github_placeholder,
    last_name_placeholder,
    twitter_handle_placeholder,
    website_placeholder,
    faq_answer_1,
    faq_answer_2,
    faq_answer_3,
    faq_answer_4,
    faq_header,
    faq_question_1,
    faq_question_2,
    faq_question_3,
    faq_question_4,
    subheading,
  } = input.primary;

  const [validEmailClass, setValidEmailClass] = useState('hide-error');
  const [validGithubClass, setValidGithubClass] = useState('hide-error');
  const [salesFormShow, setSalesFormClass] = useState('form-ready');
  const [salesFormThankYouShow, setSalesFormThankYouClass] = useState('is-none');
  const [salesFormResponseError, setFormResponseError] = useState('error-text');
  const [currentDate, setCurrentDate] = useState(new Date());
  const [eventDateValue, setEventDateValue] = useState('');

  const formArray = [
    {
      post_name: 'FirstName',
      field_name: 'first_name',
    },
    {
      post_name: 'LastName',
      field_name: 'last_name',
    },
    {
      post_name: 'Email',
      field_name: 'email',
    },
    {
      post_name: 'Website',
      field_name: 'website',
    },
    {
      post_name: 'Compnay',
      field_name: 'company',
    },
    {
      post_name: 'twitterhandle',
      field_name: 'twitter',
    },
    {
      post_name: 'github',
      field_name: 'github',
    },
    {
      post_name: 'dfdeventname',
      field_name: 'event_name',
    },
    {
      post_name: 'dfdeventcity',
      field_name: 'event_city',
    },
    {
      post_name: 'dfdeventcountry',
      field_name: 'event_country',
    },
    {
      post_name: 'dfdeventdate',
      field_name: 'event_date',
    },
    {
      post_name: 'dfdeventattendance',
      field_name: 'event_attendance',
    },
    {
      post_name: 'dfdapprovedtalktitle',
      field_name: 'approved_talk_title',
    },
    {
      post_name: 'dfdapprovedtalkdescription',
      field_name: 'approved_talk_description',
    },
    {
      post_name: 'dfdaudiencelevel',
      field_name: 'audience_level',
    },
  ];

  const { register, handleSubmit, errors } = useForm();
  const onSubmit = data => {
    const createParams = formArray
      .map(form => `&${form.post_name}=${data[form.field_name]}`)
      .reduce((acc, val) => acc + val);

    const mktoRefer = `&_mktoReferrer=${encodeURI(window.location.href)}`;
    const staticParams = '&formid=1069&formVid=1069&munchkinId=937-EID-756';
    const concatAllValues = createParams.concat(mktoRefer).concat(staticParams);

    fetch('https://go.digitalocean.com/index.php/leadCapture/save2', {
      method: 'POST',
      mode: 'cors',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: concatAllValues,
    })
      .then(response => {
        if (response.status === 200) {
          setSalesFormClass('form-ready is-none');
          setSalesFormThankYouClass('is-block');
        } else {
          setFormResponseError('error-text show');
        }
      })
      .catch(error => {
        console.error('Error:', error);
      });
  };

  const onChange = event => {
    if (event.target.name === 'email') {
      const checkEmailFormat = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(event.target.value);

      !checkEmailFormat ? setValidEmailClass('show-error error-text') : setValidEmailClass('hide-error');
    }

    if (event.target.name === 'github') {
      const checkGithubUidFormat = /^[a-z0-9]+$/.test(event.target.value);

      !checkGithubUidFormat ? setValidGithubClass('show-error error-text') : setValidGithubClass('hide-error');
    }
  };

  const changeDateSelect = date => {
    setCurrentDate(date);

    const d = new Date(date);
    let month = `${d.getMonth() + 1}`;
    let day = `${d.getDate()}`;
    const year = d.getFullYear();

    if (month.length < 2) month = `0 + ${month}`;
    if (day.length < 2) day = `0 + ${day}`;

    const formatDate = [year, month, day].join('-');

    setEventDateValue(formatDate);
  };

  return (
    <BulmaSection>
      <BulmaContainer>
        <StyledThankYouWrapper className={salesFormThankYouShow}>
          <h3>Thank you for applying!</h3>
          <p>Our team will review and follow back up shortly with next steps.</p>
          <p>In the meantime, share Droplets for Demos with your friends!</p>
          <a href="https://twitter.com/intent/tweet?text=Power%20your%20tech%20talk%20with%20infrastructure%20credits%20from%20%40DigitalOcean%20http%3A%2F%2Fdo.co%2Fspeak%20%23dropletsfordemos">
            Share on Twitter
          </a>
          <a href="http://www.facebook.com/sharer.php?u=https%3A%2F%2Fdigitalocean.com%2Fdroplets-for-demos%2F">
            Share on Facebook
          </a>
        </StyledThankYouWrapper>

        <span className={salesFormShow} css={styledFormReady}>
          <p className="error-text">There was a problem with your form request. Please try again.</p>
          {subheading &&
            subheading[0].text &&
            renderHeading(subheading[0], {
              'data-testid': 'subheading',
              renderAs: 'p',
              className: 'medium darkblue subtitle',
              css: styledSubHeading,
              subtitle: true,
            })}
          <StyledForm className="form-align-left" onSubmit={handleSubmit(onSubmit)}>
            <span className="form-wrapper">
              <div className="form-item-full-width">
                <h2>Tell us a little bit about yourself.</h2>
                <p>
                  Don’t have a DigitalOcean email?
                  <a href="https://cloud.digitalocean.com/registrations/new">Register here</a>
                </p>
              </div>
              <div className="form-item-half-width margin-right is-required">
                <input
                  type="text"
                  name="first_name"
                  className={errors.first_name ? 'error-border' : 'error-none is-required'}
                  placeholder={first_name_placeholder}
                  ref={register({ required: true, maxLength: 20 })}
                />
                {errors.first_name && <span className="error-text">First name is a required field</span>}
              </div>
              <div className="form-item-half-width margin-left is-required">
                <input
                  type="text"
                  name="last_name"
                  className={errors.last_name ? 'error-border' : 'error-none'}
                  placeholder={last_name_placeholder}
                  ref={register({ required: true })}
                />
                {errors.last_name && <span className="error-text">Last name is a required field</span>}
              </div>
              <div className="form-item-full-width">
                <input
                  type="text"
                  name="company"
                  className={errors.company ? 'error-border' : 'error-none'}
                  placeholder={company_placeholder}
                  ref={register({ required: false })}
                />
              </div>
              <div className="form-item-half-width margin-right is-required">
                <input
                  type="text"
                  name="email"
                  className={errors.email ? 'error-border' : 'error-none'}
                  placeholder={email_placeholder}
                  onChange={onChange}
                  ref={register({ required: true })}
                />
                <span className={validEmailClass}>A valid email is required</span>
                {errors.email && <span className="error-text">A valid email is required</span>}
              </div>
              <div className="form-item-half-width margin-left is-required">
                <input
                  type="text"
                  name="website"
                  className={errors.website ? 'error-border' : 'error-none'}
                  placeholder={website_placeholder}
                  ref={register({ required: false })}
                />
              </div>
              <div className="form-item-half-width margin-right is-required">
                <input
                  type="text"
                  name="twitter"
                  className={errors.twitter ? 'error-border' : 'error-none'}
                  placeholder={twitter_handle_placeholder}
                  ref={register({ required: false })}
                />
              </div>
              <div className="form-item-half-width margin-left is-required">
                <input
                  type="text"
                  name="github"
                  onChange={onChange}
                  className={errors.github ? 'error-border' : 'error-none'}
                  placeholder={github_placeholder}
                  ref={register({ required: true })}
                />
                <span className={validGithubClass}>A valid Github username is required</span>
                {errors.github && <span className="error-text">Github address is required</span>}
              </div>
              <div className="form-item-full-width">
                <h2>Where will you be speaking?</h2>
              </div>
              <div className="form-item-full-width is-required">
                <input
                  type="text"
                  name="event_name"
                  className={errors.event_name ? 'error-border' : 'error-none'}
                  placeholder={event_name_placeholder}
                  ref={register({ required: true })}
                />
                {errors.event_name && <span className="error-text">Event name is required</span>}
              </div>
              <div className="form-item-half-width margin-right is-required">
                <input
                  type="text"
                  name="event_city"
                  className={errors.event_city ? 'error-border' : 'error-none'}
                  placeholder={event_city_placeholder}
                  ref={register({ required: true })}
                />
                {errors.event_city && <span className="error-text">Event city address is required</span>}
              </div>
              <div className="form-item-half-width margin-left is-required">
                <input
                  type="text"
                  name="event_country"
                  className={errors.event_country ? 'error-border' : 'error-none'}
                  placeholder={event_country_placeholder}
                  ref={register({ required: true })}
                />
                {errors.event_country && <span className="error-text">Event country is required</span>}
              </div>
              <div className="form-item-full-width is-required">
                <DatePicker
                  selected={currentDate}
                  onChange={changeDateSelect}
                  name="startDate"
                  dateFormat="yyyy-MM-dd"
                />
                <input type="hidden" name="event_date" value={eventDateValue} ref={register({ required: true })} />
                {errors.event_date && <span className="error-text">Event date is a required field</span>}
              </div>
              <div className="form-item-full-width is-required select">
                <select
                  name="event_attendance"
                  placeholder={event_attendance_placeholder}
                  className={errors.lead_role ? 'error-border' : 'error-none'}
                  ref={register({ required: true })}
                >
                  <option value="">{event_attendance_placeholder}</option>
                  <option value="0-50">0-50 developers</option>
                  <option value="50-150">50-150 developers</option>
                  <option value="150-500">150-500 developers</option>
                  <option value="500+">500+ developers</option>
                </select>
                {errors.event_attendance && <span className="error-text">Event attendance is a required field</span>}
              </div>
              <div className="form-item-full-width">
                <h2>What are you speaking about?</h2>
              </div>
              <div className="form-item-full-width is-required">
                <input
                  type="text"
                  name="approved_talk_title"
                  className={errors.approved_talk_title_placeholder ? 'error-border' : 'error-none'}
                  placeholder={approved_talk_title_placeholder}
                  ref={register({ required: true })}
                />
                {errors.approved_talk_title && (
                  <span className="error-text">Approved talk title is a required field</span>
                )}
              </div>
              <div className="form-item-full-width is-required text-area">
                <textarea
                  name="approved_talk_description"
                  placeholder={approved_talk_description_placeholder}
                  ref={register({ required: true })}
                />
                {errors.approved_talk_description && (
                  <span className="error-text">Approved talk description is a required field</span>
                )}
              </div>
              <div className="form-item-full-width is-required select">
                <select
                  name="audience_level"
                  placeholder={audience_level_placeholder}
                  className={errors.audience_level ? 'error-border' : 'error-none'}
                  ref={register({ required: true })}
                >
                  <option value="">{audience_level_placeholder}</option>
                  <option value="beginner">Beginner</option>
                  <option value="intermediate">Intermediate</option>
                  <option value="advanced">Advanced</option>
                </select>
                {errors.audience_level && <span className="error-text">Audience level is a required field</span>}
              </div>
              <div className="form-item-half-width">
                <input type="submit" value="Apply for Droplets" />
              </div>
            </span>
          </StyledForm>
          <StyledFaq>
            <h2>{faq_header}</h2>
            <span>
              <h4>{faq_question_1}</h4>
              <p>{faq_answer_1[0].text}</p>
            </span>
            <span>
              <h4>{faq_question_2}</h4>
              <p>{faq_answer_2[0].text}</p>
            </span>
            <span>
              <h4>{faq_question_3}</h4>
              <p>{faq_answer_3[0].text}</p>
            </span>
            <span>
              <h4>{faq_question_4}</h4>
              <p>{faq_answer_4[0].text}</p>
            </span>
          </StyledFaq>
        </span>
      </BulmaContainer>
    </BulmaSection>
  );
};

export default DropletsDemosForm;

DropletsDemosForm.propTypes = {
  input: PropTypes.object.isRequired,
};
