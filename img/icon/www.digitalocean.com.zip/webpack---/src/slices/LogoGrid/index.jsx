/* eslint-disable camelcase */
import React from 'react';
import PropTypes from 'prop-types';

import { css, keyframes } from '@emotion/core';

import BulmaContainer from 'react-bulma-components/lib/components/container';
import BulmaSection from 'react-bulma-components/lib/components/section';

import {
  styledSection,
  styledLogoContainer,
  styledHeader,
  styledSubheader,
  styledCTA,
  styledLogoMask,
  styledImage,
} from './LogoGridStyles';
import { createRandomId } from '../../util/createRandomId';
import { Heading, TextLink, LazyImage } from '../atoms';

const renderHeading = (text, atts) => (
  <Heading {...atts} css={atts.css}>
    {text.text}
  </Heading>
);

// To create the scrolling animation, we need to create an
// array of all the logos 3 times so there are no possible gaps.
const renderLogos = (items, auto_scroll, scroll_speed) => {
  // Calculate largest height in all logos
  const largestHeight = items.reduce((largest, item) =>
    largest > item.logo.dimensions.height ? largest : item.logo.dimensions.height,
  );
  // Calculate length of all logos + margin (40 on each side) so the animation is perfectly cut.
  const animationLength = items.reduce((prev, current) => prev + (current.logo.dimensions.width + 80), 0);
  const imageScrollAnimation = keyframes`
    0% {
      margin-left: 0px;
    }
    100% {
      margin-left: -${animationLength}px;
    }
  `;
  const styledFirstImage = css`
    animation: ${imageScrollAnimation} ${scroll_speed}s linear infinite;
  `;
  // Double logos when auto_scroll is enabled, so that there are no gaps between logos
  const logos = auto_scroll ? [...items, ...items] : items;
  return (
    <div
      id="logogrid-logos"
      css={css`
        width: ${animationLength * 2}px;
        height: ${largestHeight}px;
      `}
      className={!auto_scroll ? 'no-scroll' : null}
    >
      {logos.map((item, index) => (
        <LazyImage
          alt={item.logo.alt || 'logo'}
          key={createRandomId()}
          src={item.logo.url}
          width={item.logo.dimensions.width}
          height={item.logo.dimensions.height}
          css={index === 0 && auto_scroll ? styledFirstImage : styledImage}
        />
      ))}
    </div>
  );
};

const LogoGrid = ({ input }) => {
  const {
    text_color,
    autoScroll,
    scroll_speed,
    background_color,
    heading,
    heading_color,
    subheading,
    subheading_color,
    cta_link,
    cta_text,
  } = input.primary;

  return (
    <BulmaSection id="logogrid" css={styledSection} style={{ backgroundColor: background_color }}>
      <BulmaContainer>
        {heading &&
          renderHeading(heading[0], {
            style: heading_color ? { color: heading_color } : null,
            className: text_color === 'light' ? 'h6 white' : 'h6 darkblue',
            renderAs: 'h6',
            css: styledHeader,
          })}
        {subheading &&
          renderHeading(subheading[0], {
            style: subheading_color ? { color: subheading_color } : null,
            className: text_color === 'light' ? 'small transparentWhite' : 'small darkgrey',
            renderAs: 'p',
            subtitle: true,
            css: styledSubheader,
          })}
        <BulmaContainer css={styledLogoContainer}>
          {autoScroll ? (
            <div
              css={css`
              ${styledLogoMask}
              background: linear-gradient(90deg, ${background_color} 12.38%, rgba(1, 14, 40, 0) 100%);
              left: 0;
            `}
            />
          ) : null}
          {renderLogos(input.fields, autoScroll, scroll_speed)}
          {autoScroll ? (
            <div
              css={css`
              ${styledLogoMask}
              background: linear-gradient(-90deg, ${background_color} 12.38%, rgba(1, 14, 40, 0) 100%);
              right: 0;
            `}
            />
          ) : null}
        </BulmaContainer>
        {cta_link ? (
          <TextLink id="logogrid-cta" css={styledCTA} className="medium arrow" url={cta_link && cta_link.url}>
            {cta_text && cta_text[0].text}
          </TextLink>
        ) : null}
      </BulmaContainer>
    </BulmaSection>
  );
};

export default LogoGrid;

LogoGrid.propTypes = {
  input: PropTypes.object.isRequired,
};
