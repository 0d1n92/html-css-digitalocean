// Styles here will override Bulma styles
import { css } from '@emotion/core';
import media, { setBreakPoints } from 'css-in-js-media';

setBreakPoints({ desktop: 1220, phone: 750 });

export const styledSection = css`
  padding-top: 64px;
  padding-bottom: 64px;
`;

export const styledLogoContainer = css`
  overflow: hidden;
  display: flex;
  justify-content: center;
  align-items: center;
  max-width: 1170px;
  margin-top: 32px;

  div.no-scroll {
    height: 100%;
    display: flex;
    width: 100%;
    flex-wrap: wrap;
    justify-content: center;
    align-items: center;

    ${media('< desktop')} {
      max-width: 79vw;
      display: grid;
      grid-template-columns: 1fr 1fr 1fr;

      img {
        margin: 0 auto;
      }
    }

    ${media('< phone')} {
      justify-content: center;
      align-items: center;
      display: flex;
      flex-direction: column;
    }
  }
`;

export const styledHeader = css`
  text-align: center !important;
  letter-spacing: 0.05em !important;
  text-transform: uppercase;
  opacity: 1;
  color: #5b6987 !important;

  margin: 0 auto !important;
`;

export const styledSubheader = css`
  text-align: center;
  margin: 0 auto !important;
`;

export const styledCTA = css`
  text-align: center;
  width: 100%;
  display: flex;
  justify-content: center;
  align-items: flex-end;
  margin-top: 20px;
  margin-bottom: 10px;

  &:after {
    top: 4px !important;
  }
`;

export const styledLogoMask = css`
  position: absolute;
  display: block;
  height: 100%;
  width: 28%;
  z-index: 1;
  top: 0;
`;

export const styledImage = css`
  margin-left: 31px;
  margin-right: 31px;
`;

export const styledLinkArrow = css`
  margin-left: 7px;
  margin-top: 7px;
`;
