import { css } from '@emotion/core';
import media from 'css-in-js-media';
import styled from '@emotion/styled';

export const styledHeading = css`
  margin: 60px auto 0 auto;
  text-align: center;
`;

export const styledSubHeading = css`
  margin: 0 auto;
  max-width: 820px;
  text-align: center;
`;

export const StyledForm = styled.form`
  margin-top: 32px;
  .form-wrapper {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    margin-top: 64px;
    text-align: left;

    .form-item-full-width {
      width: 100%;

      .checkbox-wrapper {
        display: inline-block;
        margin-bottom: 36px;
      }

      label {
        color: #5b6987;
        font-family: 'Sailec-Regular';
        font-size: 16px;
        margin-left: 5px;
      }

      textarea {
        color: #5b6987;
        border: 1px solid #e5e8ed;
        font-family: 'Sailec-Regular';
        font-size: 16px;
        overflow: auto;
        vertical-align: top;
        resize: vertical;
        margin: 25px 0;
        min-height: 80px;
        height: auto;
        text-indent: 10px;
        width: 100%;
      }

      textarea::placeholder {
        color: #5b6987;
      }
    }

    .form-item-half-width:nth-of-type(odd) {
      margin-right: 1%;

      ${media('< tablet')} {
        margin-right: 0;
      }
    }

    .form-item-half-width:nth-of-type(even) {
      margin-left: 1%;

      ${media('< tablet')} {
        margin-left: 0;
      }
    }

    .form-item-half-width {
      margin-bottom: 16px;
      position: relative;
      width: 49%;

      &.is-required:before {
        content: '';
        background: url(
          https://images.prismic.io/www-static/50bfb6e8-d754-4e9f-ade8-b9a08d1ab626_asterik-blue.svg?auto=compress,
          format
        );
        background-size: 10px;
        fill: #0069ff;
        width: 10px;
        height: 10px;
        background-repeat: no-repeat;
        position: absolute;
        top: 20px;
        right: 16px;
        -webkit-transform-origin: center center;
        transform-origin: center center;
        pointer-events: none;
        z-index: 2;
      }

      &.select.is-required:after,
      &.select:after {
        content: '';
        position: absolute;
        top: 25px;
        -webkit-transform: translateY(-50%);
        transform: translateY(-50%);
        right: 16px;
        background: url(
          https://images.prismic.io/www-static/ab28bfed-9412-44c9-b247-6497457a88d4_arrow-down-gray-e67c5162.svg?auto=compress,
          format
        );
        fill: rgba(3, 27, 78, 0.75);
        width: 12px;
        height: 12px;
        background-repeat: no-repeat;
        background-size: contain;
        pointer-events: none;
        right: 40px;
        z-index: 2;
      }

      &.select:after {
        right: 15px;
      }

      input,
      select {
        width: 100%;
        height: 48px;
        background: #fff;
        border: 1px solid #e5e8ed;
        box-sizing: border-box;
        border-radius: 3px;
        margin-bottom: 8px;
        font-family: 'Sailec-Regular';
        font-size: 16px;
        padding: 16px;
        color: #5b6987;
        :focus {
          border-color: #0069ff;
          outline: #0069ff;
        }
      }

      select::-ms-expand {
        display: none;
      }

      select {
        -webkit-appearance: none;
        -moz-appearance: none;
        appearance: none;
        padding: 2px 30px 2px 2px;
        text-indent: 10px;
      }

      input[type='text']::-webkit-input-placeholder {
        color: #5b6987;
      }

      input[type='text']::-moz-placeholder {
        color: #5b6987;
        opacity: 1;
      }

      input[type='text']:-ms-input-placeholder {
        color: #5b6987;
      }

      input[type='text']::-ms-input-placeholder {
        color: #5b6987;
      }

      input[type='text']::placeholder {
        color: #5b6987;
      }

      input.error-border,
      select.error-border {
        border: solid 1px #ca0c0c;
      }
      input[type='submit'] {
        background: #0069ff;
        border: none;
        line-height: 100%;
        font-family: 'Sailec-Bold';
        color: #fff;
        padding: 17px;
        cursor: pointer;
        margin-bottom: 0;
      }
      span.error-text {
        color: #ca0c0c;
        display: inline-block;
        font-family: 'Sailec-Regular';
        font-size: 12px;
        margin-bottom: 16px;
        text-align: left;
      }

      ${media('< tablet')} {
        width: 100%;
        margin-right: 0;
        margin-left: 0;
      }
    }
  }
  .hide-error {
    display: none;
  }
  .show-error {
    display: block;
  }

  .terms-of-service {
    font-size: 14px;
    text-align: center;

    a {
      color: #0069ff;
      text-decoration: underline;
    }
  }
`;

export const styledFormReady = css`
  display: inline-block;

  &.is-none {
    display: none;
  }

  .error-text {
    display: none;
    color: #ca0c0c;
    font-family: 'Sailec-Regular';
    font-size: 16px;
    margin-bottom: 16px;
    text-align: center;
  }

  .error-text.show {
    display: block;
  }
`;

export const StyledThankYouWrapper = styled.div`
  display: flex;
  flex-wrap: wrap;
  justify-content: center;

  svg {
    display: inline-block;
    width: 100%;
  }

  p {
    color: #031b4e;
    font-family: 'Sailec-Light';
    font-size: 20px;
    line-height: 150%;
  }

  &.is-none {
    display: none;
  }

  &.is-block {
    display: block;
    text-align: center;
  }
`;

export const styledCards = css`
  display: grid;
  grid-auto-flow: dense;
  grid-auto-rows: 1fr;
  grid-gap: 32px;
  max-width: 1168px;
  margin-top: 64px;

  .related-card {
    display: inherit;
    margin: 15px auto;
    max-width: 300px;
    min-height: 270px;

    img {
      max-width: 300px;
    }

    p {
      font-size: 16px;
      text-align: left;
    }
  }

  ${media('< desktop')} {
    display: flex;
    flex-direction: column;
    margin-left: 0px;
    margin-right: 0px;
    margin-top: 32px !important;
  }
`;

export const styledCardBox = css`
  background: #fff;
  border: 1px solid #e5e8ed;
  border-radius: 5px;
  padding: 24px;
  margin-bottom: 0 !important;
  box-shadow: none;

  ${media('< desktop')} {
    margin-top: 32px;
  }
`;

export const styledCardContent = css`
  position: relative;
  height: 100%;

  .title {
    margin-top: 15px;
  }

  img {
    max-width: 120px;
    margin-bottom: 10px;
  }

  ${media('<= desktop')} {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
  }
`;
