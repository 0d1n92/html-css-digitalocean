// Styles here will override Bulma styles
import { css } from '@emotion/core';
import styled from '@emotion/styled';
import media from 'css-in-js-media';

export const styledSection = css`
  background: repeat;
  overflow: hidden;
  .container {
    justify-content: center;
    align-items: center;
    display: flex;
    flex-direction: column;
  }
`;

export const styledColumn = css`
  padding-bottom: 28px !important;

  ${media('< desktop')} {
    text-align: center !important;
    width: 80% !important;
    margin: 0 auto;
    padding-bottom: 12px !important;
    flex-direction: column;
    align-items: center;
  }
`;

export const StyledHeadingContainer = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-bottom: 30px;

  p {
    text-align: center;
  }
`;

export const styledHeading = css`
  text-align: center;
`;

export const styledSubheading = css`
  max-width: 670px;
  text-align: center;

  ${media('< desktop')} {
    margin-bottom: 60px !important;
  }
`;

export const styledTable = css`
  max-width: 870px;
  border-spacing: 0px;

  ${media('< tablet')} {
    display: inline-block;
    overflow: scroll;
  }

  a,
  a p {
    cursor: pointer;
    color: #0069ff;
    margin: 0;

    :hover {
      color: #1633ff !important;
    }
  }

  a img {
    margin: 0;
  }

  thead,
  tbody {
    th,
    td {
      color: #5b6987;
      background: #fff !important;
      border-bottom: 1px solid #e5e8ed;
      padding: 10px 0px;
    }
  }

  tbody {
    th {
      font-weight: normal;
    }

    tr {
      th {
        max-width: 500px !important;
        padding-right: 10px;
        vertical-align: middle !important;
      }
    }
  }
`;

export const styledModal = css`
  position: fixed;
  top: 100px;
  ${media('< desktop')} {
    top: 20px;
  }
`;

export const StyledModalContent = styled.div`
  max-width: 770px;
  min-height: 575px;
  background: #fff;
  border-radius: 6px;
  margin: 0 auto;
  display: flex;
  flex-direction: column;
  justify-content: space-between;

  ${media('< desktop')} {
    width: 100%;
  }
`;

export const StyledModalHeader = styled.div`
  border-bottom: 1px solid #f3f5f9;
  display: flex;
  justify-content: space-between;
  align-items: center;
`;

export const styledModalTitle = css`
  text-align: left;
  padding: 24px !important;
  line-height: 110% !important;
`;

export const StyledCloseBtn = styled.a`
  padding: 24px 20px;
  position: relative;
  height: 15px;
  width: 15px;
  cursor: pointer;

  :before,
  :after {
    position: absolute;
    content: ' ';
    height: 15px;
    width: 2px;
    background-color: #5b6987;
  }

  :before {
    transform: rotate(45deg);
  }
  :after {
    transform: rotate(-45deg);
  }
`;

export const StyledModalCopy = styled.div`
  height: 330px;
  padding: 48px 48px 0 48px;
  overflow: scroll;
  color: #5b6987;
`;

export const StyledButtonContainer = styled.div`
  margin: 32px 48px 48px 48px;

  .is-primary {
    margin-right: 16px;
    ${media('< tablet')} {
      margin-top: 16px;
      width: 100%;
    }
  }
`;
