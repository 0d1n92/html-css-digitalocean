/* eslint-disable camelcase */
import React, { useState } from 'react';
import PropTypes from 'prop-types';

import BulmaContainer from 'react-bulma-components/lib/components/container';
import BulmaSection from 'react-bulma-components/lib/components/section';
import BulmaTable from 'react-bulma-components/lib/components/table';

import { RichText } from 'prismic-reactjs';
import { linkResolver } from '../../util/linkResolver';
import { createRandomId } from '../../util/createRandomId';

import { Heading, Modal, Button, LazyLink } from '../atoms';

import {
  styledHeading,
  styledSubheading,
  styledTable,
  styledSection,
  styledModal,
  StyledModalContent,
  StyledModalHeader,
  styledModalTitle,
  StyledCloseBtn,
  StyledModalCopy,
  StyledButtonContainer,
} from './TableModalStyles';

const renderHeading = (text, atts) => (
  <Heading {...atts} css={atts.css}>
    {text.text}
  </Heading>
);

const TableModal = ({ input }) => {
  const {
    text_color,
    background_color,
    background_image,
    heading,
    heading_color,
    subheading,
    subheading_color,
    modal_title,
    modal_copy,
    primary_button_text,
    secondary_button_text,
  } = input.primary;

  const { fields } = input;

  // state for modal
  const [currentDownloadLink, setCurrentDownloadLink] = useState(null);
  const [modalIsShowing, setModalIsShowing] = useState(false);

  return (
    <BulmaSection
      css={styledSection}
      style={{
        backgroundColor: background_color || '#fff',
        backgroundImage: `url(${background_image && background_image.url})`,
        paddingTop: `${!heading && !subheading ? '0px' : null}`,
      }}
    >
      <BulmaContainer>
        {heading &&
          heading[0].text &&
          renderHeading(heading[0], {
            'data-testid': 'heading',
            renderAs: 'h2',
            style: heading_color ? { color: heading_color } : null,
            className: text_color === 'light' ? 'h2 white' : 'h2 darkblue',
            css: styledHeading,
          })}
        {subheading &&
          subheading[0].text &&
          renderHeading(subheading[0], {
            'data-testid': 'subheading',
            renderAs: 'p',
            style: subheading_color ? { color: subheading_color } : null,
            className: text_color === 'light' ? 'medium white' : 'medium darkgrey',
            subtitle: true,
            css: styledSubheading,
          })}

        {/* Table */}
        <BulmaTable css={styledTable} className="is-scrollable">
          <thead>
            <tr>
              {fields.map(col => (
                <th key={createRandomId()}>{col.column_heading ? col.column_heading : null}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {fields[0] && fields[0].column_row_1 && fields[0].column_row_1[0].text && (
              <tr>
                <th> {fields[0] && fields[0].column_row_1 && fields[0].column_row_1[0].text} </th>
                {modal_copy ? (
                  <>
                    <td>
                      <a
                        role="button"
                        tabIndex="0"
                        onClick={() => {
                          setCurrentDownloadLink(
                            fields[1] &&
                              fields[1].column_row_1_download_link &&
                              fields[1].column_row_1_download_link.url,
                          );
                          setModalIsShowing(true);
                        }}
                        onKeyPress={() => setModalIsShowing(true)}
                      >
                        <RichText
                          render={fields[1] && fields[1].column_row_1 && fields[1].column_row_1}
                          linkResolver={linkResolver}
                        />
                      </a>
                    </td>
                    <td>
                      <a
                        role="button"
                        tabIndex="0"
                        onClick={() => {
                          setCurrentDownloadLink(
                            fields[2] &&
                              fields[2].column_row_1_download_link &&
                              fields[2].column_row_1_download_link.url,
                          );
                          setModalIsShowing(true);
                        }}
                        onKeyPress={() => setModalIsShowing(true)}
                      >
                        <RichText
                          render={fields[2] && fields[2].column_row_1 && fields[2].column_row_1}
                          linkResolver={linkResolver}
                        />
                      </a>
                    </td>
                    <td>
                      <a
                        role="button"
                        tabIndex="0"
                        onClick={() => {
                          setCurrentDownloadLink(
                            fields[3] &&
                              fields[3].column_row_1_download_link &&
                              fields[3].column_row_1_download_link.url,
                          );
                          setModalIsShowing(true);
                        }}
                        onKeyPress={() => setModalIsShowing(true)}
                      >
                        <RichText
                          render={fields[3] && fields[3].column_row_1 && fields[3].column_row_1}
                          linkResolver={linkResolver}
                        />
                      </a>
                    </td>
                    <td>
                      <a
                        role="button"
                        tabIndex="0"
                        onClick={() => {
                          setCurrentDownloadLink(
                            fields[4] &&
                              fields[4].column_row_1_download_link &&
                              fields[4].column_row_1_download_link.url,
                          );
                          setModalIsShowing(true);
                        }}
                        onKeyPress={() => setModalIsShowing(true)}
                      >
                        <RichText
                          render={fields[4] && fields[4].column_row_1 && fields[4].column_row_1}
                          linkResolver={linkResolver}
                        />
                      </a>
                    </td>
                    <td>
                      <a
                        role="button"
                        tabIndex="0"
                        onClick={() => {
                          setCurrentDownloadLink(
                            fields[5] &&
                              fields[5].column_row_1_download_link &&
                              fields[5].column_row_1_download_link.url,
                          );
                          setModalIsShowing(true);
                        }}
                        onKeyPress={() => setModalIsShowing(true)}
                      >
                        <RichText
                          render={fields[5] && fields[5].column_row_1 && fields[5].column_row_1}
                          linkResolver={linkResolver}
                        />
                      </a>
                    </td>
                  </>
                ) : (
                  <>
                    <td>
                      <RichText
                        render={fields[1] && fields[1].column_row_1 && fields[1].column_row_1[0]}
                        linkResolver={linkResolver}
                      />
                      {/* {fields[1] && fields[1].column_row_1 && fields[1].column_row_1[0].text} */}
                    </td>
                    <td>
                      <RichText
                        render={fields[2] && fields[2].column_row_1 && fields[2].column_row_1}
                        linkResolver={linkResolver}
                      />
                    </td>
                    <td>
                      <RichText
                        render={fields[3] && fields[3].column_row_1 && fields[3].column_row_1}
                        linkResolver={linkResolver}
                      />
                    </td>
                    <td>
                      <RichText
                        render={fields[4] && fields[4].column_row_1 && fields[4].column_row_1}
                        linkResolver={linkResolver}
                      />
                    </td>
                    <td>
                      <RichText
                        render={fields[5] && fields[5].column_row_1 && fields[5].column_row_1}
                        linkResolver={linkResolver}
                      />
                    </td>
                  </>
                )}
              </tr>
            )}
            {fields[0] && fields[0].column_row_2 && fields[0].column_row_2[0].text && (
              <tr>
                <th> {fields[0] && fields[0].column_row_2 && fields[0].column_row_2[0].text} </th>
                {modal_copy ? (
                  <>
                    <td>
                      <a
                        role="button"
                        tabIndex="0"
                        onClick={() => {
                          setCurrentDownloadLink(
                            fields[1] &&
                              fields[1].column_row_2_download_link &&
                              fields[1].column_row_2_download_link.url,
                          );
                          setModalIsShowing(true);
                        }}
                        onKeyPress={() => setModalIsShowing(true)}
                      >
                        <RichText
                          render={fields[1] && fields[1].column_row_1 && fields[1].column_row_1}
                          linkResolver={linkResolver}
                        />
                      </a>
                    </td>
                    <td>
                      <a
                        role="button"
                        tabIndex="0"
                        onClick={() => {
                          setCurrentDownloadLink(
                            fields[2] &&
                              fields[2].column_row_2_download_link &&
                              fields[2].column_row_2_download_link.url,
                          );
                          setModalIsShowing(true);
                        }}
                        onKeyPress={() => setModalIsShowing(true)}
                      >
                        <RichText
                          render={fields[2] && fields[2].column_row_2 && fields[2].column_row_2}
                          linkResolver={linkResolver}
                        />
                      </a>
                    </td>
                    <td>
                      <a
                        role="button"
                        tabIndex="0"
                        onClick={() => {
                          setCurrentDownloadLink(
                            fields[3] &&
                              fields[3].column_row_2_download_link &&
                              fields[3].column_row_2_download_link.url,
                          );
                          setModalIsShowing(true);
                        }}
                        onKeyPress={() => setModalIsShowing(true)}
                      >
                        <RichText
                          render={fields[3] && fields[3].column_row_2 && fields[3].column_row_2}
                          linkResolver={linkResolver}
                        />
                      </a>
                    </td>
                    <td>
                      <a
                        role="button"
                        tabIndex="0"
                        onClick={() => {
                          setCurrentDownloadLink(
                            fields[4] &&
                              fields[4].column_row_2_download_link &&
                              fields[4].column_row_2_download_link.url,
                          );
                          setModalIsShowing(true);
                        }}
                        onKeyPress={() => setModalIsShowing(true)}
                      >
                        <RichText
                          render={fields[4] && fields[4].column_row_2 && fields[4].column_row_2}
                          linkResolver={linkResolver}
                        />
                      </a>
                    </td>
                    <td>
                      <a
                        role="button"
                        tabIndex="0"
                        onClick={() => {
                          setCurrentDownloadLink(
                            fields[5] &&
                              fields[5].column_row_2_download_link &&
                              fields[5].column_row_2_download_link.url,
                          );
                          setModalIsShowing(true);
                        }}
                        onKeyPress={() => setModalIsShowing(true)}
                      >
                        <RichText
                          render={fields[5] && fields[5].column_row_2 && fields[5].column_row_2}
                          linkResolver={linkResolver}
                        />
                      </a>
                    </td>
                  </>
                ) : (
                  <>
                    <td>
                      <RichText
                        render={fields[1] && fields[1].column_row_2 && fields[1].column_row_2}
                        linkResolver={linkResolver}
                      />
                    </td>
                    <td>
                      <RichText
                        render={fields[2] && fields[2].column_row_2 && fields[2].column_row_2}
                        linkResolver={linkResolver}
                      />
                    </td>
                    <td>
                      <RichText
                        render={fields[3] && fields[3].column_row_2 && fields[3].column_row_2}
                        linkResolver={linkResolver}
                      />
                    </td>
                    <td>
                      <RichText
                        render={fields[4] && fields[4].column_row_2 && fields[4].column_row_2}
                        linkResolver={linkResolver}
                      />
                    </td>
                    <td>
                      <RichText
                        render={fields[5] && fields[5].column_row_2 && fields[5].column_row_2}
                        linkResolver={linkResolver}
                      />
                    </td>
                  </>
                )}
              </tr>
            )}
            {fields[0] && fields[0].column_row_3 && fields[0].column_row_3[0].text && (
              <tr>
                <th> {fields[0] && fields[0].column_row_3 && fields[0].column_row_3[0].text} </th>
                {modal_copy ? (
                  <>
                    <td>
                      <a
                        role="button"
                        tabIndex="0"
                        onClick={() => {
                          setCurrentDownloadLink(
                            fields[1] &&
                              fields[1].column_row_3_download_link &&
                              fields[1].column_row_3_download_link.url,
                          );
                          setModalIsShowing(true);
                        }}
                        onKeyPress={() => setModalIsShowing(true)}
                      >
                        <RichText
                          render={fields[1] && fields[1].column_row_3 && fields[1].column_row_3}
                          linkResolver={linkResolver}
                        />
                      </a>
                    </td>
                    <td>
                      <a
                        role="button"
                        tabIndex="0"
                        onClick={() => {
                          setCurrentDownloadLink(
                            fields[2] &&
                              fields[2].column_row_3_download_link &&
                              fields[2].column_row_3_download_link.url,
                          );
                          setModalIsShowing(true);
                        }}
                        onKeyPress={() => setModalIsShowing(true)}
                      >
                        <RichText
                          render={fields[2] && fields[2].column_row_3 && fields[2].column_row_3}
                          linkResolver={linkResolver}
                        />
                      </a>
                    </td>
                    <td>
                      <a
                        role="button"
                        tabIndex="0"
                        onClick={() => {
                          setCurrentDownloadLink(
                            fields[3] &&
                              fields[3].column_row_3_download_link &&
                              fields[3].column_row_3_download_link.url,
                          );
                          setModalIsShowing(true);
                        }}
                        onKeyPress={() => setModalIsShowing(true)}
                      >
                        <RichText
                          render={fields[3] && fields[3].column_row_3 && fields[3].column_row_3}
                          linkResolver={linkResolver}
                        />
                      </a>
                    </td>
                    <td>
                      <a
                        role="button"
                        tabIndex="0"
                        onClick={() => {
                          setCurrentDownloadLink(
                            fields[4] &&
                              fields[4].column_row_3_download_link &&
                              fields[4].column_row_3_download_link.url,
                          );
                          setModalIsShowing(true);
                        }}
                        onKeyPress={() => setModalIsShowing(true)}
                      >
                        <RichText
                          render={fields[4] && fields[4].column_row_3 && fields[4].column_row_3}
                          linkResolver={linkResolver}
                        />
                      </a>
                    </td>
                    <td>
                      <a
                        role="button"
                        tabIndex="0"
                        onClick={() => {
                          setCurrentDownloadLink(
                            fields[5] &&
                              fields[5].column_row_3_download_link &&
                              fields[5].column_row_3_download_link.url,
                          );
                          setModalIsShowing(true);
                        }}
                        onKeyPress={() => setModalIsShowing(true)}
                      >
                        <RichText
                          render={fields[5] && fields[5].column_row_3 && fields[5].column_row_3}
                          linkResolver={linkResolver}
                        />
                      </a>
                    </td>
                  </>
                ) : (
                  <>
                    <td>
                      <RichText
                        render={fields[1] && fields[1].column_row_3 && fields[1].column_row_3}
                        linkResolver={linkResolver}
                      />
                    </td>
                    <td>
                      <RichText
                        render={fields[2] && fields[2].column_row_3 && fields[2].column_row_3}
                        linkResolver={linkResolver}
                      />
                    </td>
                    <td>
                      <RichText
                        render={fields[3] && fields[3].column_row_3 && fields[3].column_row_3}
                        linkResolver={linkResolver}
                      />
                    </td>
                    <td>
                      <RichText
                        render={fields[4] && fields[4].column_row_3 && fields[4].column_row_3}
                        linkResolver={linkResolver}
                      />
                    </td>
                    <td>
                      <RichText
                        render={fields[5] && fields[5].column_row_3 && fields[5].column_row_3}
                        linkResolver={linkResolver}
                      />
                    </td>
                  </>
                )}
              </tr>
            )}
            {fields[0] && fields[0].column_row_4 && fields[0].column_row_4[0].text && (
              <tr>
                <th> {fields[0] && fields[0].column_row_4 && fields[0].column_row_4[0].text} </th>
                {modal_copy ? (
                  <>
                    <td>
                      <a
                        role="button"
                        tabIndex="0"
                        onClick={() => {
                          setCurrentDownloadLink(
                            fields[1] &&
                              fields[1].column_row_4_download_link &&
                              fields[1].column_row_4_download_link.url,
                          );
                          setModalIsShowing(true);
                        }}
                        onKeyPress={() => setModalIsShowing(true)}
                      >
                        <RichText
                          render={fields[1] && fields[1].column_row_4 && fields[1].column_row_4}
                          linkResolver={linkResolver}
                        />
                      </a>
                    </td>
                    <td>
                      <a
                        role="button"
                        tabIndex="0"
                        onClick={() => {
                          setCurrentDownloadLink(
                            fields[2] &&
                              fields[2].column_row_4_download_link &&
                              fields[2].column_row_4_download_link.url,
                          );
                          setModalIsShowing(true);
                        }}
                        onKeyPress={() => setModalIsShowing(true)}
                      >
                        <RichText
                          render={fields[2] && fields[2].column_row_4 && fields[3].column_row_4}
                          linkResolver={linkResolver}
                        />
                      </a>
                    </td>
                    <td>
                      <a
                        role="button"
                        tabIndex="0"
                        onClick={() => {
                          setCurrentDownloadLink(
                            fields[3] &&
                              fields[3].column_row_4_download_link &&
                              fields[3].column_row_4_download_link.url,
                          );
                          setModalIsShowing(true);
                        }}
                        onKeyPress={() => setModalIsShowing(true)}
                      >
                        <RichText
                          render={fields[3] && fields[3].column_row_4 && fields[3].column_row_4}
                          linkResolver={linkResolver}
                        />
                      </a>
                    </td>
                    <td>
                      <a
                        role="button"
                        tabIndex="0"
                        onClick={() => {
                          setCurrentDownloadLink(
                            fields[4] &&
                              fields[4].column_row_4_download_link &&
                              fields[4].column_row_4_download_link.url,
                          );
                          setModalIsShowing(true);
                        }}
                        onKeyPress={() => setModalIsShowing(true)}
                      >
                        <RichText
                          render={fields[4] && fields[4].column_row_4 && fields[4].column_row_4}
                          linkResolver={linkResolver}
                        />
                      </a>
                    </td>
                    <td>
                      <a
                        role="button"
                        tabIndex="0"
                        onClick={() => {
                          setCurrentDownloadLink(
                            fields[5] &&
                              fields[5].column_row_4_download_link &&
                              fields[5].column_row_4_download_link.url,
                          );
                          setModalIsShowing(true);
                        }}
                        onKeyPress={() => setModalIsShowing(true)}
                      >
                        <RichText
                          render={fields[5] && fields[5].column_row_4 && fields[5].column_row_4}
                          linkResolver={linkResolver}
                        />
                      </a>
                    </td>
                  </>
                ) : (
                  <>
                    <td>
                      <RichText
                        render={fields[1] && fields[1].column_row_4 && fields[1].column_row_4}
                        linkResolver={linkResolver}
                      />
                    </td>
                    <td>
                      <RichText
                        render={fields[2] && fields[2].column_row_4 && fields[3].column_row_4}
                        linkResolver={linkResolver}
                      />
                    </td>
                    <td>
                      <RichText
                        render={fields[3] && fields[3].column_row_4 && fields[3].column_row_4}
                        linkResolver={linkResolver}
                      />
                    </td>
                    <td>
                      <RichText
                        render={fields[4] && fields[4].column_row_4 && fields[4].column_row_4}
                        linkResolver={linkResolver}
                      />
                    </td>
                    <td>
                      <RichText
                        render={fields[5] && fields[5].column_row_4 && fields[5].column_row_4}
                        linkResolver={linkResolver}
                      />
                    </td>
                  </>
                )}
              </tr>
            )}
            {fields[0] && fields[0].column_row_5 && fields[0].column_row_5[0].text && (
              <tr>
                <th> {fields[0] && fields[0].column_row_5 && fields[0].column_row_5[0].text} </th>
                {modal_copy ? (
                  <>
                    {' '}
                    <td>
                      <a
                        role="button"
                        tabIndex="0"
                        onClick={() => {
                          setCurrentDownloadLink(
                            fields[1] &&
                              fields[1].column_row_5_download_link &&
                              fields[1].column_row_5_download_link.url,
                          );
                          setModalIsShowing(true);
                        }}
                        onKeyPress={() => setModalIsShowing(true)}
                      >
                        <RichText
                          render={fields[1] && fields[1].column_row_5 && fields[1].column_row_5}
                          linkResolver={linkResolver}
                        />
                      </a>
                    </td>
                    <td>
                      <a
                        role="button"
                        tabIndex="0"
                        onClick={() => {
                          setCurrentDownloadLink(
                            fields[2] &&
                              fields[2].column_row_5_download_link &&
                              fields[2].column_row_5_download_link.url,
                          );
                          setModalIsShowing(true);
                        }}
                        onKeyPress={() => setModalIsShowing(true)}
                      >
                        <RichText
                          render={fields[2] && fields[2].column_row_5 && fields[2].column_row_5}
                          linkResolver={linkResolver}
                        />
                      </a>
                    </td>
                    <td>
                      <a
                        role="button"
                        tabIndex="0"
                        onClick={() => {
                          setCurrentDownloadLink(
                            fields[3] &&
                              fields[3].column_row_5_download_link &&
                              fields[3].column_row_5_download_link.url,
                          );
                          setModalIsShowing(true);
                        }}
                        onKeyPress={() => setModalIsShowing(true)}
                      >
                        <RichText
                          render={fields[3] && fields[3].column_row_5 && fields[3].column_row_5}
                          linkResolver={linkResolver}
                        />
                      </a>
                    </td>
                    <td>
                      <a
                        role="button"
                        tabIndex="0"
                        onClick={() => {
                          setCurrentDownloadLink(
                            fields[4] &&
                              fields[4].column_row_5_download_link &&
                              fields[4].column_row_5_download_link.url,
                          );
                          setModalIsShowing(true);
                        }}
                        onKeyPress={() => setModalIsShowing(true)}
                      >
                        <RichText
                          render={fields[4] && fields[4].column_row_5 && fields[4].column_row_5}
                          linkResolver={linkResolver}
                        />
                      </a>
                    </td>
                    <td>
                      <a
                        role="button"
                        tabIndex="0"
                        onClick={() => {
                          setCurrentDownloadLink(
                            fields[5] &&
                              fields[5].column_row_5_download_link &&
                              fields[5].column_row_5_download_link.url,
                          );
                          setModalIsShowing(true);
                        }}
                        onKeyPress={() => setModalIsShowing(true)}
                      >
                        <RichText
                          render={fields[5] && fields[5].column_row_5 && fields[5].column_row_5}
                          linkResolver={linkResolver}
                        />
                      </a>
                    </td>
                  </>
                ) : (
                  <>
                    <td>
                      <RichText
                        render={fields[1] && fields[1].column_row_5 && fields[1].column_row_5}
                        linkResolver={linkResolver}
                      />
                    </td>
                    <td>
                      <RichText
                        render={fields[2] && fields[2].column_row_5 && fields[2].column_row_5}
                        linkResolver={linkResolver}
                      />
                    </td>
                    <td>
                      <RichText
                        render={fields[3] && fields[3].column_row_5 && fields[3].column_row_5}
                        linkResolver={linkResolver}
                      />
                    </td>
                    <td>
                      <RichText
                        render={fields[4] && fields[4].column_row_5 && fields[4].column_row_5}
                        linkResolver={linkResolver}
                      />
                    </td>
                    <td>
                      <RichText
                        render={fields[5] && fields[5].column_row_5 && fields[5].column_row_5}
                        linkResolver={linkResolver}
                      />
                    </td>
                  </>
                )}
              </tr>
            )}
            {fields[0] && fields[0].column_row_6 && fields[0].column_row_6[0].text && (
              <tr>
                <th> {fields[0] && fields[0].column_row_6 && fields[0].column_row_6[0].text} </th>
                {modal_copy ? (
                  <>
                    <td>
                      <a
                        role="button"
                        tabIndex="0"
                        onClick={() => {
                          setCurrentDownloadLink(
                            fields[1] &&
                              fields[1].column_row_6_download_link &&
                              fields[1].column_row_6_download_link.url,
                          );
                          setModalIsShowing(true);
                        }}
                        onKeyPress={() => setModalIsShowing(true)}
                      >
                        <RichText
                          render={fields[1] && fields[1].column_row_6 && fields[1].column_row_6}
                          linkResolver={linkResolver}
                        />
                      </a>
                    </td>
                    <td>
                      <a
                        role="button"
                        tabIndex="0"
                        onClick={() => {
                          setCurrentDownloadLink(
                            fields[2] &&
                              fields[2].column_row_6_download_link &&
                              fields[2].column_row_6_download_link.url,
                          );
                          setModalIsShowing(true);
                        }}
                        onKeyPress={() => setModalIsShowing(true)}
                      >
                        <RichText
                          render={fields[2] && fields[2].column_row_6 && fields[2].column_row_6}
                          linkResolver={linkResolver}
                        />
                      </a>
                    </td>
                    <td>
                      <a
                        role="button"
                        tabIndex="0"
                        onClick={() => {
                          setCurrentDownloadLink(
                            fields[3] &&
                              fields[3].column_row_6_download_link &&
                              fields[3].column_row_6_download_link.url,
                          );
                          setModalIsShowing(true);
                        }}
                        onKeyPress={() => setModalIsShowing(true)}
                      >
                        <RichText
                          render={fields[3] && fields[3].column_row_6 && fields[3].column_row_6}
                          linkResolver={linkResolver}
                        />
                      </a>
                    </td>
                    <td>
                      <a
                        role="button"
                        tabIndex="0"
                        onClick={() => {
                          setCurrentDownloadLink(
                            fields[4] &&
                              fields[4].column_row_6_download_link &&
                              fields[4].column_row_6_download_link.url,
                          );
                          setModalIsShowing(true);
                        }}
                        onKeyPress={() => setModalIsShowing(true)}
                      >
                        <RichText
                          render={fields[4] && fields[4].column_row_6 && fields[4].column_row_6}
                          linkResolver={linkResolver}
                        />
                      </a>
                    </td>
                    <td>
                      <a
                        role="button"
                        tabIndex="0"
                        onClick={() => {
                          setCurrentDownloadLink(
                            fields[5] &&
                              fields[5].column_row_6_download_link &&
                              fields[5].column_row_6_download_link.url,
                          );
                          setModalIsShowing(true);
                        }}
                        onKeyPress={() => setModalIsShowing(true)}
                      >
                        <RichText
                          render={fields[5] && fields[5].column_row_6 && fields[5].column_row_6}
                          linkResolver={linkResolver}
                        />
                      </a>
                    </td>
                  </>
                ) : (
                  <>
                    <td>
                      <RichText
                        render={fields[1] && fields[1].column_row_6 && fields[1].column_row_6}
                        linkResolver={linkResolver}
                      />
                    </td>
                    <td>
                      <RichText
                        render={fields[2] && fields[2].column_row_6 && fields[2].column_row_6}
                        linkResolver={linkResolver}
                      />
                    </td>
                    <td>
                      <RichText
                        render={fields[3] && fields[3].column_row_6 && fields[3].column_row_6}
                        linkResolver={linkResolver}
                      />
                    </td>
                    <td>
                      <RichText
                        render={fields[4] && fields[4].column_row_6 && fields[4].column_row_6}
                        linkResolver={linkResolver}
                      />
                    </td>
                    <td>
                      <RichText
                        render={fields[5] && fields[5].column_row_6 && fields[5].column_row_6}
                        linkResolver={linkResolver}
                      />
                    </td>
                  </>
                )}
              </tr>
            )}
            {fields[0] && fields[0].column_row_7 && fields[0].column_row_7[0].text && (
              <tr>
                <th> {fields[0] && fields[0].column_row_7 && fields[0].column_row_7[0].text} </th>
                {modal_copy ? (
                  <>
                    <td>
                      <a
                        role="button"
                        tabIndex="0"
                        onClick={() => {
                          setCurrentDownloadLink(
                            fields[1] &&
                              fields[1].column_row_7_download_link &&
                              fields[1].column_row_7_download_link.url,
                          );
                          setModalIsShowing(true);
                        }}
                        onKeyPress={() => setModalIsShowing(true)}
                      >
                        <RichText
                          render={fields[1] && fields[1].column_row_7 && fields[1].column_row_7}
                          linkResolver={linkResolver}
                        />
                      </a>
                    </td>
                    <td>
                      <a
                        role="button"
                        tabIndex="0"
                        onClick={() => {
                          setCurrentDownloadLink(
                            fields[2] &&
                              fields[2].column_row_7_download_link &&
                              fields[2].column_row_7_download_link.url,
                          );
                          setModalIsShowing(true);
                        }}
                        onKeyPress={() => setModalIsShowing(true)}
                      >
                        <RichText
                          render={fields[2] && fields[2].column_row_7 && fields[2].column_row_7}
                          linkResolver={linkResolver}
                        />
                      </a>
                    </td>
                    <td>
                      <a
                        role="button"
                        tabIndex="0"
                        onClick={() => {
                          setCurrentDownloadLink(
                            fields[3] &&
                              fields[3].column_row_7_download_link &&
                              fields[3].column_row_7_download_link.url,
                          );
                          setModalIsShowing(true);
                        }}
                        onKeyPress={() => setModalIsShowing(true)}
                      >
                        <RichText
                          render={fields[3] && fields[3].column_row_7 && fields[3].column_row_7}
                          linkResolver={linkResolver}
                        />
                      </a>
                    </td>
                    <td>
                      <a
                        role="button"
                        tabIndex="0"
                        onClick={() => {
                          setCurrentDownloadLink(
                            fields[4] &&
                              fields[4].column_row_7_download_link &&
                              fields[4].column_row_7_download_link.url,
                          );
                          setModalIsShowing(true);
                        }}
                        onKeyPress={() => setModalIsShowing(true)}
                      >
                        <RichText
                          render={fields[4] && fields[4].column_row_7 && fields[4].column_row_7}
                          linkResolver={linkResolver}
                        />
                      </a>
                    </td>
                    <td>
                      <a
                        role="button"
                        tabIndex="0"
                        onClick={() => {
                          setCurrentDownloadLink(
                            fields[5] &&
                              fields[5].column_row_7_download_link &&
                              fields[5].column_row_7_download_link.url,
                          );
                          setModalIsShowing(true);
                        }}
                        onKeyPress={() => setModalIsShowing(true)}
                      >
                        <RichText
                          render={fields[5] && fields[5].column_row_7 && fields[5].column_row_7}
                          linkResolver={linkResolver}
                        />
                      </a>
                    </td>
                  </>
                ) : (
                  <>
                    <td>
                      <RichText
                        render={fields[1] && fields[1].column_row_7 && fields[1].column_row_7}
                        linkResolver={linkResolver}
                      />
                    </td>
                    <td>
                      <RichText
                        render={fields[2] && fields[2].column_row_7 && fields[2].column_row_7}
                        linkResolver={linkResolver}
                      />
                    </td>
                    <td>
                      <RichText
                        render={fields[3] && fields[3].column_row_7 && fields[3].column_row_7}
                        linkResolver={linkResolver}
                      />
                    </td>
                    <td>
                      <RichText
                        render={fields[4] && fields[4].column_row_7 && fields[4].column_row_7}
                        linkResolver={linkResolver}
                      />
                    </td>
                    <td>
                      <RichText
                        render={fields[5] && fields[5].column_row_7 && fields[5].column_row_7}
                        linkResolver={linkResolver}
                      />
                    </td>
                  </>
                )}
              </tr>
            )}
            {fields[0] && fields[0].column_row_8 && fields[0].column_row_8[0].text && (
              <tr>
                <th> {fields[0] && fields[0].column_row_8 && fields[0].column_row_8[0].text} </th>
                {modal_copy ? (
                  <>
                    <td>
                      <a
                        role="button"
                        tabIndex="0"
                        onClick={() => {
                          setCurrentDownloadLink(
                            fields[1] &&
                              fields[1].column_row_8_download_link &&
                              fields[1].column_row_8_download_link.url,
                          );
                          setModalIsShowing(true);
                        }}
                        onKeyPress={() => setModalIsShowing(true)}
                      >
                        <RichText
                          render={fields[1] && fields[1].column_row_8 && fields[1].column_row_8}
                          linkResolver={linkResolver}
                        />
                      </a>
                    </td>
                    <td>
                      <a
                        role="button"
                        tabIndex="0"
                        onClick={() => {
                          setCurrentDownloadLink(
                            fields[2] &&
                              fields[2].column_row_8_download_link &&
                              fields[2].column_row_8_download_link.url,
                          );
                          setModalIsShowing(true);
                        }}
                        onKeyPress={() => setModalIsShowing(true)}
                      >
                        <RichText
                          render={fields[2] && fields[2].column_row_8 && fields[2].column_row_8}
                          linkResolver={linkResolver}
                        />
                      </a>
                    </td>
                    <td>
                      <a
                        role="button"
                        tabIndex="0"
                        onClick={() => {
                          setCurrentDownloadLink(
                            fields[3] &&
                              fields[3].column_row_8_download_link &&
                              fields[3].column_row_8_download_link.url,
                          );
                          setModalIsShowing(true);
                        }}
                        onKeyPress={() => setModalIsShowing(true)}
                      >
                        <RichText
                          render={fields[3] && fields[3].column_row_8 && fields[3].column_row_8}
                          linkResolver={linkResolver}
                        />
                      </a>
                    </td>
                    <td>
                      <a
                        role="button"
                        tabIndex="0"
                        onClick={() => {
                          setCurrentDownloadLink(
                            fields[4] &&
                              fields[4].column_row_8_download_link &&
                              fields[4].column_row_8_download_link.url,
                          );
                          setModalIsShowing(true);
                        }}
                        onKeyPress={() => setModalIsShowing(true)}
                      >
                        <RichText
                          render={fields[4] && fields[4].column_row_8 && fields[4].column_row_8}
                          linkResolver={linkResolver}
                        />
                      </a>
                    </td>
                    <td>
                      <a
                        role="button"
                        tabIndex="0"
                        onClick={() => {
                          setCurrentDownloadLink(
                            fields[5] &&
                              fields[5].column_row_8_download_link &&
                              fields[5].column_row_8_download_link.url,
                          );
                          setModalIsShowing(true);
                        }}
                        onKeyPress={() => setModalIsShowing(true)}
                      >
                        <RichText
                          render={fields[5] && fields[5].column_row_8 && fields[5].column_row_8}
                          linkResolver={linkResolver}
                        />
                      </a>
                    </td>
                  </>
                ) : (
                  <>
                    <td>
                      <RichText
                        render={fields[1] && fields[1].column_row_8 && fields[1].column_row_8}
                        linkResolver={linkResolver}
                      />
                    </td>
                    <td>
                      <RichText
                        render={fields[2] && fields[2].column_row_8 && fields[2].column_row_8}
                        linkResolver={linkResolver}
                      />
                    </td>
                    <td>
                      <RichText
                        render={fields[3] && fields[3].column_row_8 && fields[3].column_row_8}
                        linkResolver={linkResolver}
                      />
                    </td>
                    <td>
                      <RichText
                        render={fields[4] && fields[4].column_row_8 && fields[4].column_row_8}
                        linkResolver={linkResolver}
                      />
                    </td>
                    <td>
                      <RichText
                        render={fields[5] && fields[5].column_row_8 && fields[5].column_row_8}
                        linkResolver={linkResolver}
                      />
                    </td>
                  </>
                )}
              </tr>
            )}
            {fields[0] && fields[0].column_row_9 && fields[0].column_row_9[0].text && (
              <tr>
                <th> {fields[0] && fields[0].column_row_9 && fields[0].column_row_9[0].text} </th>
                {modal_copy ? (
                  <>
                    <td>
                      <a
                        role="button"
                        tabIndex="0"
                        onClick={() => {
                          setCurrentDownloadLink(
                            fields[1] &&
                              fields[1].column_row_9_download_link &&
                              fields[1].column_row_9_download_link.url,
                          );
                          setModalIsShowing(true);
                        }}
                        onKeyPress={() => setModalIsShowing(true)}
                      >
                        <RichText
                          render={fields[1] && fields[1].column_row_9 && fields[1].column_row_9}
                          linkResolver={linkResolver}
                        />
                      </a>
                    </td>
                    <td>
                      <a
                        role="button"
                        tabIndex="0"
                        onClick={() => {
                          setCurrentDownloadLink(
                            fields[2] &&
                              fields[2].column_row_9_download_link &&
                              fields[2].column_row_9_download_link.url,
                          );
                          setModalIsShowing(true);
                        }}
                        onKeyPress={() => setModalIsShowing(true)}
                      >
                        <RichText
                          render={fields[2] && fields[2].column_row_9 && fields[2].column_row_9}
                          linkResolver={linkResolver}
                        />
                      </a>
                    </td>
                    <td>
                      <a
                        role="button"
                        tabIndex="0"
                        onClick={() => {
                          setCurrentDownloadLink(
                            fields[3] &&
                              fields[3].column_row_9_download_link &&
                              fields[3].column_row_9_download_link.url,
                          );
                          setModalIsShowing(true);
                        }}
                        onKeyPress={() => setModalIsShowing(true)}
                      >
                        <RichText
                          render={fields[3] && fields[3].column_row_9 && fields[3].column_row_9}
                          linkResolver={linkResolver}
                        />
                      </a>
                    </td>
                    <td>
                      <a
                        role="button"
                        tabIndex="0"
                        onClick={() => {
                          setCurrentDownloadLink(
                            fields[4] &&
                              fields[4].column_row_9_download_link &&
                              fields[4].column_row_9_download_link.url,
                          );
                          setModalIsShowing(true);
                        }}
                        onKeyPress={() => setModalIsShowing(true)}
                      >
                        <RichText
                          render={fields[4] && fields[4].column_row_9 && fields[4].column_row_9}
                          linkResolver={linkResolver}
                        />
                      </a>
                    </td>
                    <td>
                      <a
                        role="button"
                        tabIndex="0"
                        onClick={() => {
                          setCurrentDownloadLink(
                            fields[5] &&
                              fields[5].column_row_9_download_link &&
                              fields[5].column_row_9_download_link.url,
                          );
                          setModalIsShowing(true);
                        }}
                        onKeyPress={() => setModalIsShowing(true)}
                      >
                        <RichText
                          render={fields[5] && fields[5].column_row_9 && fields[5].column_row_9}
                          linkResolver={linkResolver}
                        />
                      </a>
                    </td>
                  </>
                ) : (
                  <>
                    <td>
                      <RichText
                        render={fields[1] && fields[1].column_row_9 && fields[1].column_row_9}
                        linkResolver={linkResolver}
                      />
                    </td>
                    <td>
                      <RichText
                        render={fields[2] && fields[2].column_row_9 && fields[2].column_row_9}
                        linkResolver={linkResolver}
                      />
                    </td>
                    <td>
                      <RichText
                        render={fields[3] && fields[3].column_row_9 && fields[3].column_row_9}
                        linkResolver={linkResolver}
                      />
                    </td>
                    <td>
                      <RichText
                        render={fields[4] && fields[4].column_row_9 && fields[4].column_row_9}
                        linkResolver={linkResolver}
                      />
                    </td>
                    <td>
                      <RichText
                        render={fields[5] && fields[5].column_row_9 && fields[5].column_row_9}
                        linkResolver={linkResolver}
                      />
                    </td>
                  </>
                )}
              </tr>
            )}
            {fields[0] && fields[0].column_row_10 && fields[0].column_row_10[0].text && (
              <tr>
                <th> {fields[0] && fields[0].column_row_10 && fields[0].column_row_10[0].text} </th>
                {modal_copy ? (
                  <>
                    <td>
                      <a
                        role="button"
                        tabIndex="0"
                        onClick={() => {
                          setCurrentDownloadLink(
                            fields[1] &&
                              fields[1].column_row_10_download_link &&
                              fields[1].column_row_10_download_link.url,
                          );
                          setModalIsShowing(true);
                        }}
                        onKeyPress={() => setModalIsShowing(true)}
                      >
                        <RichText
                          render={fields[1] && fields[1].column_row_10 && fields[1].column_row_10}
                          linkResolver={linkResolver}
                        />
                      </a>
                    </td>
                    <td>
                      <a
                        role="button"
                        tabIndex="0"
                        onClick={() => {
                          setCurrentDownloadLink(
                            fields[2] &&
                              fields[2].column_row_10_download_link &&
                              fields[2].column_row_10_download_link.url,
                          );
                          setModalIsShowing(true);
                        }}
                        onKeyPress={() => setModalIsShowing(true)}
                      >
                        <RichText
                          render={fields[2] && fields[2].column_row_10 && fields[2].column_row_10}
                          linkResolver={linkResolver}
                        />
                      </a>
                    </td>
                    <td>
                      <a
                        role="button"
                        tabIndex="0"
                        onClick={() => {
                          setCurrentDownloadLink(
                            fields[3] &&
                              fields[3].column_row_10_download_link &&
                              fields[3].column_row_10_download_link.url,
                          );
                          setModalIsShowing(true);
                        }}
                        onKeyPress={() => setModalIsShowing(true)}
                      >
                        <RichText
                          render={fields[3] && fields[3].column_row_10 && fields[3].column_row_10}
                          linkResolver={linkResolver}
                        />
                      </a>
                    </td>
                    <td>
                      <a
                        role="button"
                        tabIndex="0"
                        onClick={() => {
                          setCurrentDownloadLink(
                            fields[4] &&
                              fields[4].column_row_10_download_link &&
                              fields[4].column_row_10_download_link.url,
                          );
                          setModalIsShowing(true);
                        }}
                        onKeyPress={() => setModalIsShowing(true)}
                      >
                        <RichText
                          render={fields[4] && fields[4].column_row_10 && fields[4].column_row_10}
                          linkResolver={linkResolver}
                        />
                      </a>
                    </td>
                    <td>
                      <a
                        role="button"
                        tabIndex="0"
                        onClick={() => {
                          setCurrentDownloadLink(
                            fields[5] &&
                              fields[5].column_row_10_download_link &&
                              fields[5].column_row_10_download_link.url,
                          );
                          setModalIsShowing(true);
                        }}
                        onKeyPress={() => setModalIsShowing(true)}
                      >
                        <RichText
                          render={fields[5] && fields[5].column_row_10 && fields[5].column_row_10}
                          linkResolver={linkResolver}
                        />
                      </a>
                    </td>
                  </>
                ) : (
                  <>
                    <td>
                      <RichText
                        render={fields[1] && fields[1].column_row_10 && fields[1].column_row_10}
                        linkResolver={linkResolver}
                      />
                    </td>
                    <td>
                      <RichText
                        render={fields[2] && fields[2].column_row_10 && fields[2].column_row_10}
                        linkResolver={linkResolver}
                      />
                    </td>
                    <td>
                      <RichText
                        render={fields[3] && fields[3].column_row_10 && fields[3].column_row_10}
                        linkResolver={linkResolver}
                      />
                    </td>
                    <td>
                      <RichText
                        render={fields[4] && fields[4].column_row_10 && fields[4].column_row_10}
                        linkResolver={linkResolver}
                      />
                    </td>
                    <td>
                      <RichText
                        render={fields[5] && fields[5].column_row_10 && fields[5].column_row_10}
                        linkResolver={linkResolver}
                      />
                    </td>
                  </>
                )}
              </tr>
            )}
            {fields[0] && fields[0].column_row_11 && fields[0].column_row_11[0].text && (
              <tr>
                <th> {fields[0] && fields[0].column_row_11 && fields[0].column_row_11[0].text} </th>
                {modal_copy ? (
                  <>
                    <td>
                      <a
                        role="button"
                        tabIndex="0"
                        onClick={() => {
                          setCurrentDownloadLink(
                            fields[1] &&
                              fields[1].column_row_11_download_link &&
                              fields[1].column_row_11_download_link.url,
                          );
                          setModalIsShowing(true);
                        }}
                        onKeyPress={() => setModalIsShowing(true)}
                      >
                        <RichText
                          render={fields[1] && fields[1].column_row_11 && fields[1].column_row_11}
                          linkResolver={linkResolver}
                        />
                      </a>
                    </td>
                    <td>
                      <a
                        role="button"
                        tabIndex="0"
                        onClick={() => {
                          setCurrentDownloadLink(
                            fields[2] &&
                              fields[2].column_row_11_download_link &&
                              fields[2].column_row_11_download_link.url,
                          );
                          setModalIsShowing(true);
                        }}
                        onKeyPress={() => setModalIsShowing(true)}
                      >
                        <RichText
                          render={fields[2] && fields[2].column_row_11 && fields[2].column_row_11}
                          linkResolver={linkResolver}
                        />
                      </a>
                    </td>
                    <td>
                      <a
                        role="button"
                        tabIndex="0"
                        onClick={() => {
                          setCurrentDownloadLink(
                            fields[3] &&
                              fields[3].column_row_11_download_link &&
                              fields[3].column_row_11_download_link.url,
                          );
                          setModalIsShowing(true);
                        }}
                        onKeyPress={() => setModalIsShowing(true)}
                      >
                        <RichText
                          render={fields[3] && fields[3].column_row_11 && fields[3].column_row_11}
                          linkResolver={linkResolver}
                        />
                      </a>
                    </td>
                    <td>
                      <a
                        role="button"
                        tabIndex="0"
                        onClick={() => {
                          setCurrentDownloadLink(
                            fields[4] &&
                              fields[4].column_row_11_download_link &&
                              fields[4].column_row_11_download_link.url,
                          );
                          setModalIsShowing(true);
                        }}
                        onKeyPress={() => setModalIsShowing(true)}
                      >
                        <RichText
                          render={fields[4] && fields[4].column_row_11 && fields[4].column_row_11}
                          linkResolver={linkResolver}
                        />
                      </a>
                    </td>
                    <td>
                      <a
                        role="button"
                        tabIndex="0"
                        onClick={() => {
                          setCurrentDownloadLink(
                            fields[5] &&
                              fields[5].column_row_11_download_link &&
                              fields[5].column_row_11_download_link.url,
                          );
                          setModalIsShowing(true);
                        }}
                        onKeyPress={() => setModalIsShowing(true)}
                      >
                        <RichText
                          render={fields[5] && fields[5].column_row_11 && fields[5].column_row_11}
                          linkResolver={linkResolver}
                        />
                      </a>
                    </td>
                  </>
                ) : (
                  <>
                    <td>
                      <RichText
                        render={fields[1] && fields[1].column_row_11 && fields[1].column_row_11}
                        linkResolver={linkResolver}
                      />
                    </td>
                    <td>
                      <RichText
                        render={fields[2] && fields[2].column_row_11 && fields[2].column_row_11}
                        linkResolver={linkResolver}
                      />
                    </td>
                    <td>
                      <RichText
                        render={fields[3] && fields[3].column_row_11 && fields[3].column_row_11}
                        linkResolver={linkResolver}
                      />
                    </td>
                    <td>
                      <RichText
                        render={fields[4] && fields[4].column_row_11 && fields[4].column_row_11}
                        linkResolver={linkResolver}
                      />
                    </td>
                    <td>
                      <RichText
                        render={fields[5] && fields[5].column_row_11 && fields[5].column_row_11}
                        linkResolver={linkResolver}
                      />
                    </td>
                  </>
                )}
              </tr>
            )}
            {fields[0] && fields[0].column_row_12 && fields[0].column_row_12[0].text && (
              <tr>
                <th> {fields[0] && fields[0].column_row_12 && fields[0].column_row_12[0].text} </th>
                {modal_copy ? (
                  <>
                    <td>
                      <a
                        role="button"
                        tabIndex="0"
                        onClick={() => {
                          setCurrentDownloadLink(
                            fields[1] &&
                              fields[1].column_row_12_download_link &&
                              fields[1].column_row_12_download_link.url,
                          );
                          setModalIsShowing(true);
                        }}
                        onKeyPress={() => setModalIsShowing(true)}
                      >
                        <RichText
                          render={fields[1] && fields[1].column_row_12 && fields[1].column_row_12}
                          linkResolver={linkResolver}
                        />
                      </a>
                    </td>
                    <td>
                      <a
                        role="button"
                        tabIndex="0"
                        onClick={() => {
                          setCurrentDownloadLink(
                            fields[2] &&
                              fields[2].column_row_12_download_link &&
                              fields[2].column_row_12_download_link.url,
                          );
                          setModalIsShowing(true);
                        }}
                        onKeyPress={() => setModalIsShowing(true)}
                      >
                        <RichText
                          render={fields[2] && fields[2].column_row_12 && fields[2].column_row_12}
                          linkResolver={linkResolver}
                        />
                      </a>
                    </td>
                    <td>
                      <a
                        role="button"
                        tabIndex="0"
                        onClick={() => {
                          setCurrentDownloadLink(
                            fields[3] &&
                              fields[3].column_row_12_download_link &&
                              fields[3].column_row_12_download_link.url,
                          );
                          setModalIsShowing(true);
                        }}
                        onKeyPress={() => setModalIsShowing(true)}
                      >
                        <RichText
                          render={fields[3] && fields[3].column_row_12 && fields[3].column_row_12}
                          linkResolver={linkResolver}
                        />
                      </a>
                    </td>
                    <td>
                      <a
                        role="button"
                        tabIndex="0"
                        onClick={() => {
                          setCurrentDownloadLink(
                            fields[4] &&
                              fields[4].column_row_12_download_link &&
                              fields[4].column_row_12_download_link.url,
                          );
                          setModalIsShowing(true);
                        }}
                        onKeyPress={() => setModalIsShowing(true)}
                      >
                        <RichText
                          render={fields[4] && fields[4].column_row_12 && fields[4].column_row_12}
                          linkResolver={linkResolver}
                        />
                      </a>
                    </td>
                    <td>
                      <a
                        role="button"
                        tabIndex="0"
                        onClick={() => {
                          setCurrentDownloadLink(
                            fields[5] &&
                              fields[5].column_row_12_download_link &&
                              fields[5].column_row_12_download_link.url,
                          );
                          setModalIsShowing(true);
                        }}
                        onKeyPress={() => setModalIsShowing(true)}
                      >
                        <RichText
                          render={fields[5] && fields[5].column_row_12 && fields[5].column_row_12}
                          linkResolver={linkResolver}
                        />
                      </a>
                    </td>
                  </>
                ) : (
                  <>
                    <td>
                      <RichText
                        render={fields[1] && fields[1].column_row_12 && fields[1].column_row_12}
                        linkResolver={linkResolver}
                      />
                    </td>
                    <td>
                      <RichText
                        render={fields[2] && fields[2].column_row_12 && fields[2].column_row_12}
                        linkResolver={linkResolver}
                      />
                    </td>
                    <td>
                      <RichText
                        render={fields[3] && fields[3].column_row_12 && fields[3].column_row_12}
                        linkResolver={linkResolver}
                      />
                    </td>
                    <td>
                      <RichText
                        render={fields[4] && fields[4].column_row_12 && fields[4].column_row_12}
                        linkResolver={linkResolver}
                      />
                    </td>
                    <td>
                      <RichText
                        render={fields[5] && fields[5].column_row_12 && fields[5].column_row_12}
                        linkResolver={linkResolver}
                      />
                    </td>
                  </>
                )}
              </tr>
            )}
            {fields[0] && fields[0].column_row_13 && fields[0].column_row_13[0].text && (
              <tr>
                <th> {fields[0] && fields[0].column_row_13 && fields[0].column_row_13[0].text} </th>
                {modal_copy ? (
                  <>
                    <td>
                      <a
                        role="button"
                        tabIndex="0"
                        onClick={() => {
                          setCurrentDownloadLink(
                            fields[1] &&
                              fields[1].column_row_13_download_link &&
                              fields[1].column_row_13_download_link.url,
                          );
                          setModalIsShowing(true);
                        }}
                        onKeyPress={() => setModalIsShowing(true)}
                      >
                        <RichText
                          render={fields[1] && fields[1].column_row_13 && fields[1].column_row_13}
                          linkResolver={linkResolver}
                        />
                      </a>
                    </td>
                    <td>
                      <a
                        role="button"
                        tabIndex="0"
                        onClick={() => {
                          setCurrentDownloadLink(
                            fields[2] &&
                              fields[2].column_row_13_download_link &&
                              fields[2].column_row_13_download_link.url,
                          );
                          setModalIsShowing(true);
                        }}
                        onKeyPress={() => setModalIsShowing(true)}
                      >
                        <RichText
                          render={fields[2] && fields[2].column_row_13 && fields[2].column_row_13}
                          linkResolver={linkResolver}
                        />
                      </a>
                    </td>
                    <td>
                      <a
                        role="button"
                        tabIndex="0"
                        onClick={() => {
                          setCurrentDownloadLink(
                            fields[3] &&
                              fields[3].column_row_13_download_link &&
                              fields[3].column_row_13_download_link.url,
                          );
                          setModalIsShowing(true);
                        }}
                        onKeyPress={() => setModalIsShowing(true)}
                      >
                        <RichText
                          render={fields[3] && fields[3].column_row_13 && fields[3].column_row_13}
                          linkResolver={linkResolver}
                        />
                      </a>
                    </td>
                    <td>
                      <a
                        role="button"
                        tabIndex="0"
                        onClick={() => {
                          setCurrentDownloadLink(
                            fields[4] &&
                              fields[4].column_row_13_download_link &&
                              fields[4].column_row_13_download_link.url,
                          );
                          setModalIsShowing(true);
                        }}
                        onKeyPress={() => setModalIsShowing(true)}
                      >
                        <RichText
                          render={fields[4] && fields[4].column_row_13 && fields[4].column_row_13}
                          linkResolver={linkResolver}
                        />
                      </a>
                    </td>
                    <td>
                      <a
                        role="button"
                        tabIndex="0"
                        onClick={() => {
                          setCurrentDownloadLink(
                            fields[5] &&
                              fields[5].column_row_13_download_link &&
                              fields[5].column_row_13_download_link.url,
                          );
                          setModalIsShowing(true);
                        }}
                        onKeyPress={() => setModalIsShowing(true)}
                      >
                        <RichText
                          render={fields[5] && fields[5].column_row_13 && fields[5].column_row_13}
                          linkResolver={linkResolver}
                        />
                      </a>
                    </td>
                  </>
                ) : (
                  <>
                    <td>
                      <RichText
                        render={fields[1] && fields[1].column_row_13 && fields[1].column_row_13}
                        linkResolver={linkResolver}
                      />
                    </td>
                    <td>
                      <RichText
                        render={fields[2] && fields[2].column_row_13 && fields[2].column_row_13}
                        linkResolver={linkResolver}
                      />
                    </td>
                    <td>
                      <RichText
                        render={fields[3] && fields[3].column_row_13 && fields[3].column_row_13}
                        linkResolver={linkResolver}
                      />
                    </td>
                    <td>
                      <RichText
                        render={fields[4] && fields[4].column_row_13 && fields[4].column_row_13}
                        linkResolver={linkResolver}
                      />
                    </td>
                    <td>
                      <RichText
                        render={fields[5] && fields[5].column_row_13 && fields[5].column_row_13}
                        linkResolver={linkResolver}
                      />
                    </td>
                  </>
                )}
              </tr>
            )}
          </tbody>
        </BulmaTable>

        {/* Modal */}
        <Modal
          show={modalIsShowing}
          onClose={() => {
            setCurrentDownloadLink(null);
            setModalIsShowing(false);
          }}
          css={styledModal}
          closeOnBlur
          showClose={false}
        >
          <StyledModalContent>
            <StyledModalHeader>
              {modal_title &&
                modal_title[0].text &&
                renderHeading(modal_title[0], {
                  renderAs: 'h5',
                  className: 'h5 darkblue',
                  css: styledModalTitle,
                })}

              <StyledCloseBtn
                onClick={() => {
                  setCurrentDownloadLink(null);
                  setModalIsShowing(false);
                }}
              />
            </StyledModalHeader>
            <StyledModalCopy>
              <RichText render={modal_copy} linkResolver={linkResolver} />
            </StyledModalCopy>
            <StyledButtonContainer>
              <Button
                color={text_color === 'light' ? 'white' : 'primary'}
                renderAs={LazyLink}
                url={currentDownloadLink}
              >
                {primary_button_text}
              </Button>
              <Button
                color={text_color === 'light' ? 'white' : 'primary'}
                outlined
                renderAs="a"
                onClick={() => {
                  setCurrentDownloadLink(null);
                  setModalIsShowing(false);
                }}
              >
                {secondary_button_text}
              </Button>
            </StyledButtonContainer>
          </StyledModalContent>
        </Modal>
      </BulmaContainer>
    </BulmaSection>
  );
};

export default TableModal;

TableModal.propTypes = {
  input: PropTypes.object.isRequired,
};
