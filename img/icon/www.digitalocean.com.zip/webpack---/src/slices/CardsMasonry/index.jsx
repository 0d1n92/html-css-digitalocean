/* eslint-disable camelcase */
import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { css } from 'emotion';

import BulmaContainer from 'react-bulma-components/lib/components/container';
import BulmaSection from 'react-bulma-components/lib/components/section';

import { Heading, Card } from '../atoms';

import { createRandomId } from '../../util/createRandomId';

import {
  styledCardsSection,
  styledCardsContainer,
  styledHeading,
  styledSubtitle,
  StyledNavContainer,
} from './CardsMasonryStyles';
import Masonry from '../atoms/Masonry';
import DropdownMenu from '../atoms/Dropdown';

const CardsMasonry = ({ input }) => {
  const {
    text_color,
    heading,
    heading_color,
    subheading,
    subheading_color,
    background_image,
    background_color,
    dropdown_item_1,
    dropdown_item_2,
    dropdown_item_3,
    dropdown_item_4,
    dropdown_item_5,
  } = input.primary;
  const { fields } = input;

  const [filterValue, setFilterValue] = useState('all');

  const selectFilterValue = value => {
    setFilterValue(value);
  };

  const doesCardContainFilterValue = (card, filterBy) => {
    switch (filterBy) {
      case card.filter_value_1:
        return true;
      case card.filter_value_2:
        return true;
      case card.filter_value_3:
        return true;
      case card.filter_value_4:
        return true;
      case card.filter_value_5:
        return true;
      default:
        return false;
    }
  };

  return (
    <BulmaSection
      id="testCardsSection"
      css={styledCardsSection}
      style={{
        backgroundImage: `url(${background_image && background_image.url})`,
        backgroundColor: background_color,
        paddingTop: `${!heading && !subheading ? '64px' : null}`,
        paddingBottom: `${!heading && !subheading ? '64px' : null}`,
      }}
    >
      <BulmaContainer css={styledCardsContainer}>
        <StyledNavContainer>
          <div>
            {heading && heading[0].text ? (
              <Heading
                style={heading_color ? { color: heading_color } : null}
                css={styledHeading}
                className={text_color === 'light' ? 'h2 white' : 'h2 darkblue'}
                renderAs="h2"
              >
                {heading[0].text}
              </Heading>
            ) : null}
            {subheading && subheading[0].text ? (
              <Heading
                style={subheading_color ? { color: subheading_color } : null}
                css={styledSubtitle}
                subtitle
                className={text_color === 'light' ? 'medium white' : 'medium darkgrey'}
                renderAs="p"
              >
                {subheading[0].text}
              </Heading>
            ) : null}
          </div>
          <DropdownMenu
            onPressFilter={selectFilterValue}
            dropdownItems={[
              dropdown_item_1 && dropdown_item_1[0].text,
              dropdown_item_2 && dropdown_item_2[0].text,
              dropdown_item_3 && dropdown_item_3[0].text,
              dropdown_item_4 && dropdown_item_4[0].text,
              dropdown_item_5 && dropdown_item_5[0].text,
            ]}
          />
        </StyledNavContainer>
        <Masonry
          minWidth={300}
          css={css`
            margin: 2em 0;
          `}
        >
          {filterValue === 'all'
            ? fields.map(card => (
                <Card
                  image={card.image}
                  title={card.title1}
                  title_color={card.title_color}
                  text={card.text}
                  text_color={card.text_color}
                  link={card.link}
                  thumbnail_play={card.image_play_button}
                  key={createRandomId()}
                />
              ))
            : fields
                .filter(card => doesCardContainFilterValue(card, filterValue))
                .map(card => (
                  <Card
                    image={card.image}
                    title={card.title1}
                    title_color={card.title_color}
                    text={card.text}
                    text_color={card.text_color}
                    link={card.link}
                    thumbnail_play={card.image_play_button}
                    key={createRandomId()}
                  />
                ))}
        </Masonry>
      </BulmaContainer>
    </BulmaSection>
  );
};

export default CardsMasonry;

CardsMasonry.propTypes = {
  input: PropTypes.object.isRequired,
};
