// Styles here will override Bulma styles
import styled from '@emotion/styled';
import { css } from '@emotion/core';
import media from 'css-in-js-media';

export const styledHeroTextSection = css`
  display: flex;
  flex-direction: column;
  justify-content: center;
  text-align: center;
  padding-top: 100px;
  padding-bottom: 40px;
`;

export const styledHeroTextContainer = css`
  width: 970px;
  max-width: 970px;
  ${media('< desktop')} {
    width: inherit;
    max-width: inherit;
  }
`;

export const styledButtonContainer = css`
  display: flex;
  justify-content: center;
  margin-top: 40px;

  ${media('< tablet')} {
    flex-direction: column;
  }

  .button {
    margin-right: 0 !important;
  }

  .button:nth-last-of-type(1) {
    margin-left: 20px !important;

    ${media('< tablet')} {
      margin-top: 10px;
      margin-left: 0 !important;
    }
  }
`;

export const StyledAdditionalLinks = styled.ul`
  list-style: none;
  display: flex;
  justify-content: center;
  align-items: flex-end;
  margin-top: 100px;
  flex-wrap: wrap;

  a {
    text-decoration: underline;
    padding: 10px;
  }
`;
