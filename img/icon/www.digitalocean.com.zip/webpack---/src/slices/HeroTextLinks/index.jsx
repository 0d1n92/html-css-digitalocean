/* eslint-disable camelcase */
import React from 'react';
import PropTypes from 'prop-types';

import BulmaButton from 'react-bulma-components/lib/components/button';
import BulmaContainer from 'react-bulma-components/lib/components/container';
import BulmaSection from 'react-bulma-components/lib/components/section';

import { css } from '@emotion/core';
import { Heading, Button, TextLink, LazyLink } from '../atoms';

import {
  styledButtonContainer,
  styledHeroTextContainer,
  styledHeroTextSection,
  StyledAdditionalLinks,
} from './HeroTextLinksStyles';

const renderHeading = (text, heading_color, atts) => (
  <Heading {...atts} style={heading_color ? { color: heading_color } : null}>
    {text}
  </Heading>
);

const renderButton = (link, text, text_color) => (
  <Button color={text_color === 'light' ? 'white' : 'primary'} outlined renderAs={LazyLink} url={link.url}>
    {text}
  </Button>
);

const renderLink = (item, text_color) => {
  const { additional_link_text, additional_link_url } = item;
  return (
    <li>
      <TextLink className={text_color === 'light' ? 'white medium' : 'medium'} url={additional_link_url.url}>
        {additional_link_text}
      </TextLink>
    </li>
  );
};

const HeroTextLinks = ({ input }) => {
  const {
    text_color,
    background_color,
    background_image,
    preheading,
    preheading_color,
    heading,
    heading_color,
    subheading,
    subheading_color,
    cta_primary_text,
    cta_primary_url,
    cta_secondary_text,
    cta_secondary_url,
  } = input.primary;

  return (
    <BulmaSection
      css={css`
        ${styledHeroTextSection}
        background-color: ${background_color};
        ${background_image ? `background-image: url(${background_image.url});` : null};
      `}
    >
      <BulmaContainer css={styledHeroTextContainer}>
        {preheading
          ? renderHeading(preheading, preheading_color, {
              id: 'testHeroTextLinks-preheading',
              renderAs: 'h6',
              className: `${text_color === 'light' ? 'h6 white' : 'h6 darkblue'}`,
            })
          : null}
        {heading && heading[0].text
          ? renderHeading(heading[0].text, heading_color, {
              id: 'testHeroTextLinks-heading',
              className: `${text_color === 'light' ? 'h1 white hero-title' : 'h1 darkblue hero-title'}`,
            })
          : null}
        {subheading && subheading[0].text
          ? renderHeading(subheading[0].text, subheading_color, {
              id: 'testHeroTextLinks-subheading',
              subtitle: true,
              renderAs: 'p',
              className: `${text_color === 'light' ? 'white medium' : 'darkgrey medium'}`,
            })
          : null}
        {cta_primary_url && cta_primary_url.url ? (
          <BulmaButton.Group id="testHeroTextLinks-buttons" css={styledButtonContainer}>
            {cta_primary_url ? renderButton(cta_primary_url, cta_primary_text, text_color) : null}
            {cta_secondary_url && cta_secondary_url.url
              ? renderButton(cta_secondary_url, cta_secondary_text, text_color)
              : null}
          </BulmaButton.Group>
        ) : null}
        <StyledAdditionalLinks>{input.fields.map(item => renderLink(item, text_color))}</StyledAdditionalLinks>
      </BulmaContainer>
    </BulmaSection>
  );
};

export default HeroTextLinks;

HeroTextLinks.propTypes = {
  input: PropTypes.object.isRequired,
};
