/* eslint-disable camelcase */
import React, { useState } from 'react';
import PropTypes from 'prop-types';

import BulmaSection from 'react-bulma-components/lib/components/section';
import BulmaButton from 'react-bulma-components/lib/components/button';
import { Heading, Button, Carousel, Modal, WistiaVideo, LazyImage, LazyLink } from '../atoms';
import playLight from '../../assets/images/play-light.svg';
import {
  StyledCopy,
  styledSubHeading,
  styledHeroCarouselV2Section,
  styledVideoContainer,
  styledHeading,
  styledImage,
  styledLogo,
  styledButtonContainer,
  styledModal,
  StyledMainContent,
  styledVideoPlayMobile,
  styledRightSideContent,
} from './HeroCarouselV2Styles';
import VideoPlay from '../atoms/VideoPlay';

const renderHeading = (text, atts) => <Heading {...atts}>{text.text}</Heading>;

const renderVideoModal = (wistiaId, modalIsShowing, setModalIsShowing, setCurrentWistiaVideoId) => (
  <Modal
    show={modalIsShowing}
    css={styledModal}
    onClose={() => {
      setModalIsShowing(false);
      setCurrentWistiaVideoId(null);
    }}
  >
    <WistiaVideo
      onModalVideoClose={() => {
        setModalIsShowing(false);
        setCurrentWistiaVideoId(null);
      }}
      wistiaId={wistiaId}
      autoplay
    />
  </Modal>
);

const renderContent = (section, prepareVideoModal) => (
  <StyledMainContent>
    <StyledCopy>
      {section.brand_logo && section.brand_logo.url && (
        <LazyImage
          css={styledLogo}
          style={{
            margin: section.text_alignment === 'left' ? '0 0 32px 0' : '0 auto 32px auto',
          }}
          src={section.brand_logo.url}
        />
      )}
      {renderHeading(section.heading[0], {
        id: 'herotext-heading',
        className: `h1 ${section.text_color === 'light' ? 'h1 white' : 'h1 darkblue'} ${
          section.large_heading ? 'hero-title' : ''
        }`,
        css: styledHeading,
        renderAs: 'h1',
        style: { textAlign: section.text_alignment === 'left' ? 'left' : 'center' },
      })}
      {renderHeading(section.subheading[0], {
        id: 'herotext-subheading',
        className: `${section.text_color === 'light' ? 'large white' : 'large darkblue'}`,
        renderAs: 'p',
        subtitle: true,
        css: styledSubHeading,
        style: {
          textAlign: section.text_alignment === 'left' ? 'left' : 'center',
          marginLeft: section.text_alignment === 'left' ? '0' : 'auto',
        },
      })}
      {(section.video_cta_text || section.display_cta_button) && (
        <BulmaButton.Group
          id="herotext-buttons"
          style={section.text_alignment === 'center' ? { display: 'flex', justifyContent: 'center' } : null}
          css={styledButtonContainer}
        >
          {section.display_cta_button && (
            <Button
              color={section.text_color === 'light' ? 'white' : 'primary'}
              renderAs={LazyLink}
              url={section.cta_button_url.url}
            >
              {section.cta_button_text}
            </Button>
          )}
          {section.video_cta_text &&
            section.video_cta_text[0].text &&
            VideoPlay(
              section.video_cta_text,
              section.video_timestamp,
              null,
              section.text_color,
              () => prepareVideoModal(section.video_wistia_id),
              () => prepareVideoModal(section.video_wistia_id),
              null,
            )}
        </BulmaButton.Group>
      )}
    </StyledCopy>
    {section.image && section.image.url && (
      <div css={styledImage}>
        <LazyImage src={section.image.url} />
      </div>
    )}
    {section.video_thumbnail_image && section.video_wistia_id && (
      <button
        css={styledRightSideContent}
        onKeyPress={() => prepareVideoModal(section.video_wistia_id)}
        onClick={() => prepareVideoModal(section.video_wistia_id)}
        aria-label="clickable video-thumbnail"
        role="button"
      >
        <>
          <div css={styledVideoContainer}>
            <LazyImage src={section.video_thumbnail_image.url} />
            <div className="after" />
          </div>
          <LazyImage src={playLight} alt="play" className="play" />
        </>
        <div css={styledVideoPlayMobile}>
          {section.video_cta_text &&
            !section.video_cta_text[0].text &&
            section.video_wistia_id &&
            VideoPlay(
              [{ text: 'Play Video' }],
              section.video_timestamp,
              null,
              section.text_color,
              () => prepareVideoModal(section.video_wistia_id),
              () => prepareVideoModal(section.video_wistia_id),
              null,
            )}
        </div>
      </button>
    )}
  </StyledMainContent>
);

const HeroCarouselV2 = ({ input }) => {
  const [modalIsShowing, setModalIsShowing] = useState(false);
  const [currentWistiaVideoId, setCurrentWistiaVideoId] = useState(null);
  const [currentCarouselIndex, setCurrentCarouselIndex] = useState(0);

  const prepareVideoModal = video_wistia_id => {
    setCurrentWistiaVideoId(video_wistia_id);
    setModalIsShowing(true);
  };

  return (
    <>
      <BulmaSection
        className="hero"
        css={styledHeroCarouselV2Section}
        style={{
          backgroundImage:
            input.fields[currentCarouselIndex] &&
            input.fields[currentCarouselIndex].background_image &&
            `url(${input.fields[currentCarouselIndex].background_image.url})`,
          backgroundColor: input.fields[currentCarouselIndex] && input.fields[currentCarouselIndex].background_color,
        }}
      >
        <Carousel
          maxWidth="1470px"
          text_color={input.fields[currentCarouselIndex] && input.fields[currentCarouselIndex].text_color}
          selectColor={
            input.fields[currentCarouselIndex] && input.fields[currentCarouselIndex].text_color === 'light'
              ? '#fff'
              : '#069fff'
          }
          setCurrentCarouselIndex={setCurrentCarouselIndex}
        >
          {input.fields.map(section => renderContent(section, prepareVideoModal))}
        </Carousel>
        {currentWistiaVideoId &&
          renderVideoModal(currentWistiaVideoId, modalIsShowing, setModalIsShowing, setCurrentWistiaVideoId)}
      </BulmaSection>
    </>
  );
};

export default HeroCarouselV2;

HeroCarouselV2.propTypes = {
  input: PropTypes.object.isRequired,
};
