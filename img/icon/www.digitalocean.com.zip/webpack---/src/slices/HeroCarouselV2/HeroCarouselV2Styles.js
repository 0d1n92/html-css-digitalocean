// Styles here will override Bulma styles
import { css } from '@emotion/core';
import styled from '@emotion/styled';
import media from 'css-in-js-media';

export const styledHeroCarouselV2Section = css`
  display: flex;
  flex-direction: column;

  justify-content: center;
  align-items: center;
  padding-top: 40px;
  padding-bottom: 60px;
  background-repeat: repeat;

  @media screen and (max-width: 425px) {
    #carousel {
      margin-top: 0px;
    }

    padding-top: 24px !important;
    height: calc(100vh - 150px) !important;
  }

  @media screen and (max-width: 374px) {
    height: calc(100vh - 60px) !important;
    padding-top: 32px !important;
    padding-bottom: 68px !important;
    margin-top: -54px;
  }

  .draggable {
    display: flex;
    align-items: center !important;
  }
`;

export const styledHeading = css`
  line-height: 120%;

  ${media('< desktop')} {
    &.hero-title {
      font-size: 31px !important;
    }

    &.title {
      font-size: 31px !important;
    }

    width: 80%;
    margin: auto !important;
    text-align: center !important;
  }

  @media screen and (max-width: 375px) {
    font-size: 22px !important;
  }
`;

export const styledSubHeading = css`
  width: 90%;
  ${media('< desktop')} {
    width: 80%;
    margin: auto !important;
    text-align: center !important;
  }

  @media screen and (max-width: 375px) {
    font-size: 18px !important;
  }
`;

export const styledHeroCarouselV2Content = css`
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  margin-left: 32px !important;

  ${media('< tablet')} {
    margin-bottom: 32px !important;
  }

  div {
    align-items: flex-start !important;
  }
`;

export const styledButtonContainer = css`
  margin-top: 32px;

  a {
    margin-right: 24px !important;
    align-items: center;
  }

  div {
    margin-top: 0;
    align-items: center;
  }

  ${media('< desktop')} {
    justify-content: center;
    flex-direction: column;

    a {
      margin: auto !important;
      align-items: center;
    }

    div {
      margin-top: 26px;
    }
  }
`;

export const styledModal = css`
  margin: auto;
  border-radius: 3px;
  max-width: 80%;

  ${media('< desktop')} {
    max-width: 95%;
  }

  div:only-child {
    margin: 0 auto;
    width: 100%;
    height: 100%;
    border-radius: 3px;
  }
`;

export const StyledMainContent = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-around;
  margin-bottom: 32px;
  padding: 0 32px;

  ${media('< desktop')} {
    flex-direction: column;
    justify-content: center;
    align-items: center;
  }

  ${media('< tablet')} {
    margin-bottom: 24px;
  }
`;

export const StyledCopy = styled.div``;

export const styledRightSideContent = css`
  background: none;
  color: inherit;
  border: none;
  padding: 0;
  font: inherit;
  cursor: pointer;
  outline: inherit;

  margin-left: 32px;
  position: relative;

  &:hover {
    cursor: pointer;
  }

  .play {
    display: inline-block;
    padding: 25px;
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
  }

  ${media('< desktop')} {
    margin-left: auto;
    margin-right: auto;

    .play {
      display: none;
    }
  }
`;

export const styledImage = css`
  img {
    max-width: 525px;
  }

  ${media('< desktop')} {
    display: none;
    img {
      margin-top: 32px;
      max-width: 320px;
    }
  }
`;

export const styledVideoContainer = css`
  position: relative;
  overflow: hidden;
  border-radius: 10px;

  img {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }

  .after {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    display: block;
    color: #0314be;
    background: rgba(3, 27, 78, 0.8);
  }

  ${media('< desktop')} {
    display: none;
    margin-top: 32px;
    max-width: 320px;
    max-height: 340px;
  }
`;

export const styledLogo = css`
  display: flex;
  max-width: 240px;

  ${media('< desktop')} {
    margin: 32px auto !important;
  }

  ${media('< tablet')} {
    max-width: 160px;
  }
`;

export const styledVideoPlayMobile = css`
  display: none;

  ${media('< desktop')} {
    display: block;
  }
`;
