/* eslint-disable camelcase */
import React from 'react';
import PropTypes from 'prop-types';

import BulmaSection from 'react-bulma-components/lib/components/section';

import { css } from '@emotion/core';
import { createRandomId } from '../../util/createRandomId';

import { Card, SlidingTabsContainer, SlidingTab, Heading, LazyLink } from '../atoms';

import { styledHeading, styledSubheading, styledCards } from './LeftSlidingNavCardsStyles';

const renderCard = card => {
  const { image, title1, title_color, text, text_color, link } = card;
  return (
    <Card
      image={image && image.url ? image : null}
      title={title1 && title1[0] && title1[0].text ? title1 : null}
      title_color={title_color}
      text={text && text[0] ? text : null}
      text_color={text_color}
      link={link}
      key={createRandomId()}
      renderAs={LazyLink}
      url={link && link.url ? link.url : null}
    />
  );
};

const LeftSlidingNavCards = ({ input }) => {
  const {
    background_image,
    background_color,
    text_color,
    cta_button_text,
    cta_button_link,
    cta_button_color,
  } = input.primary;

  return (
    <BulmaSection
      css={css`
        background-image: url(${background_image ? background_image.url : ''});
        background-color: ${background_color};
      `}
    >
      <SlidingTabsContainer
        text_color={text_color}
        button_text={cta_button_text}
        button_link={cta_button_link}
        button_color={cta_button_color}
      >
        {input.fields.map(item => (
          <SlidingTab key={`tabbed-content-${item.heading[0].text}`} label={item.heading[0].text}>
            <Heading
              id="testLeftSlidingNavHeading"
              css={styledHeading}
              style={item.heading_color ? { color: item.heading_color } : null}
              className={text_color === 'light' ? 'h2 grey light' : 'h2 darkblue light'}
              renderAs="h2"
            >
              {item.heading[0].text}
            </Heading>
            <Heading
              id="testLeftSlidingNavSubheading"
              style={item.subheading_color ? { color: item.subheading_color } : null}
              subtitle
              className={text_color === 'light' ? 'white medium' : 'darkgrey medium'}
              renderAs="p"
              css={styledSubheading}
            >
              {item.subheading[0].text}
            </Heading>
            <div
              id="testCards"
              css={styledCards}
              style={{
                gridTemplateColumns: `repeat(3, minmax(220px, 1fr))`,
              }}
            >
              {item.card_1_title || item.card_1_image
                ? renderCard({
                    image: item.card_1_image,
                    title1: item.card_1_title,
                    link: item.card_1_link,
                    text: item.card_1_copy,
                  })
                : null}
              {item.card_2_title || item.card_2_image
                ? renderCard({
                    image: item.card_2_image,
                    title1: item.card_2_title,
                    link: item.card_2_link,
                    text: item.card_2_copy,
                  })
                : null}
              {item.card_3_title || item.card_3_image
                ? renderCard({
                    image: item.card_3_image,
                    title1: item.card_3_title,
                    link: item.card_3_link,
                    text: item.card_3_copy,
                  })
                : null}
              {item.card_4_title || item.card_4_image
                ? renderCard({
                    image: item.card_4_image,
                    title1: item.card_4_title,
                    link: item.card_4_link,
                    text: item.card_4_copy,
                  })
                : null}
              {item.card_5_title || item.card_5_image
                ? renderCard({
                    image: item.card_5_image,
                    title1: item.card_5_title,
                    link: item.card_5_link,
                    text: item.card_5_copy,
                  })
                : null}
              {item.card_6_title || item.card_6_image
                ? renderCard({
                    image: item.card_6_image,
                    title1: item.card_6_title,
                    link: item.card_6_link,
                    text: item.card_6_copy,
                  })
                : null}
              {item.card_7_title || item.card_7_image
                ? renderCard({
                    image: item.card_7_image,
                    title1: item.card_7_title,
                    link: item.card_7_link,
                    text: item.card_7_copy,
                  })
                : null}
              {item.card_8_title || item.card_8_image
                ? renderCard({
                    image: item.card_8_image,
                    title1: item.card_8_title,
                    link: item.card_8_link,
                    text: item.card_8_copy,
                  })
                : null}
              {item.card_9_title || item.card_9_image
                ? renderCard({
                    image: item.card_9,
                    title1: item.card_9,
                    link: item.card_9_link,
                    text: item.card_9_copy,
                  })
                : null}
            </div>
          </SlidingTab>
        ))}
      </SlidingTabsContainer>
    </BulmaSection>
  );
};

export default LeftSlidingNavCards;

LeftSlidingNavCards.propTypes = {
  input: PropTypes.object.isRequired,
};
