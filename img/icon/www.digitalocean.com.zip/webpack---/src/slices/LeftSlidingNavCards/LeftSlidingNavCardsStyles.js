import { css } from '@emotion/core';
import media from 'css-in-js-media';

export const styledHeading = css`
  margin: 0 0 0 0 !important;
  text-align: left;
  ${media('< desktop')} {
    text-align: center;
  }
`;

export const styledSubheading = css`
  margin-top: 20px !important;
  margin-bottom: 32px !important;
  max-width: 100% !important;

  ${media('< desktop')} {
    text-align: center;
    margin: 20px auto 0 auto !important;
  }
`;

export const styledCards = css`
  display: grid;
  grid-auto-flow: dense;
  grid-auto-rows: 1fr;
  grid-gap: 32px;
  margin-bottom: 120px;
  margin-top: 32px;

  a {
    text-decoration: none;
  }

  img {
    max-height: 35px;
    max-width: 200px;
  }

  .title {
    margin-bottom: 10px !important;
  }

  p {
    margin-bottom: 0;
  }

  div {
    ${media('<= desktop')} {
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      text-align: center;
    }
  }

  ${media('< desktop')} {
    display: flex;
    flex-direction: column;
    margin-left: 0px;
    margin-right: 0px;
    margin-bottom: 64px;
  }
`;

// export const styledCardContent = css`
//   position: relative;
//   height: 100%;
//   flex: 1;

//   img {
//     max-height: 35px;
//     max-width: 220px;
//   }

// .title {
//   margin-bottom: 10px !important;
// }

// p {
//   margin-bottom: 0;
// }

//   a {
//     text-decoration: none;
//   }

// ${media('<= desktop')} {
//   display: flex;
//   flex-direction: column;
//   justify-content: center;
//   align-items: center;
//   text-align: center;
// }
// `;

export const styledButton = css`
  margin-top: 60px;
  margin-bottom: 40px;
`;
