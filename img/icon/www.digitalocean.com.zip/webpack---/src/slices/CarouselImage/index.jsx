/* eslint-disable camelcase */
import React from 'react';
import PropTypes from 'prop-types';

import BulmaSection from 'react-bulma-components/lib/components/section';

import { css } from '@emotion/core';
import { Carousel, Heading, LazyImage } from '../atoms';
import {
  styledSubHeading,
  styledHeroCarouselSection,
  styledImage,
  styledImageContainer,
  StyledImageText,
  StyledCarouselWrapper,
} from './CarouselImageStyles';
import { createRandomId } from '../../util/createRandomId';

const CarouselImage = ({ input }) => {
  const {
    background_color,
    background_image,
    text_color,
    heading,
    heading_color,
    subheading,
    subheading_color,
  } = input.primary;

  return (
    <BulmaSection
      css={css`
        ${styledHeroCarouselSection}
        ${background_image ? `background-image: url(${background_image.url});` : null};
        background-color: ${background_color};
      `}
    >
      {heading && heading[0].text && (
        <Heading
          renderAs="h1"
          className={text_color === 'light' ? 'h2 white' : 'h2 darkblue'}
          css={css`
            color: ${heading_color} !important;
          `}
        >
          {heading[0].text}
        </Heading>
      )}
      {subheading && subheading[0].text && (
        <Heading
          renderAs="p"
          subtitle
          className={text_color === 'light' ? 'medium grey' : 'medium darkblue'}
          css={css`
          ${styledSubHeading}
          color: ${subheading_color} !important;
        `}
        >
          {subheading[0].text}
        </Heading>
      )}
      <StyledCarouselWrapper>
        <Carousel
          fadeIn
          text_color={text_color}
          selectColor={text_color === 'light' ? '#fff' : '#0069ff'}
          id="testCarouselImage"
          arrowType="chevron"
        >
          {input.fields.map((field, index) => (
            <div css={styledImageContainer} key={`CarouselImage-${createRandomId()}`}>
              <LazyImage css={styledImage} src={field.image.url} />
              <StyledImageText
                id={`testCarouselImageImage-${index}`}
                className={text_color === 'light' ? 'white' : 'darkgray'}
                css={css`
                  color: ${field.image_text_color} !important;
                `}
              >
                {field.image_text[0].text}
              </StyledImageText>
            </div>
          ))}
        </Carousel>
      </StyledCarouselWrapper>
    </BulmaSection>
  );
};

export default CarouselImage;

CarouselImage.propTypes = {
  input: PropTypes.object.isRequired,
};
