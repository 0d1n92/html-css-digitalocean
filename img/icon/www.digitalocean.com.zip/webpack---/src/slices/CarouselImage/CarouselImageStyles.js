// Styles here will override Bulma styles
import { css } from '@emotion/core';
import styled from '@emotion/styled';

export const styledHeroCarouselSection = css`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  text-align: center;
`;

export const styledSubHeading = css`
  text-align: center;
`;

export const styledImageContainer = css`
  display: flex;
  flex-direction: column;
  align-items: start;
`;
export const styledImage = css`
  width: 80%;
  margin: 0 auto;
  border-radius: 5px;
  box-shadow: 0 2px 4px rgba(3, 27, 78, 0.06);
`;
export const StyledImageText = styled.p`
  text-align: center;
  width: 80%;
  margin: 32px auto 0 auto;
  &.white {
    color: #fff;
  }
  &.darkblue {
    color: #031b4e;
  }
`;

export const StyledCarouselWrapper = styled.div`
  max-width: 100%;
`;
