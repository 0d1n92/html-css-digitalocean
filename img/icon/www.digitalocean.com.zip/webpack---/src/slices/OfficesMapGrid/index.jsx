/* eslint-disable camelcase */
import React, { useState } from 'react';
import PropTypes from 'prop-types';
import Media from 'react-media';

import BulmaContainer from 'react-bulma-components/lib/components/container';
import BulmaSection from 'react-bulma-components/lib/components/section';
import BulmaImage from 'react-bulma-components/lib/components/image';

import mapMarker from '../../assets/images/map-marker.svg';

import { Heading, Map, LazyImage } from '../atoms';

import {
  styledOfficesMapGridContainer,
  styledLocationWrapper,
  styledLocationWrapperMobile,
  StyledLocation,
  StyledLocationMobile,
  styledDownArrow,
  styledLocationImage,
  StyledLocationContentMobile,
  StyledLocationDetails,
  StyledLocationDetailsMobile,
  StyledLocationIcon,
  styledLocationName,
  StyledLocationAddress,
  StyledMapContainer,
} from './OfficesMapGridStyles';

const renderHeading = (text, heading_color, atts) => (
  <Heading {...atts} style={heading_color ? { color: heading_color } : null}>
    {text}
  </Heading>
);

const OfficesMapGrid = ({ input }) => {
  const {
    background_color,
    background_image,
    heading,
    heading_color,
    subheading,
    subheading_color,
    text_color,
    google_api_key,
  } = input.primary;

  const RenderLocationContent = mediaSize => {
    // create state for current location selected to use on google map
    const [currentLocation, setCurrentLocation] = useState({
      index: 0,
      lat: `${input.fields[0].location_latitude}`,
      lng: `${input.fields[0].location_longitude}`,
    });

    // This is used to enable defaultMatches for react-media Media SSR issues
    const [isMedia] = useState('mobile');

    return (
      <Media
        queries={mediaSize === 'desktop' ? { medium: '(min-width: 1025px)' } : { medium: '(max-width: 1025px)' }}
        defaultMatches={mediaSize === 'desktop' ? { medium: isMedia === 'desktop' } : { medium: isMedia === 'mobile' }}
        render={() => (
          <>
            <div css={mediaSize === 'desktop' ? styledLocationWrapper : styledLocationWrapperMobile}>
              {input.fields.map((item, index) => {
                const { location_address, location_image, location_latitude, location_longitude, location_name } = item;
                // Return content for desktop or mobile
                return mediaSize === 'desktop' ? (
                  <StyledLocation
                    css={index === currentLocation.index ? styledDownArrow : null}
                    key={location_name}
                    tabIndex={index}
                    onClick={() => setCurrentLocation({ index, lat: location_latitude, lng: location_longitude })}
                    onKeyPress={() => setCurrentLocation({ index, lat: location_latitude, lng: location_longitude })}
                  >
                    <BulmaImage
                      css={styledLocationImage}
                      src={location_image && location_image.url}
                      alt={location_image && location_image.alt}
                    />
                    <StyledLocationDetails>
                      {location_name
                        ? renderHeading(location_name, '', {
                            className: 'h5 darkblue',
                            renderAs: 'h5',
                            css: styledLocationName,
                          })
                        : null}
                      <StyledLocationAddress>{location_address || null}</StyledLocationAddress>
                    </StyledLocationDetails>
                  </StyledLocation>
                ) : (
                  <StyledLocationMobile
                    key={location_name}
                    tabIndex={index}
                    url={`https://www.google.com/maps/place/${location_latitude},${location_longitude}`}
                  >
                    <BulmaImage
                      css={styledLocationImage}
                      src={location_image && location_image.url}
                      alt={location_image && location_image.alt}
                    />
                    <StyledLocationContentMobile>
                      <StyledLocationDetailsMobile>
                        {location_name
                          ? renderHeading(location_name, '', {
                              className: 'h5 darkblue',
                              renderAs: 'h5',
                              css: styledLocationName,
                            })
                          : null}
                        <StyledLocationAddress>{location_address || null}</StyledLocationAddress>
                      </StyledLocationDetailsMobile>
                      <StyledLocationIcon>
                        <LazyImage src={mapMarker} alt="map marker icon" />
                      </StyledLocationIcon>
                    </StyledLocationContentMobile>
                  </StyledLocationMobile>
                );
              })}
            </div>
            {mediaSize === 'desktop' ? (
              <div>
                <Map
                  lat={parseFloat(currentLocation.lat)}
                  lng={parseFloat(currentLocation.lng)}
                  isMarkerShown
                  googleAPIKey={google_api_key}
                />
              </div>
            ) : null}
          </>
        )}
      />
    );
  };

  return (
    <BulmaSection
      style={
        background_image && background_image.url
          ? { backgroundImage: `url(${background_image.url})` }
          : { backgroundColor: `${background_color}` }
      }
    >
      <BulmaContainer css={styledOfficesMapGridContainer}>
        {heading && heading[0]
          ? renderHeading(heading[0].text, heading_color, {
              id: 'testOfficesMapGrid-heading',
              className: `${text_color === 'light' ? 'h2 white' : 'h2 darkblue'}`,
              renderAs: 'h2',
            })
          : null}
        {subheading && subheading[0]
          ? renderHeading(subheading[0].text, subheading_color, {
              id: 'testOfficesMapGrid-subheading',
              renderAs: 'p',
              subtitle: true,
              className: `${text_color === 'light' ? 'medium white' : 'medium darkgrey'}`,
            })
          : null}

        <StyledMapContainer>
          {/* conditionally render desktop or mobile content */}
          {RenderLocationContent('desktop')}
          {RenderLocationContent('mobile')}
        </StyledMapContainer>
      </BulmaContainer>
    </BulmaSection>
  );
};

export default OfficesMapGrid;

OfficesMapGrid.propTypes = {
  input: PropTypes.object.isRequired,
};
