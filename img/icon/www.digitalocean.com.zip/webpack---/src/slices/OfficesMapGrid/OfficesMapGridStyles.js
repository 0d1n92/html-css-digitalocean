// Styles here will override Bulma styles
import styled from '@emotion/styled';
import { css } from '@emotion/core';
import media from 'css-in-js-media';

import { LazyLink } from '../atoms';

export const styledOfficesMapGridContainer = css`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  margin-top: 40px;

  ${media('< desktop')} {
    h2,
    p {
      margin-left: 20px;
      margin-right: 20px;
      text-align: center;
    }
  }
`;

export const StyledMapContainer = styled.div`
  max-width: 1168px;
  margin-top: 65px;
  margin-bottom: 120px;
  z-index: 0;
`;

export const styledLocationWrapper = css`
  display: flex;
  background: #fff;
  border-top-left-radius: 5px;
  border-top-right-radius: 5px;
  position: relative;
  z-index: 100;

  button:first-of-type {
    border-top-left-radius: 5px;
    img {
      border-top-left-radius: 5px;
    }
  }

  button:last-of-type {
    border-top-right-radius: 5px;
    img {
      border-top-right-radius: 5px;
    }
  }
`;

export const styledLocationWrapperMobile = css`
  display: flex;
  flex-direction: column;

  img {
    border-top-left-radius: 5px;
    border-top-right-radius: 5px;
  }

  :hover {
    background-color: #fff !important;
  }
`;

export const StyledLocation = styled.button`
  box-shadow: 0 4px 10px rgba(3, 27, 78, 0.06);
  transition: opacity 0.25s linear, transform 0.25s linear, -webkit-transform 0.25s linear;
  padding: 0;
  border: none;
  cursor: pointer;
  position: relative;
  background: #fff;

  &:focus {
    outline: none;
  }

  :hover {
    box-shadow: 0 10px 18px rgba(3, 27, 78, 0.15);
  }

  &::after {
    content: '';
    border-left: 12px solid transparent;
    border-right: 12px solid transparent;
    border-top: 12px solid #fff;
    display: block;
    height: 0;
    position: absolute;
    transition: opacity 0.25s linear, transform 0.25s linear;
    width: 0;
    z-index: 3;
    left: 49%;
    opacity: 0;
    bottom: 0;
  }
`;

export const StyledLocationMobile = styled(LazyLink)`
  box-shadow: 0 4px 10px rgba(3, 27, 78, 0.06);
  transition: opacity 0.25s linear, transform 0.25s linear, -webkit-transform 0.25s linear;
  padding: 0;
  border: none;
  cursor: pointer;
  position: relative;
  background: #fff;
  margin: 15px 0;
  border-radius: 5px;

  &:focus {
    outline: none;
  }

  :hover {
    box-shadow: 0 10px 18px rgba(3, 27, 78, 0.15);
  }

  p {
    text-align: left;
    margin: 0;
    color: #005fe6;
  }
`;

export const StyledLocationIcon = styled.div`
  width: 50px;
  height: 50px;
  border-radius: 50%;
  background-color: #f2f8ff;
  margin: 24px 28px 24px 32px;

  img {
    width: 24px;
    height: 24px;
    margin: 12px 0 0 13px;
  }
`;

export const styledDownArrow = css`
  box-shadow: 0 10px 18px rgba(3, 27, 78, 0.15);

  &::after {
    content: '';
    bottom: -10px;
    transform: translateY(12%) scale(1);
    opacity: 1;
  }
`;

export const styledLocationImage = css`
  margin: 0;
`;

export const StyledLocationContentMobile = styled.div`
  display: flex;
  justify-content: space-between;
`;

export const StyledLocationDetails = styled.div`
  border-left: 1px solid rgba(3, 27, 78, 0.1);
  border-right: 1px solid rgba(3, 27, 78, 0.1);
  padding: 24px 8px 24px 32px;
`;

export const StyledLocationDetailsMobile = styled.div`
  padding: 30px 8px 24px 32px;
`;

export const styledLocationName = css`
  margin: 0;
  text-align: left;
`;

export const StyledLocationAddress = styled.p`
  margin: 0;
  text-align: left;
`;
