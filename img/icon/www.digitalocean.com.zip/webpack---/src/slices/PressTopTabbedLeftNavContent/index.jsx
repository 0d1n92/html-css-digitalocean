/* eslint-disable camelcase */
import React from 'react';
import PropTypes from 'prop-types';

import BulmaSection from 'react-bulma-components/lib/components/section';

import { css } from '@emotion/core';

import { Tab, TabsContainer, TextLink, Heading, Button, LazyLink } from '../atoms';

import {
  styledLink,
  styledLeftTabContent,
  styledHeading,
  styledButton,
  StyledContent,
} from './PressTopTabbedLeftNavContentStyles';
import { TopTabContainer } from '../atoms/Tabs/TopTabNav';
import { renderCompanyDate } from '../atoms/CompanyDate';

const renderLinks = (year, topTabArticles, currentTab, defaultTextColor) => {
  const items = [];
  topTabArticles
    .sort((article1, article2) => new Date(article2.date1) - new Date(article1.date1))
    .forEach(article => {
      if (
        article.top_tab_relation.toLowerCase() === currentTab.toLowerCase() &&
        year === article.year &&
        items.length <= 7
      ) {
        items.push(
          <>
            <TextLink
              style={{ color: defaultTextColor === 'light' ? '#fff' : '#031b4e' }}
              css={styledLink}
              url={article.link_url && article.link_url.url}
            >
              {article.link_text}
            </TextLink>
            {renderCompanyDate(article.company, article.date1, '#fff')}
          </>,
        );
      }
    });

  return items;
};

const renderContent = (topTabArticles, topTabNavList, currentTab, defaultTextColor) => (
  <StyledContent>
    <div css={styledLeftTabContent}>
      <TabsContainer data-testid="top_tab_container">
        {Object.keys(topTabNavList.find(obj => obj.name === currentTab).years)
          .sort((year1, year2) => parseInt(year2, 10) - parseInt(year1, 10))
          .map(year => (
            <Tab content={renderLinks(year, topTabArticles, currentTab, defaultTextColor)} label={year} />
          ))}
      </TabsContainer>
    </div>
    <Button
      css={styledButton}
      renderAs={LazyLink}
      className="is-primary is-outlined"
      url={
        currentTab && currentTab.toLowerCase() === 'press releases'
          ? 'https://digitalocean.com/press/releases'
          : 'https://digitalocean.com/press/in-the-news'
      }
    >
      Read All
    </Button>
  </StyledContent>
);

const PressTopTabbedLeftNavContent = ({ input }) => {
  const {
    heading,
    heading_color,
    background_image,
    background_color,
    text_color,
    top_tab_1,
    top_tab_2,
  } = input.primary;
  const topTabNavList = [
    {
      name: `${top_tab_1 && top_tab_1[0].text}`,
      years: {},
    },
    {
      name: `${top_tab_2 && top_tab_2[0].text}`,
      years: {},
    },
  ];
  const getTopTabsRelatedItems = tab => {
    const currentTabObj = topTabNavList.find(tabItem => tabItem.name.toLowerCase() === tab.toLowerCase());
    input.fields.forEach(item => {
      if (item.top_tab_relation.toLowerCase() === tab.toLowerCase()) {
        if (item.year && !currentTabObj.years[item.year]) {
          currentTabObj.years[item.year] = true;
        }
      }
    });
    const filteredItems = input.fields.filter(item => item.top_tab_relation.toLowerCase() === tab.toLowerCase());
    return filteredItems;
  };
  return (
    <BulmaSection
      css={css`
        background-image: url(${background_image ? background_image.url : ''});
        background-color: ${background_color};
      `}
    >
      {heading && heading[0] ? (
        <Heading
          css={styledHeading}
          style={heading_color ? { color: heading_color } : null}
          className="h2 darkblue"
          renderAs="h2"
        >
          {heading[0].text}
        </Heading>
      ) : null}
      <TopTabContainer>
        {topTabNavList.map(tab => (
          <Tab
            label={tab.name}
            content={[renderContent(getTopTabsRelatedItems(tab.name), topTabNavList, tab.name, text_color)]}
          />
        ))}
      </TopTabContainer>
    </BulmaSection>
  );
};
export default PressTopTabbedLeftNavContent;
PressTopTabbedLeftNavContent.propTypes = {
  input: PropTypes.object.isRequired,
};
