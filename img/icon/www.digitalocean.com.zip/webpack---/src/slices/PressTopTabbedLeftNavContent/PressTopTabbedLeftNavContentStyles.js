import { css } from '@emotion/core';
import media from 'css-in-js-media';
import styled from '@emotion/styled';

export const styledHeading = css`
  text-align: center;
  margin-left: auto;
  margin-right: auto;
  margin-bottom: 40px !important;
  font-size: 1.7rem;
  margin-top: 10px !important;
`;

export const styledSubheading = css`
  margin-top: 20px !important;
  ${media('> tablet')} {
    margin-bottom: 40px !important;
  }
`;

export const styledLink = css`
  font-size: 16px;
  font-family: 'Sailec-Regular', 'Helvetica', 'sans-serif';
  text-decoration: none !important;
  font-style: normal !important;
  cursor: pointer;

  ${media('< desktop')} {
    margin-top: 10px;
  }
`;

export const styledLeftTabContent = css`
  margin-top: 60px;

  .is-3 {
    margin-left: 90px;
    width: 14% !important;
  }

  .tab-container {
    display: flex !important;
    flex-direction: column;
  }

  .company-date {
    justify-content: flex-start !important;
  }

  ${media('< tablet')} {
    .is-3 {
      margin-left: auto;
      margin-top: -50px;
      width: auto !important;
    }

    .company-date {
      justify-content: center !important;
    }
  }
`;

export const styledButton = css`
  margin: 40px auto;
`;

export const StyledContent = styled.div`
  display: flex;
  flex-direction: column;
`;
