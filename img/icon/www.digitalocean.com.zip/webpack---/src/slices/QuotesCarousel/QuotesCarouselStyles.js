import styled from '@emotion/styled';
import { css } from '@emotion/core';
import media from 'css-in-js-media';
import arrow from '../../assets/images/arrow-green.svg';

import { LazyLink } from '../atoms';

export const styledSection = css`
  padding-left: 0;
  padding-right: 0;
`;

export const styledLogo = css`
  img {
    position: absolute;
    top: 55px;
    right: 260px;
    width: 130px;
    height: 130px;
    border-radius: 50%;
    box-shadow: 0px 10px 30px rgba(3, 27, 78, 0.05);
    z-index: 10;
    object-fit: cover;
    background-color: #fff;

    ${media('< desktop')} {
      width: 100px;
      height: 100px;
      top: 0px;
      left: 50%;
      margin-left: -50px;
    }
  }
`;

export const styledPhoto = css`
  img {
    position: absolute;
    top: 55px;
    right: 20px;
    width: 370px;
    height: 370px;
    border: 6px solid #ffffff;
    box-sizing: border-box;
    box-shadow: 0px 20px 60px rgba(1, 14, 40, 0.1);
    border-radius: 50%;
    z-index: 9;
    object-fit: cover;

    ${media('< desktop')} {
      display: none !important;
    }
  }
`;

export const StyledContent = styled.div`
  position: absolute;
  top: 90px;
  left: 50px;
  display: contents;

  p {
    font-family: 'Sailec-Bold', 'Helvetica', 'sans-serif';
    color: #fff;
  }
`;

export const StyledName = styled.p`
  margin: 120px 0 20px 0;
  font-size: 12px;
  line-height: 15px;
  letter-spacing: 2px;
  text-transform: uppercase;
  opacity: 0.8;
`;

export const styledQuote = css`
  margin-bottom: 30px !important;
  margin-left: 0;
  max-width: 700px;
`;

export const StyledLink = styled(LazyLink)`
  font-family: 'Sailec-Bold', 'Helvetica', 'sans-serif';
  font-weight: 500;
  font-size: 16px;
  line-height: 20px;
  color: #fff;
  position: relative;

  ${media('< desktop')} {
    margin: auto;
  }

  :after {
    background: url(${arrow}) no-repeat 0 0;
    background-size: 24px;
    content: '';
    height: 24px;
    margin-top: -12px;
    position: absolute;
    right: -35px;
    top: 50%;
    width: 24px;
    transition: all 0.3s ease;
  }

  :hover {
    color: #fff !important;
    opacity: 0.8;

    &:after {
      right: -40px;
    }
  }
`;

export const StyledBlockQuotesCarousel = styled.div`
  max-width: 2000;
  height: auto;

  ${media('< tablet')} {
    background-image: none !important;
  }

  .columns {
    display: flex !important;
    ${media('< tablet')} {
      flex-direction: column;
      width: 90vw !important;
      margin: 0 auto;
    }
  }

  .slick-list,
  .slick-slider,
  .slick-track {
    position: relative;
    display: block;
  }
  .slick-loading .slick-slide,
  .slick-loading .slick-track {
    visibility: hidden;
  }
  .slick-slider {
    box-sizing: border-box;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
    -webkit-touch-callout: none;
    -khtml-user-select: none;
    -ms-touch-action: pan-y;
    touch-action: pan-y;
    -webkit-tap-highlight-color: transparent;
  }
  .slick-list {
    overflow: hidden;
    margin: 0;
    padding: 0;
  }
  .slick-list:focus {
    outline: 0;
  }
  .slick-list.dragging {
    cursor: pointer;
    cursor: hand;
  }
  .slick-slider .slick-list,
  .slick-slider .slick-track {
    -webkit-transform: translate3d(0, 0, 0);
    -moz-transform: translate3d(0, 0, 0);
    -ms-transform: translate3d(0, 0, 0);
    -o-transform: translate3d(0, 0, 0);
    transform: translate3d(0, 0, 0);
  }
  .slick-track {
    top: 0;
    left: 0;
  }
  .slick-track:after,
  .slick-track:before {
    display: table;
    content: '';
  }
  .slick-track:after {
    clear: both;
  }
  .slick-slide {
    display: none;
    float: left;
    height: 100%;
    min-height: 1px;
    div div {
      outline: none;
    }
  }
  [dir='rtl'] .slick-slide {
    float: right;
  }
  .slick-slide img {
    display: block;
  }
  .slick-slide.slick-loading img {
    display: none;
  }
  .slick-slide.dragging img {
    pointer-events: none;
  }
  .slick-initialized .slick-slide {
    display: block;
  }
  .slick-vertical .slick-slide {
    display: block;
    height: auto;
    border: 1px solid transparent;
  }
  .slick-arrow.slick-hidden {
    display: none;
  }
  .slick-dots,
  .slick-next,
  .slick-prev {
    position: absolute;
    display: block;
    padding: 0;
  }
  .slick-dots li button:before,
  .slick-next:before,
  .slick-prev:before {
    font-family: slick;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
  }
  .slick-loading .slick-list {
    background: url(ajax-loader.gif) center center no-repeat #fff;
  }
  .slick-next,
  .slick-prev {
    font-size: 0;
    line-height: 0;
    top: 50%;
    width: 20px;
    height: 20px;
    -webkit-transform: translate(0, -50%);
    -ms-transform: translate(0, -50%);
    transform: translate(0, -50%);
    cursor: pointer;
    color: transparent;
    border: none;
    outline: 0;
    background: 0 0;
  }
  .slick-next:focus,
  .slick-next:hover,
  .slick-prev:focus,
  .slick-prev:hover {
    color: transparent;
    outline: 0;
    background: 0 0;
  }
  .slick-next:focus:before,
  .slick-next:hover:before,
  .slick-prev:focus:before,
  .slick-prev:hover:before {
    opacity: 1;
  }
  .slick-next.slick-disabled:before,
  .slick-prev.slick-disabled:before {
    opacity: 0.25;
  }
  .slick-next:before,
  .slick-prev:before {
    font-size: 20px;
    line-height: 1;
    opacity: 0.75;
    color: #fff;
  }
  .slick-prev {
    left: -25px;
  }
  [dir='rtl'] .slick-prev {
    right: -25px;
    left: auto;
  }
  .slick-prev:before {
    content: 'â†';
  }
  .slick-next:before,
  [dir='rtl'] .slick-prev:before {
    content: 'â†’';
  }
  .slick-next {
    right: -25px;
  }
  [dir='rtl'] .slick-next {
    right: auto;
    left: -25px;
  }
  [dir='rtl'] .slick-next:before {
    content: 'â†';
  }
  .slick-dotted.slick-slider {
    margin-bottom: 30px;
  }
  .slick-dots {
    bottom: -25px;
    width: 100%;
    margin: 0;
    list-style: none;
    text-align: center;
  }
  .slick-dots li {
    position: relative;
    display: inline-block;
    width: 20px;
    height: 20px;
    margin: 0;
    padding: 0;
    cursor: pointer;
  }
  .slick-dots li button {
    font-size: 0;
    line-height: 0;
    display: block;
    width: 20px;
    height: 20px;
    padding: 5px;
    cursor: pointer;
    color: transparent;
    border: 0;
    outline: 0;
    background: 0 0;
  }
  .slick-dots li button:focus,
  .slick-dots li button:hover {
    outline: 0;
  }
  .slick-dots li button:focus:before,
  .slick-dots li button:hover:before {
    opacity: 1;
  }
  .slick-dots li button:before {
    font-size: 30px;
    line-height: 20px;
    position: absolute;
    top: 0;
    left: 0;
    width: 20px;
    height: 20px;
    content: '•';
    text-align: center;
    opacity: 0.25;
    color: #fff;
  }
  .slick-dots li.slick-active button:before {
    opacity: 0.75;
    color: #fff;
  }
  .slick-list,
  .slick-slider {
    height: 486px;
  }
`;
