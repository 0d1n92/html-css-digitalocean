/* eslint-disable camelcase */
import React from 'react';
import PropTypes from 'prop-types';

import Slider from 'react-slick';

import BulmaImage from 'react-bulma-components/lib/components/image';
import BulmaSection from 'react-bulma-components/lib/components/section';
import BulmaColumns from 'react-bulma-components/lib/components/columns';

import { Heading } from '../atoms';

import {
  styledSection,
  StyledBlockQuotesCarousel,
  styledLogo,
  styledPhoto,
  StyledContent,
  StyledName,
  styledQuote,
  StyledLink,
} from './QuotesCarouselStyles';

const renderImage = (image, atts) => <BulmaImage {...atts} src={image.url} />;

const renderCarouselSlide = slide => {
  const { name_and_position, logo, photo, quote, link } = slide;

  return (
    <BulmaColumns key={name_and_position.text}>
      <BulmaColumns.Column>
        {renderImage(logo, { css: styledLogo })}
        {renderImage(photo, { css: styledPhoto })}
      </BulmaColumns.Column>
      <BulmaColumns.Column>
        <StyledContent>
          <StyledName>{name_and_position[0].text}</StyledName>
          <Heading css={styledQuote} className="h3 white" renderAs="h3">
            {quote[0].text}
          </Heading>
          {link && link.url ? <StyledLink url={link.url}>Read case study</StyledLink> : null}
        </StyledContent>
      </BulmaColumns.Column>
    </BulmaColumns>
  );
};

const QuotesCarousel = ({ input }) => {
  const { background_image } = input.primary;

  const settings = {
    arrows: false,
    autoplay: false,
    dots: true,
    infinite: true,
    autoplayspeed: 2000,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
  };

  const backgroundImage = `#0069ff url(${background_image.url}) no-repeat center center`;

  return (
    <BulmaSection css={styledSection} style={{ background: backgroundImage, backgroundSize: 'cover' }}>
      <StyledBlockQuotesCarousel>
        <Slider {...settings}>{input.fields.map(slide => renderCarouselSlide(slide))}</Slider>
      </StyledBlockQuotesCarousel>
    </BulmaSection>
  );
};

export default QuotesCarousel;

QuotesCarousel.propTypes = {
  input: PropTypes.object.isRequired,
};
