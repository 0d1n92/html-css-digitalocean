/* eslint-disable camelcase */
import React from 'react';
import PropTypes from 'prop-types';

import BulmaColumns from 'react-bulma-components/lib/components/columns';
import BulmaContainer from 'react-bulma-components/lib/components/container';
import BulmaSection from 'react-bulma-components/lib/components/section';

import { css } from '@emotion/core';

import { Heading, LargeImgWithSideContent } from '../atoms';
import { createRandomId } from '../../util/createRandomId';

import {
  styledHeading,
  styledListAlternating,
  styledContainerHeading,
  styledSubheading,
  styledContentWrapper,
} from './ListAlternatingStyles';

const renderHeading = (text, atts, headingCss) => (
  <Heading {...atts} css={headingCss}>
    {text.text}
  </Heading>
);

const ListAlternatingV2 = ({ input }) => {
  const {
    heading,
    subheading,
    background_color,
    background_image,
    text_color,
    heading_color,
    subheading_color,
  } = input.primary;

  return (
    <BulmaSection
      id="testListAlternating"
      css={styledListAlternating}
      style={{
        backgroundColor: background_color || '#fff',
        backgroundImage: `url(${background_image ? background_image.url : ''})`,
      }}
    >
      {heading || subheading ? (
        <BulmaContainer>
          {heading && heading[0].text
            ? renderHeading(
                heading[0],
                {
                  renderAs: 'h2',
                  className: `${text_color === 'light' ? 'h2 white' : 'h2 darkblue'}`,
                  style: { color: heading_color },
                },
                css`
                  ${styledContainerHeading}
                  ${styledHeading}
                `,
              )
            : null}
          {subheading && subheading[0].text
            ? renderHeading(
                subheading[0],
                {
                  renderAs: 'p',
                  className: `${text_color === 'light' ? 'medium white' : 'medium darkgrey'}`,
                  style: { color: subheading_color },
                  subtitle: true,
                },
                css`
                  ${styledSubheading}
                  ${styledHeading}
                `,
              )
            : null}
        </BulmaContainer>
      ) : null}
      <BulmaContainer css={styledContentWrapper}>
        <BulmaColumns>
          {input.fields.map(item => (
            <LargeImgWithSideContent
              image={item.list_alt_image}
              title={item.list_alt_title}
              linkURL={item.list_alt_link}
              linkColor={item.list_link_color}
              linkText={item.list_alt_link_text}
              titleColor={item.list_title_color}
              text={item.list_alt_text}
              defaultTextColor={item.text_color}
              contentTextColor={item.list_text_color}
              imagePosition={null}
              key={createRandomId()}
            />
          ))}
        </BulmaColumns>
      </BulmaContainer>
    </BulmaSection>
  );
};

export default ListAlternatingV2;

ListAlternatingV2.propTypes = {
  input: PropTypes.object.isRequired,
};
