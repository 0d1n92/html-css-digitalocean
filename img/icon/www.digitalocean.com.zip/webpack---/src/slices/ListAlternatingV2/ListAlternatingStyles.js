import { css } from '@emotion/core';
import media from 'css-in-js-media';

export const styledSubheading = css`
  text-align: center;
  margin: 10px auto 0 auto !important;
`;

export const styledHeading = css`
  margin: 64px auto 0 auto !important;
  line-height: 1.2;
  ul {
    font-size: 18px;
    margin-top: 10px;
    margin-left: 32px;
  }
  ${media('< tablet')} {
    text-align: center;
    width: 100%;
    margin: 20px auto 0 auto;
  }
`;

export const styledContainerHeading = css`
  text-align: center;
  margin: 0 !important;
  ${media('< tablet')} {
    margin: 0 auto !important;
  }
`;
export const styledListAlternating = css`
  p {
    color: #5b6987;
    margin: 20px 0 0 0;
    ${media('< desktop')} {
      text-align: center;
      width: 100%;
      margin: 20px auto 0 auto;
    }
  }
`;

export const styledLink = css`
  margin-top: 20px !important;
  display: block;
  ${media('< tablet')} {
    display: block;
    text-align: center;
    width: 80%;
    margin: 20px auto 0 auto;
  }
`;

export const styledContentWrapper = css`
  margin-top: 64px;
`;
