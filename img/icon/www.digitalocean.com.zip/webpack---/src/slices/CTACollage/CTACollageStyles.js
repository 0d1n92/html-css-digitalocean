// Styles here will override Bulma styles
import { css } from '@emotion/core';
import styled from '@emotion/styled';
import media from 'css-in-js-media';

export const styledHeading = css`
  margin: 60px auto 0 auto;
  text-align: center;
`;
export const styledCTAHeading = css`
  text-align: center;
`;

export const styledSubheading = css`
  margin: 20px auto 80px auto !important;
  max-width: 670px;
  text-align: center;
`;

export const styledCollageContainer = css`
  display: grid;
  grid-gap: 32px;
  grid-template-columns: repeat(12, 1fr);
  grid-template-rows: repeat(12, 40px);
  max-width: 1200px;
  ${media('< desktop')} {
    grid-template-columns: repeat(2, 1fr);
    grid-template-rows: repeat(2, min-content);
  }
`;

export const StyledImageContainer = styled.div`
  display: flex;
  align-items: center;
  img {
    height: 100%;
    object-fit: cover;
    width: 100%;
  }
`;

export const styledTopLeftImage = css`
  grid-column: 2/5;
  grid-row: 2/6;
  box-shadow: 0 4px 30px rgba(1, 14, 40, 0.1);
  ${media('< desktop')} {
    grid-column: 1/2;
    grid-row: 1/2;
  }
`;
export const styledTopRightImage = css`
  grid-column: 5/13;
  grid-row: 1/9;
  box-shadow: 0 4px 30px rgba(1, 14, 40, 0.1);
  ${media('< desktop')} {
    grid-column: 2/3;
    grid-row: 1/2;
  }
`;

export const styledBottomRightImage = css`
  grid-column: 7/10;
  grid-row: 9/13;
  box-shadow: 0 4px 30px rgba(1, 14, 40, 0.1);
  ${media('< desktop')} {
    display: none;
  }
`;

export const StyledCTAContainer = styled.div`
  grid-column: 1/7;
  grid-row: 6/12;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  padding: 40px;
  z-index: 10;
  box-shadow: 0 4px 30px rgba(1, 14, 40, 0.1);
  ${media('< desktop')} {
    grid-column: 1/3;
    grid-row: 2/3;
  }
`;

export const styledCTAButton = css`
  margin-top: 32px;
`;
