/* eslint-disable camelcase */
import React from 'react';
import PropTypes from 'prop-types';

import BulmaContainer from 'react-bulma-components/lib/components/container';
import BulmaSection from 'react-bulma-components/lib/components/section';
import { Heading, Button, LazyLink, LazyImage } from '../atoms';

import {
  styledHeading,
  styledCTAHeading,
  styledSubheading,
  styledCollageContainer,
  StyledImageContainer,
  StyledCTAContainer,
  styledTopLeftImage,
  styledTopRightImage,
  styledBottomRightImage,
  styledCTAButton,
} from './CTACollageStyles';

const CTACollage = ({ input }) => {
  const {
    text_color,
    heading,
    heading_color,
    subheading,
    subheading_color,
    background_color,
    background_image,
    top_left_image,
    large_top_image,
    bottom_right_image,
    cta_background_color,
    cta_heading,
    cta_heading_color,
    cta_subheading,
    cta_subheading_color,
    cta_button_link,
    cta_button_text,
  } = input.primary;
  return (
    <BulmaSection
      id="testCardsSection"
      style={
        background_image && background_image.url
          ? { backgroundImage: `url(${background_image.url})` }
          : { backgroundColor: `${background_color}` }
      }
    >
      <BulmaContainer>
        {heading && heading[0].text ? (
          <Heading
            id="testCTACollageHeading"
            style={heading_color ? { color: heading_color } : null}
            css={styledHeading}
            className={text_color === 'light' ? 'h2 white' : 'h2 darkblue'}
            renderAs="h2"
          >
            {heading[0].text}
          </Heading>
        ) : null}
        {subheading && subheading[0].text ? (
          <Heading
            id="testCTACollageSubheading"
            style={subheading_color ? { color: subheading_color } : null}
            css={styledSubheading}
            subtitle
            className={text_color === 'light' ? 'medium white' : 'medium darkgrey'}
            renderAs="p"
          >
            {subheading[0].text}
          </Heading>
        ) : null}
      </BulmaContainer>
      <BulmaContainer css={styledCollageContainer} id="testCTACollageContainer">
        <StyledImageContainer css={styledTopLeftImage}>
          <LazyImage src={top_left_image.url} alt={top_left_image.alt || 'DigitalOcean company image'} />
        </StyledImageContainer>
        <StyledImageContainer css={styledTopRightImage}>
          <LazyImage src={large_top_image.url} alt={large_top_image.alt || 'DigitalOcean company image'} />
        </StyledImageContainer>
        <StyledCTAContainer id="testCTACollageCTAContainer" style={{ backgroundColor: cta_background_color }}>
          {cta_heading && cta_heading[0].text ? (
            <Heading
              id="testCTACollageCTAHeading"
              style={cta_heading_color ? { color: cta_heading_color } : null}
              css={styledCTAHeading}
              className={text_color === 'light' ? 'h2 white' : 'h2 darkblue'}
              renderAs="h2"
            >
              {cta_heading[0].text}
            </Heading>
          ) : null}
          {cta_subheading && cta_subheading[0].text ? (
            <Heading
              style={subheading_color ? { color: cta_subheading_color } : null}
              css={styledCTAHeading}
              subtitle
              className={text_color === 'light' ? 'medium white' : 'medium darkgrey'}
              renderAs="p"
            >
              {cta_subheading[0].text}
            </Heading>
          ) : null}
          {cta_button_link && cta_button_link.url ? (
            <Button
              id="testCTACollageCTAButton"
              css={styledCTAButton}
              color={text_color === 'light' ? 'white' : 'primary'}
              outlined
              renderAs={LazyLink}
              url={cta_button_link.url}
            >
              {cta_button_text}
            </Button>
          ) : null}
        </StyledCTAContainer>
        <StyledImageContainer css={styledBottomRightImage}>
          <LazyImage src={bottom_right_image.url} alt={bottom_right_image.alt || 'DigitalOcean company image'} />
        </StyledImageContainer>
      </BulmaContainer>
    </BulmaSection>
  );
};

export default CTACollage;

CTACollage.propTypes = {
  input: PropTypes.object.isRequired,
};
