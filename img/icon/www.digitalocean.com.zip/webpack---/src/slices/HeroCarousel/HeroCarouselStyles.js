// Styles here will override Bulma styles
import { css } from '@emotion/core';
import media from 'css-in-js-media';

export const styledHeroCarouselSection = css`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  padding-top: 80px;
  padding-bottom: 60px;
  background-position: bottom;
  background-repeat: no-repeat;
  background-size: cover;
`;

export const styledHeading = css`
  margin-top: 40px !important;
  line-height: 120%;
  text-align: center;
`;

export const styledSubHeading = css`
  margin-top: 16px !important;
  margin-bottom: 60px !important;
  text-align: center;
`;

export const styledHeroCarouselContent = css`
  display: flex;
  flex-direction: column;
  justify-content: center;
  margin-left: 32px !important;

  ${media('< tablet')} {
    margin-bottom: 32px !important;
  }

  div {
    align-items: flex-start !important;
  }
`;

export const styledVideoContainer = css`
  width: 90%;
  margin: 0 auto;
  ${media('< tablet')} {
    width: 100%;
  }
`;
