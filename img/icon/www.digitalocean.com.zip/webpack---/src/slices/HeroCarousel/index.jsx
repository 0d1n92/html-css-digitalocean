/* eslint-disable camelcase */
import React from 'react';
import PropTypes from 'prop-types';

import BulmaSection from 'react-bulma-components/lib/components/section';
import BulmaColumns from 'react-bulma-components/lib/components/columns';

import { css } from '@emotion/core';
import { Carousel, Heading, Quote, WistiaVideo } from '../atoms';

import {
  styledSubHeading,
  styledHeroCarouselSection,
  styledHeroCarouselContent,
  styledVideoContainer,
  styledHeading,
} from './HeroCarouselStyles';

const renderContent = (fields, text_color) =>
  fields.map(field => {
    const { wistia_video_id } = field;

    return (
      <BulmaColumns gapless multiline={false}>
        <BulmaColumns.Column size="mobile is-12-mobile 5" css={styledHeroCarouselContent}>
          <div css={styledVideoContainer}>
            <WistiaVideo wistiaId={wistia_video_id} />
          </div>
        </BulmaColumns.Column>
        <BulmaColumns.Column size="mobile is-12-mobile 7" css={styledHeroCarouselContent}>
          <Quote quoteProps={{ ...field, text_color }} />
        </BulmaColumns.Column>
      </BulmaColumns>
    );
  });

const HeroCarousel = ({ input }) => {
  const {
    background_color,
    background_image,
    text_color,
    heading,
    heading_color,
    subheading,
    subheading_color,
  } = input.primary;

  return (
    <BulmaSection
      css={css`
        ${styledHeroCarouselSection}
        ${background_image ? `background-image: url(${background_image.url});` : null};
        background-color: ${background_color};
      `}
    >
      <Heading
        renderAs="h1"
        className={text_color === 'light' ? 'h1 white' : 'h1 darkblue'}
        css={
          heading_color
            ? css`
                ${styledHeading}
                color: ${heading_color} !important;
              `
            : styledHeading
        }
      >
        {heading[0].text}
      </Heading>
      <Heading
        renderAs="p"
        subtitle
        className={text_color === 'light' ? 'large white' : 'large darkblue'}
        css={
          heading_color
            ? css`
              ${styledSubHeading}
                color: ${subheading_color} !important;
              `
            : styledSubHeading
        }
      >
        {subheading[0].text}
      </Heading>
      <Carousel fadeIn text_color={text_color} id="testHeroCarousel">
        {renderContent(input.fields, text_color)}
      </Carousel>
    </BulmaSection>
  );
};

export default HeroCarousel;

HeroCarousel.propTypes = {
  input: PropTypes.object.isRequired,
};

renderContent.propTypes = {
  fields: PropTypes.array.isRequired,
};
