/* eslint-disable camelcase */
import React, { useEffect } from 'react';
import PropTypes from 'prop-types';
import Prism from 'prismjs';

import BulmaContainer from 'react-bulma-components/lib/components/container';
import BulmaSection from 'react-bulma-components/lib/components/section';

import { css } from '@emotion/core';
import { Heading, Tab, TextLink } from '../atoms';
import { TopTabContainer } from '../atoms/Tabs/TopTabNav';
import {
  StyledSideContent,
  StyledCodeblock,
  styledContainer,
  styledCodeblockContainer,
  styledCopy,
  styledHeading,
  styledSubheading,
} from './CodeBlockStyles';
import './prism-duotone.css';
import { createRandomId } from '../../util/createRandomId';

const Content = (blog_post_content, code_language, code_link_url, code_link_text, isSingleCodeblock) => {
  useEffect(() => {
    if (isSingleCodeblock) Prism.highlightAll();
  }, [isSingleCodeblock]);

  const content = `<pre><code class="language-${
    code_language === 'curl' || code_language === 'doctl' ? 'bash' : code_language
  }">${blog_post_content.text}</code></pre>`;
  return (
    <StyledCodeblock isSingleCodeblock={isSingleCodeblock}>
      <div dangerouslySetInnerHTML={{ __html: content }} />
      {code_link_url && code_link_url.url && (
        <TextLink url={code_link_url.url} className="arrow">
          {code_link_text && code_link_text}
        </TextLink>
      )}
    </StyledCodeblock>
  );
};

const renderHeading = (text, atts) => <Heading {...atts}>{Array.isArray(text) ? text : text.text}</Heading>;

const CodeBlock = ({ input }) => {
  const {
    text_color,
    background_color,
    background_image,
    heading,
    subheading,
    heading_color,
    subheading_color,
    headline,
    headline_color,
    copy,
    copy_color,
    code_link_url,
    code_link_text,
    link_url,
    link_text,
  } = input.primary;

  return (
    <BulmaSection
      css={css`
        background-color: ${background_color};
        ${background_image && background_image.url ? `background-image: url(${background_image.url});` : null};
      `}
    >
      <BulmaContainer css={styledCodeblockContainer}>
        {heading && heading[0].text
          ? renderHeading(heading[0], {
              renderAs: 'h2',
              className: `${text_color === 'light' && !heading_color ? 'h2 white' : 'h2 darkblue'}`,
              style: { color: heading_color },
              css: styledHeading,
            })
          : null}
        {subheading && subheading[0].text
          ? renderHeading(subheading[0], {
              renderAs: 'p',
              className: `${text_color === 'light' && !subheading_color ? 'white medium' : 'darkgrey medium'}`,
              style: { color: subheading_color },
              subtitle: true,
              css: styledSubheading,
            })
          : null}
        <div css={styledContainer}>
          <StyledSideContent>
            {headline &&
              headline[0] &&
              headline[0].text &&
              renderHeading(headline[0], {
                style: headline_color && { color: headline_color },
                renderAs: 'h2',
                className: 'h2 darkblue',
              })}
            {renderHeading(copy, { style: copy_color && { color: copy_color }, css: styledCopy })}
            {link_text && link_text[0].text ? (
              <TextLink className={text_color === 'light' ? 'white medium arrow' : 'medium arrow'} url={link_url.url}>
                {link_text[0].text}
              </TextLink>
            ) : null}
          </StyledSideContent>
          {input.fields.length === 1 ? (
            Content(input.fields[0].code_content[0], input.fields[0].code_language, code_link_url, code_link_text, true)
          ) : (
            <TopTabContainer codeBlock="codeBlock">
              {input.fields.map(codeblock => (
                <Tab
                  key={createRandomId()}
                  language={codeblock.code_language}
                  label={`${codeblock.code_language[0].toUpperCase()}${codeblock.code_language.slice(1)}`}
                  content={[
                    Content(codeblock.code_content[0], codeblock.code_language, code_link_url, code_link_text, false),
                  ]}
                />
              ))}
            </TopTabContainer>
          )}
        </div>
      </BulmaContainer>
    </BulmaSection>
  );
};

export default CodeBlock;

CodeBlock.propTypes = {
  input: PropTypes.object.isRequired,
};
