// Styles here will override Bulma styles
import { css } from '@emotion/core';
import styled from '@emotion/styled';
import media from 'css-in-js-media';

export const styledCodeblockContainer = css`
  max-width: 1170px;
`;

export const styledContainer = css`
  display: flex;
  flex-direction: row;
  justify-content: center;
  align-items: center;
  margin-top: 20px;

  div {
    flex: 40%;
  }

  .styledLineBackground {
    top: 68px !important;
  }

  pre {
    padding: 30px;
    margin: 8px 0;
    overflow: auto;
    border-radius: 0.3em;
    background-color: #1d262f;
    min-height: 265px;
    max-height: 265px;
    overflow-wrap: break-word;
    white-space: initial !important;

    ${media('< desktop')} {
      flex-direction: column-reverse;
      width: auto;
    }
  }

  code {
    white-space: pre-wrap !important;
    word-break: break-all;
  }

  .toolbar-item {
    display: none !important;
  }

  ${media('< desktop')} {
    flex-direction: column;
    .container {
      width: 88%;
    }
  }

  ${media('< tablet')} {
    code,
    pre {
      font-size: 13px;
    }
  }
`;

export const styledCopy = css`
  p {
    font-size: 16px;
  }
`;

export const StyledSideContent = styled.div`
  margin: 80px 64px 0 0;

  div {
    margin-top: 20px;
  }

  h2 {
    font-size: 30px !important;
  }

  ${media('< desktop')} {
    width: 88%;
    text-align: center;
    margin: 40px auto 20px auto;
  }
`;

export const styledHeading = css`
  margin: 64px auto 0 auto;
  text-align: center;
`;

export const styledSubheading = css`
  margin: 20px auto 80px auto !important;
  max-width: 670px;
  text-align: center;
`;

export const StyledCodeblock = styled.div`
  margin-top: ${props => (props.isSingleCodeblock ? '20px' : 0)} !important;

  ${media('< desktop')} {
    text-align: center;
  }
`;
