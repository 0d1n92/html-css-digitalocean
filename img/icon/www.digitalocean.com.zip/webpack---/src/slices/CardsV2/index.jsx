/* eslint-disable camelcase */
import React from 'react';
import PropTypes from 'prop-types';

import BulmaContainer from 'react-bulma-components/lib/components/container';
import BulmaSection from 'react-bulma-components/lib/components/section';

import { Heading, Button, Card, LazyLink } from '../atoms';

import { createRandomId } from '../../util/createRandomId';

import {
  styledCardsSection,
  styledCardsContainer,
  styledHeading,
  styledSubtitle,
  styledCards,
  styledButton,
} from './CardsV2Styles';

const CardsV2 = ({ input }) => {
  const {
    text_color,
    heading,
    heading_color,
    subheading,
    subheading_color,
    background_image,
    background_color,
    columns,
    content_alignment,
    cta_button_text,
    cta_button_url,
  } = input.primary;
  const { fields } = input;

  let topMargin;

  if (!heading && !subheading) {
    topMargin = '0';
  } else if (!heading && subheading[0].text === '') {
    topMargin = '0';
  } else if (heading[0].text === '' && !subheading) {
    topMargin = '0';
  } else if (heading[0].text === '' && subheading[0].text === '') {
    topMargin = '0';
  } else {
    topMargin = '64px';
  }

  return (
    <BulmaSection
      id="testCardsSection"
      css={styledCardsSection}
      style={{
        backgroundImage: `url(${background_image && background_image.url})`,
        backgroundColor: background_color,
        paddingTop: `${!heading && !subheading ? '64px' : null}`,
        paddingBottom: `${!heading && !subheading ? '64px' : null}`,
      }}
    >
      <BulmaContainer css={styledCardsContainer}>
        {heading && heading[0].text ? (
          <Heading
            style={heading_color ? { color: heading_color } : null}
            css={styledHeading}
            className={text_color === 'light' ? 'h2 white' : 'h2 darkblue'}
            renderAs="h2"
          >
            {heading[0].text}
          </Heading>
        ) : null}
        {subheading && subheading[0].text ? (
          <Heading
            style={subheading_color ? { color: subheading_color } : null}
            css={styledSubtitle}
            subtitle
            className={text_color === 'light' ? 'medium white' : 'medium darkgrey'}
            renderAs="p"
          >
            {subheading[0].text}
          </Heading>
        ) : null}
        <div
          id="testCards"
          css={styledCards}
          style={{
            gridTemplateColumns: `repeat(${fields.length < columns ? fields.length : columns}, minmax(220px, 1fr))`,
            textAlign: `${content_alignment === 'center' ? 'center' : 'left'}`,
            marginTop: topMargin,
            maxWidth: `${fields.length <= 2 ? '870px' : 'auto'}`,
          }}
        >
          {fields.map(card => (
            <Card
              image={card.image}
              title={card.title1}
              title_color={card.title_color}
              text={card.text}
              text_color={card.text_color}
              link={card.link}
              key={createRandomId()}
            />
          ))}
        </div>

        {cta_button_url && cta_button_url.url ? (
          <Button
            css={styledButton}
            color={text_color === 'light' ? 'white' : 'primary'}
            outlined
            renderAs={LazyLink}
            url={cta_button_url.url}
          >
            {cta_button_text}
          </Button>
        ) : null}
      </BulmaContainer>
    </BulmaSection>
  );
};

export default CardsV2;

CardsV2.propTypes = {
  input: PropTypes.object.isRequired,
};
