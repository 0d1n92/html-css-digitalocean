/* eslint-disable camelcase */
import React from 'react';
import PropTypes from 'prop-types';

import BulmaButton from 'react-bulma-components/lib/components/button';
import BulmaColumns from 'react-bulma-components/lib/components/columns';
import BulmaContainer from 'react-bulma-components/lib/components/container';
import BulmaSection from 'react-bulma-components/lib/components/section';

import { Heading, Button, LazyLink } from '../atoms';

import {
  styledCTAWrapper,
  styledHeading,
  styledButtonsContainer,
  styledButtonColumn,
  styledSubheading,
} from './CTABandStyles';

const renderHeading = (text, atts) => <Heading {...atts}>{text.text}</Heading>;

const renderButton = (link, text, atts) => (
  <Button {...atts} renderAs={LazyLink} url={link.url}>
    {text.text}
  </Button>
);

const CTABand = ({ input }) => {
  const {
    text_color,
    background_image,
    background_color,
    heading,
    subheading,
    cta_primary_background_color,
    cta_url_primary,
    cta_text_primary,
    cta_url_secondary,
    cta_text_secondary,
  } = input.primary;

  return (
    <BulmaSection
      css={styledCTAWrapper}
      style={{
        backgroundImage: `url(${background_image && background_image.url ? background_image.url : null})`,
        backgroundColor: background_color,
      }}
    >
      <BulmaContainer>
        <BulmaColumns>
          <BulmaColumns.Column size={7}>
            {heading && heading[0]
              ? renderHeading(heading[0], {
                  className: text_color === 'light' ? 'h2 white' : 'h2 darkblue',
                  css: styledHeading,
                })
              : null}
            {subheading &&
              subheading[0].text &&
              renderHeading(subheading[0], {
                className: text_color === 'light' ? 'medium white' : 'medium darkgrey',
                subtitle: true,
                renderAs: 'p',
                css: styledSubheading,
              })}
          </BulmaColumns.Column>
          <BulmaColumns.Column css={styledButtonColumn}>
            <BulmaButton.Group css={styledButtonsContainer}>
              {cta_url_secondary && cta_text_secondary && cta_url_secondary.url
                ? renderButton(cta_url_secondary, cta_text_secondary[0], { outlined: true, color: 'white' })
                : null}
              {cta_text_primary &&
                cta_text_primary[0].text &&
                cta_url_primary &&
                renderButton(cta_url_primary, cta_text_primary[0], {
                  color: `${cta_primary_background_color === 'white' ? 'white' : 'primary'}`,
                })}
            </BulmaButton.Group>
          </BulmaColumns.Column>
        </BulmaColumns>
      </BulmaContainer>
    </BulmaSection>
  );
};

export default CTABand;

CTABand.propTypes = {
  input: PropTypes.object.isRequired,
};
