// Styles here will override Bulma styles
import { css } from '@emotion/core';
import media from 'css-in-js-media';

export const styledCTAWrapper = css`
  display: flex;
  align-items: center;
  background-repeat: no-repeat;
  background-size: cover;
  background-position: center;
  padding-top: 64px;
  padding-bottom: 64px;

  ${media('< desktop')} {
    .columns {
      flex-direction: column;
    }
  }
`;

export const styledHeading = css`
  margin-top: 8px;
  ${media('< desktop')} {
    text-align: center;
    margin-left: 0px;
  }
`;

export const styledSubheading = css`
  margin-top: 10px !important;
  margin-bottom: 0px !important;
  ${media('< desktop')} {
    text-align: center;
    margin-left: 0px;
  }
`;
export const styledButtonColumn = css`
  display: flex;
  justify-content: flex-end;
  ${media('< desktop')} {
    justify-content: center;
  }
`;

export const styledButtonsContainer = css`
  display: flex;
  justify-content: flex-end;
  margin-top: 0px;
  .is-primary,
  .is-white {
    margin-right: 0px !important;
    margin-left: 14px !important;
    margin-bottom: 0.5rem;
  }
  .is-outlined {
    margin-right: 6px !important;
  }
  ${media('< tablet')} {
    flex-direction: column;
    justify-content: center !important;
    .is-white,
    .is-primary,
    .is-outlined {
      margin-right: 0px !important;
      margin-left: 0px !important;
    }
    .is-outlined {
      margin-bottom: 12px !important;
    }
  }
`;
