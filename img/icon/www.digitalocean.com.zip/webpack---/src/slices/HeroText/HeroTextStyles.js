// Styles here will override Bulma styles
import { css } from '@emotion/core';
import media, { setBreakPoints } from 'css-in-js-media';

setBreakPoints({ phone: 453 });

export const styledHeroTextSection = css`
  display: flex;
  flex-direction: column;
  justify-content: center;
  padding-top: 120px;
  padding-bottom: 120px;
  background-repeat: no-repeat;
  background-size: cover;
  background-position: bottom;
  height: 360px;

  ${media('<tablet')} {
    padding-top: 64px;
    padding-bottom: 64px;
    min-height: 360px;
    height: 100%;
  }
`;

export const styledHeroTextFullscreen = css`
  height: calc(100vh - 305px);
  display: flex;
  flex-direction: column;
  justify-content: center;

  ${media('< desktop')} {
    height: calc(100vh - 195px);
  }
`;

export const styledCenterHeroText = css`
  line-height: 120% !important;

  h1,
  h2,
  h3,
  h4,
  h5,
  p {
    margin: 0 auto;
  }

  ${media('< desktop')} {
    width: inherit;
    max-width: inherit;
  }
`;

export const styledButtonContainer = css`
  margin-top: 40px;

  a {
    margin-right: 0 !important;
  }
  a:nth-of-type(2) {
    margin-left: 24px;

    ${media('<=phone')} {
      margin-left: 0;
      margin-top: 16px;
    }
  }
`;

export const styledHeading = css`
  max-width: 670px;
  line-height: 110% !important;
`;

export const styledSubHeading = css`
  max-width: 670px !important;
`;
