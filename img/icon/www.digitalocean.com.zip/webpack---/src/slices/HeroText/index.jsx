/* eslint-disable camelcase */
import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import { Helmet } from 'react-helmet';

import BulmaButton from 'react-bulma-components/lib/components/button';
import BulmaContainer from 'react-bulma-components/lib/components/container';
import BulmaSection from 'react-bulma-components/lib/components/section';

import { css } from '@emotion/core';
import { Heading, Button, LazyLink } from '../atoms';

import {
  styledHeading,
  styledSubHeading,
  styledButtonContainer,
  styledCenterHeroText,
  styledHeroTextSection,
  styledHeroTextFullscreen,
} from './HeroTextStyles';

const renderButton = (link, text, atts) => (
  <Button renderAs={LazyLink} url={link.url} {...atts}>
    {text.text}
  </Button>
);

const renderHeading = (text, atts) => <Heading {...atts}>{text.text}</Heading>;

const HeroText = ({ input }) => {
  const {
    fullscreen,
    large_text,
    text_color,
    background_color,
    background_image,
    heading,
    subheading,
    display_primary_cta,
    primary_cta_color,
    primary_cta_link,
    primary_cta_text,
    display_secondary_cta,
    secondary_cta_link,
    secondary_cta_text,
    text_alignment,
  } = input.primary;

  const [careersPage, setCareersPage] = useState(false);

  useEffect(() => {
    if (typeof window === 'undefined' || !window.document) {
      // return
    } else {
      const isCareers = document.location.pathname.includes('/careers/');

      setCareersPage(isCareers);
    }
  }, [careersPage]);

  return (
    <span>
      {careersPage ? (
        <Helmet>
          <script src="https://widget.altrulabs.com/main.js" data-altru-widget-id="5694" />
        </Helmet>
      ) : null}
      <BulmaSection
        css={css`
          ${styledHeroTextSection}
          background-color: ${background_color};
          ${background_image ? `background-image: url(${background_image.url});` : null};
          ${text_alignment === 'center' ? 'text-align: center;' : 'text-align: left;'}
          ${fullscreen && styledHeroTextFullscreen}
        `}
      >
        <BulmaContainer css={text_alignment === 'center' ? styledCenterHeroText : null}>
          {heading && heading[0]
            ? renderHeading(heading[0], {
                id: 'herotext-heading',
                className: `${text_color === 'light' ? 'h1 white' : 'h1 darkblue'} ${large_text ? 'hero-title' : ''}`,
                css: styledHeading,
                style: { margin: text_alignment === 'left' ? '0' : '' },
              })
            : null}
          {subheading && subheading[0]
            ? renderHeading(subheading[0], {
                id: 'herotext-subheading',
                className: `${text_color === 'light' ? 'large white' : 'large darkblue'}`,
                renderAs: 'p',
                subtitle: true,
                css: styledSubHeading,
                style: { margin: text_alignment === 'left' ? '0' : '' },
              })
            : null}
          {display_primary_cta || display_secondary_cta ? (
            <BulmaButton.Group
              id="herotext-buttons"
              style={text_alignment === 'center' ? { display: 'flex', justifyContent: 'center' } : null}
              css={styledButtonContainer}
            >
              {display_primary_cta && primary_cta_text && primary_cta_link
                ? renderButton(primary_cta_link, primary_cta_text[0], { color: primary_cta_color })
                : null}
              {display_secondary_cta && secondary_cta_text && secondary_cta_link
                ? renderButton(secondary_cta_link, secondary_cta_text[0], {
                    color: 'white',
                    outlined: true,
                  })
                : null}
            </BulmaButton.Group>
          ) : null}
        </BulmaContainer>
      </BulmaSection>
    </span>
  );
};

export default HeroText;

HeroText.propTypes = {
  input: PropTypes.object.isRequired,
};
