/* eslint-disable camelcase */
import React from 'react';
import PropTypes from 'prop-types';

import BulmaContainer from 'react-bulma-components/lib/components/container';
import BulmaSection from 'react-bulma-components/lib/components/section';

import { styledQuoteSection, styledQuoteContainer } from './QuoteStyles';

import { Quote } from '../atoms';

const QuoteSlice = ({ input }) => {
  const {
    align_content,
    author_details,
    author_image,
    author_name,
    background_color,
    background_image,
    logo,
    quote,
    text_color,
  } = input.primary;

  return (
    <BulmaSection
      css={styledQuoteSection}
      style={
        background_image && background_image.url
          ? { backgroundImage: `url(${background_image.url})` }
          : { backgroundColor: `${background_color}` }
      }
    >
      <BulmaContainer
        css={styledQuoteContainer}
        style={
          align_content === 'center' ? { textAlign: 'center', justifyContent: 'center', alignItems: 'center' } : null
        }
      >
        <Quote
          quoteProps={{
            author: { 0: { text: author_name } },
            logo,
            quote,
            text_color,
            avatar: author_image,
            author_details,
            align_content,
            quote_size: 'large',
          }}
        />
      </BulmaContainer>
    </BulmaSection>
  );
};

export default QuoteSlice;

QuoteSlice.propTypes = {
  input: PropTypes.object.isRequired,
};
