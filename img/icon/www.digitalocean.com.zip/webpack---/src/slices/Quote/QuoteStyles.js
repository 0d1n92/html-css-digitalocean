// Styles here will override Bulma styles
import { css } from '@emotion/core';
import media from 'css-in-js-media';

export const styledQuoteSection = css`
  background-repeat: repeat;
`;

export const styledQuoteContainer = css`
  display: flex;
  flex-direction: column;
  justify-content: left;
  align-items: flex-start;
  max-width: 800px;

  ${media('< desktop')} {
    justify-content: center;
    align-items: center;
  }
`;
