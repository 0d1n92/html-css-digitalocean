/* eslint-disable camelcase */
import React, { useState } from 'react';
import PropTypes from 'prop-types';

import BulmaContainer from 'react-bulma-components/lib/components/container';
import BulmaSection from 'react-bulma-components/lib/components/section';

import { createRandomId } from '../../util/createRandomId';

import { Heading, Button, Card, Modal, AbuseForm } from '../atoms';

import {
  styledCardsSection,
  styledCardsContainer,
  styledHeading,
  styledSubtitle,
  StyledModalWrapper,
  StyledCards,
  styledButton,
  styledModal,
  StyledModalContent,
  StyledModalHeader,
  styledModalTitle,
  StyledCloseBtn,
} from './CardsContactStyles';

const renderHeading = (text, atts) => (
  <Heading {...atts} css={atts.css}>
    {text.text}
  </Heading>
);

const CardsContact = ({ input }) => {
  const {
    text_color,
    heading,
    heading_color,
    subheading,
    subheading_color,
    background_image,
    background_color,
    columns,
    content_alignment,
    cta_button_text,
    cta_button_url,
  } = input.primary;

  const { fields } = input;

  const [modalAbuseIsShowing, setModalAbuseIsShowing] = useState(false);

  // Rendering out card with correct modal
  const renderCard = card => {
    const { modal_title, modal_form_1 } = card;

    // If it's the abuse card return:
    if (modal_title && modal_form_1 !== null) {
      return (
        <>
          <StyledModalWrapper
            role="button"
            tabIndex="0"
            onClick={() => setModalAbuseIsShowing(true)}
            onKeyPress={() => setModalAbuseIsShowing(true)}
            key={createRandomId()}
          >
            <Card
              image={card.image}
              title={card.title1}
              title_color={card.title_color}
              text={card.text}
              text_color={card.text_color}
              key={createRandomId()}
              modal
            />
          </StyledModalWrapper>
          {/* Abuse modal */}
          <Modal
            css={styledModal}
            show={modalAbuseIsShowing}
            onClose={() => setModalAbuseIsShowing(false)}
            closeOnBlur
            showClose={false}
          >
            <StyledModalContent>
              <StyledModalHeader>
                {modal_title &&
                  modal_title[0].text &&
                  renderHeading(modal_title[0], {
                    renderAs: 'h5',
                    className: 'h5 darkblue',
                    css: styledModalTitle,
                  })}

                <StyledCloseBtn
                  onClick={() => {
                    setModalAbuseIsShowing(false);
                  }}
                />
              </StyledModalHeader>
              {AbuseForm(card)}
            </StyledModalContent>
          </Modal>
        </>
      );
    }

    // Otherwise if a non-modal card return:
    return (
      <Card
        image={card.image}
        title={card.title1}
        title_color={card.title_color}
        text={card.text}
        text_color={card.text_color}
        link={card.link}
        key={createRandomId()}
      />
    );
  };

  return (
    <BulmaSection
      id="testCardsSection"
      css={styledCardsSection}
      style={
        background_image && background_image.url
          ? { backgroundImage: `url(${background_image.url})` }
          : { backgroundColor: `${background_color}` }
      }
    >
      <BulmaContainer css={styledCardsContainer}>
        {/* Headings */}
        {heading &&
          heading[0].text &&
          renderHeading(heading[0], {
            renderAs: 'h2',
            className: `${text_color === 'light' ? 'h2 white' : 'h2 darkblue'}`,
            css: styledHeading,
            style: heading_color ? { color: heading_color } : null,
          })}

        {subheading &&
          subheading[0].text &&
          renderHeading(subheading[0], {
            renderAs: 'p',
            className: `${text_color === 'light' ? 'medium white subtitle' : 'medium darkgrey subtitle'}`,
            css: styledSubtitle,
            style: subheading_color ? { color: subheading_color } : null,
          })}

        {/* Cards */}
        <StyledCards
          id="testCards"
          style={{
            gridTemplateColumns: `repeat(${fields.length < columns ? fields.length : columns}, minmax(220px, 1fr))`,
            textAlign: `${content_alignment === 'center' ? 'center' : 'left'}`,
          }}
        >
          {fields.map(card => renderCard(card))}
        </StyledCards>

        {/* Buttons */}
        {cta_button_url && cta_button_url.url ? (
          <Button
            css={styledButton}
            color={text_color === 'light' ? 'white' : 'primary'}
            outlined
            renderAs="a"
            href={cta_button_url.url}
          >
            {cta_button_text}
          </Button>
        ) : null}
      </BulmaContainer>
    </BulmaSection>
  );
};

export default CardsContact;

CardsContact.propTypes = {
  input: PropTypes.object.isRequired,
};
