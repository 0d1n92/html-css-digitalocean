// Styles here will override Bulma styles
import styled from '@emotion/styled';
import { css } from '@emotion/core';
import media from 'css-in-js-media';

export const StyledResourceTable = styled.div`
  display: flex;
  margin-top: 60px;
  margin-right: 0px;
  justify-content: center;
  border-radius: 40px;

  .subtitle {
    width: 100%;
  }

  .card-header-title {
    background: #f4f5f9;
    flex-direction: column;
  }

  .card {
    width: ${props => (props.resourceTableCount === 1 ? '1150px' : 'auto')} !important;

    :not(:first-of-type) {
      width: 880px;
    }

    :first-of-type {
      margin-right: 20px;
    }
  }

  div {
    line-height: 180% !important;
  }

  li {
    margin-left: 18px;
  }

  .resource-card-content {
    width: ${props => (props.resourceTableCount === 1 ? '1100px' : '250px')} !important;
  }

  ${media('< largeDesktop')} {
    margin: 60px auto 0 auto;
    flex-direction: column;

    .card {
      max-width: 85%;
      width: auto !important;

      margin-left: auto !important;
      margin-right: auto !important;
      border-radius: 3px;
      :first-of-type {
        margin-bottom: 60px;
        margin-right: 0px;
        margin-left: 0px;
      }

      li {
        list-style: none;
      }

      .resource-card-content {
        width: auto !important;
      }
    }
  }
`;

export const styledHeading = css`
  text-align: center;
  margin: auto;
`;

export const styledSubheading = css`
  text-align: center;
  margin: 20px auto 0 auto;
  max-width: 808px !important;

  p {
    font-size: 20px !important;
    font-family: 'Sailec-Light';
    max-width: 808px !important;
  }
`;

export const styledResourceTableHeader = css`
  padding-top: 20px;

  h6 {
    font-weight: 700 !important;
    letter-spacing: 1px !important;
    color: #5b6987 !important;
  }
  div {
    margin-top: 10px !important;
    font-size: 14px;
  }
`;

export const styledResourceTableCopy = css`
  margin: 10px auto 10px auto;
  line-height: 180%;

  ${media('< largeDesktop')} {
    max-width: 90%;
  }
`;

export const styledResourceTitle = css`
  display: flex;
  margin-top: 0px;

  h5 {
    margin: 14px 0px 10px 5px !important;
    font-size: 20px !important;
  }

  .subtitle {
    line-height: 180% !important;
  }

  ${media('< largeDesktop')} {
    justify-content: center;
    margin: auto;

    flex-direction: column;
  }
`;

export const StyledContent = styled.div`
  margin-top: 10px;
  display: flex;
  justify-content: space-between;

  ${media('< largeDesktop')} {
    flex-direction: column;
  }
`;

export const StyledResourceTableContent = styled.div`
  position: relative;
  padding: 0 5px;
  line-height: 180%;

  :not(:first-of-type) {
    margin-left: 40px;
  }

  :not(:first-of-type):after {
    content: '';
    background: #e5e8ed;
    position: absolute;
    top: -32px;
    left: ${props => (props.resourceTableCount === 1 ? '-8%' : '-12%')};
    height: ${props => (props.resourceTableCount === 1 ? '114%' : '122%')};
    width: 1px;
  }

  ${media('< largeDesktop')} {
    margin: auto;
    text-align: center;
    min-width: 85% !important;

    :not(:first-of-type):after {
      display: none;
    }

    :not(:first-of-type) {
      margin-top: 20px;
      margin-left: auto;
    }

    :not(:last-of-type) {
      border-bottom: 1px solid #e5e8ed !important;
      padding-bottom: 25px;
    }
  }
`;

export const styledResourceTableSubtitle = css`
  margin-top: 5px !important;
  border-top: 1px solid #e5e8ed !important;
  margin-bottom: 20px !important;
  padding-top: 20px !important;
  color: #5b6987 !important;

  ${media('< largeDesktop')} {
    border-top: none !important;
  }
`;

export const styledResourceTableSubcopy = css`
  line-height: 180% !important;
`;

export const StyledParagraph = styled.p`
  line-height: 150%;
  &.light {
    font-family: 'Sailec-Light';
  }

  /* color */
  &.darkgrey {
    color: #5b6987;
  }
`;
