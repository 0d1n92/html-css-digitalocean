/* eslint-disable camelcase */
import React from 'react';
import PropTypes from 'prop-types';

import BulmaCard from 'react-bulma-components/lib/components/card';
import BulmaSection from 'react-bulma-components/lib/components/section';

import { Heading, LazyImage } from '../atoms';

import { createRandomId } from '../../util/createRandomId';

import {
  StyledResourceTable,
  styledResourceTableSubtitle,
  styledResourceTableSubcopy,
  styledResourceTableCopy,
  styledHeading,
  styledSubheading,
  styledResourceTableHeader,
  styledResourceTitle,
  StyledContent,
  StyledResourceTableContent,
  StyledParagraph,
} from './ResourceTableStyles';

const renderHeading = (text, atts) => (
  <Heading {...atts} css={atts.css}>
    {Array.isArray(text) ? text : text.text}
  </Heading>
);

const renderParagraph = (text, atts) => (
  <StyledParagraph {...atts} css={atts.css}>
    {text.text}
  </StyledParagraph>
);

const renderSection = (tableIcon, tableTitle, tableCopy, tableSubtitle, tableSubcopy, resourceTableCount) => (
  <StyledResourceTableContent resourceTableCount={resourceTableCount} className="resource-card-content">
    {tableTitle && (
      <div css={styledResourceTitle}>
        {tableIcon && <LazyImage alt={tableIcon.url} src={tableIcon.url} />}
        {renderHeading(tableTitle[0], {
          className: 'h5 darkblue',
          renderAs: 'h5',
        })}
      </div>
    )}
    {tableCopy && renderHeading(tableCopy, { css: styledResourceTableCopy, className: 'darkblue' })}
    {tableSubtitle &&
      renderHeading(tableSubtitle[0], { css: styledResourceTableSubtitle, className: 'h6 grey', renderAs: 'h6' })}
    {tableSubcopy && renderHeading(tableSubcopy, { css: styledResourceTableSubcopy, className: 'darkgrey ' })}
  </StyledResourceTableContent>
);

const renderResourceTable = (table, resourceTableCount) => (
  <BulmaCard key={createRandomId()}>
    <BulmaCard.Header>
      <BulmaCard.Header.Title css={styledResourceTableHeader}>
        {table.section_title && renderHeading(table.section_title[0], { className: 'h6 darkgrey', renderAs: 'h6' })}
        {table.section_subtitle && renderParagraph(table.section_subtitle[0], { className: 'darkgrey light' })}
      </BulmaCard.Header.Title>
    </BulmaCard.Header>
    <BulmaCard.Content>
      <StyledContent>
        {table.title_1 &&
          renderSection(
            table.icon_1,
            table.title_1,
            table.copy_1,
            table.subtitle_1,
            table.subcopy_1,
            resourceTableCount,
          )}
        {table.title_2 &&
          renderSection(
            table.icon_2,
            table.title_2,
            table.copy_2,
            table.subtitle_2,
            table.subcopy_2,
            resourceTableCount,
          )}
        {table.title_3 &&
          renderSection(
            table.icon_3,
            table.title_3,
            table.copy_3,
            table.subtitle_3,
            table.subcopy_3,
            resourceTableCount,
          )}
        {table.title_4 &&
          renderSection(
            table.icon_4,
            table.title_4,
            table.copy_4,
            table.subtitle_4,
            table.subcopy_4,
            resourceTableCount,
          )}
      </StyledContent>
    </BulmaCard.Content>
  </BulmaCard>
);

const ResourceTable = ({ input }) => {
  const {
    text_color,
    heading,
    heading_color,
    subheading,
    subheading_color,
    background_image,
    background_color,
  } = input.primary;

  return (
    <BulmaSection
      id="testCardsSection"
      style={
        background_image && background_image.url
          ? { backgroundImage: `url(${background_image.url})` }
          : { backgroundColor: `${background_color}` }
      }
    >
      {heading && heading[0].text
        ? renderHeading(heading[0], {
            css: styledHeading,
            style: heading_color ? { color: heading_color } : null,
            className: `${text_color === 'light' ? 'h2 white' : 'h2 darkblue'}`,
            renderAs: 'h2',
          })
        : null}
      {subheading && subheading[0].text
        ? renderHeading(subheading, {
            css: styledSubheading,
            styled: subheading_color ? { color: subheading_color } : null,
            className: text_color === 'light' ? 'medium white subtitle' : 'medium darkgrey subtitle',
            renderAs: 'p',
          })
        : null}
      <StyledResourceTable resourceTableCount={input.fields.length}>
        {input.fields.map(table => renderResourceTable(table, input.fields.length))}
      </StyledResourceTable>
    </BulmaSection>
  );
};

export default ResourceTable;

ResourceTable.propTypes = {
  input: PropTypes.object.isRequired,
};
