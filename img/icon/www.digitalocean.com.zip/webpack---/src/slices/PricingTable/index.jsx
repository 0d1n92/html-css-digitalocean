/* eslint-disable camelcase */
import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import { RichText } from 'prismic-reactjs';

import BulmaContainer from 'react-bulma-components/lib/components/container';
import BulmaSection from 'react-bulma-components/lib/components/section';
import BulmaTable from 'react-bulma-components/lib/components/table';
import { linkResolver } from '../../util/linkResolver';

import { Heading, LazyImage } from '../atoms';
import { createRandomId } from '../../util/createRandomId';
import { checkCookies } from '../../util/checkCookies';

import tooltipicon from '../../assets/images/tooltipicon.svg';

import {
  styledSection,
  StyledHeadingContainer,
  styledHeading,
  StyledParagraph,
  StyledToolTip,
  StyledToolTipText,
  styledTable,
  styledLink,
  StyledPopularPill,
} from './PricingTableStyles';

const renderHeading = (text, atts) => (
  <Heading {...atts} css={atts.css}>
    {text.text}
  </Heading>
);

const LinkDisplay = ({ condition, styleLink, randomId, rowLink, rowText, notLoggedInLink, notLoggedInText }) =>
  condition ? (
    <a css={styleLink} id={randomId} href={rowLink ? rowLink.url : ''}>
      {rowText}
    </a>
  ) : (
    <a css={styleLink} id={randomId} href={notLoggedInLink ? notLoggedInLink.url : ''}>
      {notLoggedInText}
    </a>
  );

const PricingTable = ({ input }) => {
  const { heading, heading_color, subheading, subheading_color, tooltip_text, target_name } = input.primary;
  const { fields } = input;

  const headers = Object.values(fields[0]);
  const rowArr = fields.map(row => row).slice(1);
  const [isClient, setClient] = useState(false);

  useEffect(() => {
    setClient(true);
  }, []);

  return (
    <BulmaSection css={styledSection}>
      <BulmaContainer>
        <StyledHeadingContainer id={target_name}>
          {heading &&
            heading[0].text &&
            renderHeading(heading[0], {
              style: heading_color ? { color: heading_color } : null,
              className: 'h4 darkblue',
              css: styledHeading,
              renderAs: 'h4',
            })}
          {tooltip_text && (
            <StyledToolTip>
              <LazyImage src={tooltipicon} alt="tooltip icon" /> <StyledToolTipText>{tooltip_text}</StyledToolTipText>
            </StyledToolTip>
          )}
        </StyledHeadingContainer>
        {subheading && (
          <StyledParagraph subheadingColor={subheading_color}>
            <RichText render={subheading} linkResolver={linkResolver} />
          </StyledParagraph>
        )}

        <BulmaTable css={styledTable} className="is-scrollable">
          <thead>
            <tr>
              {headers && headers.map(col => (col ? <th key={createRandomId()}>{col}</th> : null))}
              <th key={createRandomId()} />
            </tr>
          </thead>
          <tbody>
            {rowArr.map(row => (
              <tr>
                {row.column_text_1 && (
                  <td>
                    {row.column_text_1}
                    {row.popular_column && <StyledPopularPill>Popular</StyledPopularPill>}
                  </td>
                )}
                {row.column_text_2 && <td>{row.column_text_2}</td>}
                {row.column_text_3 && <td>{row.column_text_3}</td>}
                {row.column_text_4 && <td>{row.column_text_4}</td>}
                {row.column_text_5 && <td>{row.column_text_5}</td>}
                {row.column_text_6 && <td>{row.column_text_6}</td>}
                {row.column_text_7 && <td>{row.column_text_7}</td>}
                {row.link_url && row.link_url.url ? (
                  <td>
                    {isClient ? (
                      <LinkDisplay
                        condition={checkCookies('ajs_user_id')}
                        styleLink={styledLink}
                        randomId={createRandomId()}
                        rowLink={row.link_url}
                        rowText={row.link_text}
                        notLoggedInLink={row.link_url_not_logged_in}
                        notLoggedInText={row.link_text_not_logged_in}
                      />
                    ) : null}
                  </td>
                ) : null}
              </tr>
            ))}
          </tbody>
        </BulmaTable>
      </BulmaContainer>
    </BulmaSection>
  );
};

export default PricingTable;

LinkDisplay.propTypes = {
  condition: PropTypes.bool,
  styleLink: PropTypes.string,
  randomId: PropTypes.string,
  rowLink: PropTypes.object,
  rowText: PropTypes.string,
  notLoggedInLink: PropTypes.object,
  notLoggedInText: PropTypes.string,
};

LinkDisplay.defaultProps = {
  condition: false,
  styleLink: null,
  randomId: null,
  rowLink: null,
  rowText: null,
  notLoggedInLink: null,
  notLoggedInText: null,
};

PricingTable.propTypes = {
  input: PropTypes.object.isRequired,
};
