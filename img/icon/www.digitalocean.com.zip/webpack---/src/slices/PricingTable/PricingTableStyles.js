// Styles here will override Bulma styles
import styled from '@emotion/styled';
import { css } from '@emotion/core';
import media from 'css-in-js-media';

export const styledSection = css`
  padding-top: 32px;
  padding-bottom: 32px;
`;

export const StyledHeadingContainer = styled.div`
  display: flex;
  justify-content: flex-start;
  align-items: center;
  max-width: 870px;
  margin: 0 auto 16px auto;
  margin-top: -115px;
  padding-top: 115px;
`;

export const styledHeading = css`
  margin: 0 8px 0 0;
`;

export const StyledParagraph = styled.div`
  p {
    color: ${props => props.subheadingColor || '#5b6987'};
  }

  a {
    font-size: 16px;
    line-height: 160%;
    font-weight: normal;
    font-style: normal;
    font-family: 'Sailec-Regular';
    color: #0069ff;

    :hover {
      color: #1633ff !important;
    }
  }
`;

export const StyledToolTip = styled.div`
  position: relative;
  display: inline-block;

  :hover span {
    visibility: visible;
    opacity: 1;
  }
  ${media('< tablet')} {
    display: none;
  }
`;
export const StyledToolTipText = styled.span`
  visibility: hidden;
  width: 300px;
  background-color: #031b4e;
  color: #fff;
  text-align: left;
  padding: 10px;
  border-radius: 6px;
  font-size: 12px;

  /* Position the tooltip text */
  position: absolute;
  z-index: 1;
  bottom: 125%;
  left: 50%;
  margin-left: -60px;

  /* Fade in tooltip */
  opacity: 0;
  transition: opacity 0.3s;

  ::after {
    content: '';
    position: absolute;
    top: 100%;
    left: 18%;
    margin-left: -5px;
    border-width: 5px;
    border-style: solid;
    border-color: #031b4e transparent transparent transparent;
  }
`;

export const styledTable = css`
  max-width: 870px;
  margin: 0 auto;
  border-spacing: 0px;
  border-collapse: collapse;
  empty-cells: show;
  font-size: 14px;
  table-layout: fixed;
  margin-bottom: 40px;
  margin-top: 24px;

  ${media('< tablet')} {
    display: inline-block;
    overflow: scroll;
  }

  a {
    cursor: pointer;
    color: #0069ff;

    :hover {
      color: #1633ff !important;
    }
  }

  thead,
  tbody {
    td {
      color: #5b6987;
      background: #fff !important;
      border-bottom: 1px solid #e5e8ed;
      padding: 10px 0;
      vertical-align: middle;

      ${media('< tablet')} {
        min-width: 120px;
      }
    }
    th {
      padding: 10px 0;
      color: #031b4e !important;
      border-bottom: 2px solid #e5e8ed;
      font-family: 'Sailec-Bold';
      font-weight: normal;
    }
    td:last-child,
    th:last-child {
      width: 55px;
      padding-right: 0;
    }
  }

  tr:hover td {
    background-color: #f2f8ff !important;
  }
`;

export const styledLink = css`
  font-family: 'Sailec-Regular';
  font-weight: normal;
`;

export const StyledPopularPill = styled.span`
  background: #15cd72;
  color: #fff;
  font-size: 12px;
  padding: 3px 6px;
  border-radius: 100px;
  margin-left: 15px;
`;
