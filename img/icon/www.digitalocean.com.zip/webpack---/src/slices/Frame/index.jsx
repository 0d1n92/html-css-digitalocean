/* eslint-disable camelcase */
import React from 'react';
import PropTypes from 'prop-types';

import media from 'css-in-js-media';
import { css } from '@emotion/core';

const Frame = ({ input }) => {
  const { source } = input.primary;

  const styleBandwidthMediaQueries = css`
    overflow: hidden;
    position: relative;
    ${media('>= desktop')} {
      padding-top: 1274px;
    }
    ${media('< desktop')} {
      padding-top: 2200px;
    }
  `;

  const stylePricingMediaQueries = css`
    overflow: hidden;
    position: relative;
    ${media('>= desktop')} {
      padding-top: 1000px;
    }
    ${media('< desktop')} {
      padding-top: 1400px;
    }
  `;

  return (
    <div
      // TODO: Yes, this is bad. Solve this properly by working through iframe CORS issues (spy on the
      // iframe content height and set it dynamically, vet use of the react iframe-resizer component)
      // - OR -
      // use ~/hooks/useScript and ~/hooks/useStyles to load natively, and refactor to read bootstrap
      // DOM structure from Prismic. Will also require debugging some contexts within the individual apps.

      css={source.indexOf('pricing-calculator') !== -1 ? stylePricingMediaQueries : styleBandwidthMediaQueries}
    >
      <iframe
        title={source}
        id="iframe-content"
        scrolling="no"
        css={css`
          border: 0;
          height: 100%;
          left: 0;
          position: absolute;
          top: 0;
          width: 100%;
        `}
        src={source}
        border="none"
      />
    </div>
  );
};

export default Frame;

Frame.propTypes = {
  input: PropTypes.object.isRequired,
};
