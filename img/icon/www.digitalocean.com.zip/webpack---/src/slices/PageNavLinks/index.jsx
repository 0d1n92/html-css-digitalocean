/* eslint-disable camelcase */
import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';

import BulmaButton from 'react-bulma-components/lib/components/button';
import BulmaContainer from 'react-bulma-components/lib/components/container';

import { createRandomId } from '../../util/createRandomId';

import {
  PageNavLeftContainer,
  PageNavLeftWrapper,
  styledTab,
  styledLineContainer,
  styledLine,
} from './PageNavLinksStyles';

const ControlledTab = ({ label, navUrl, id, text_color, isSelected, onClick }) => {
  const activeLineColor = isSelected && text_color === 'dark' ? '#0069ff' : '#e5e8ed';

  return (
    <BulmaButton
      id={id}
      className={text_color === 'light' ? 'white' : 'darkblue nav-item'}
      style={{ color: isSelected ? '' : 'rgba(3, 27, 78, 0.6)' }}
      css={styledTab}
      onClick={onClick}
      url={navUrl}
    >
      {label}
      <svg css={styledLineContainer} style={{ backgroundColor: isSelected && activeLineColor }}>
        <line x1="1.5" x2="1.5" y1="2px" y2="48px" css={styledLine} className={isSelected ? 'selected' : ''} />
      </svg>
    </BulmaButton>
  );
};

const PageNavLinks = ({ input }) => {
  const { fields } = input;
  const [selected, setSelected] = useState(0);

  const setSelectedNav = anchor => {
    window.location.href = anchor;
  };

  useEffect(() => {
    if (window.location.hash) {
      const currentIndex = fields
        .map((item, i) => (item.link_url_anchor === window.location.hash ? i : null))
        .filter(i => i)[0];

      if (currentIndex) {
        setSelected(currentIndex);
      } else {
        setSelected(0);
      }
    }
  }, [selected]);

  return (
    <BulmaContainer>
      <PageNavLeftContainer id="pageNavLinks">
        <PageNavLeftWrapper>
          {fields.map((row, i) => (
            <ControlledTab
              id={`left-nav-${i}`}
              text_color="dark"
              key={createRandomId()}
              isSelected={selected === i}
              label={row.link_text}
              navUrl={row.link_url_anchor}
              onClick={() => setSelectedNav(row.link_url_anchor)}
            />
          ))}
        </PageNavLeftWrapper>
      </PageNavLeftContainer>
    </BulmaContainer>
  );
};

export default PageNavLinks;

PageNavLinks.propTypes = {
  input: PropTypes.object.isRequired,
};

ControlledTab.propTypes = {
  label: PropTypes.string.isRequired,
  navUrl: PropTypes.string.isRequired,
  id: PropTypes.node.isRequired,
  text_color: PropTypes.string,
  isSelected: PropTypes.string.isRequired,
  onClick: PropTypes.func.isRequired,
};

ControlledTab.defaultProps = {
  text_color: null,
};
