// Styles here will override Bulma styles
import { css, keyframes } from '@emotion/core';
import styled from '@emotion/styled';
import media from 'css-in-js-media';

const lineAnimation = keyframes`
  from {
    opacity: 0.0;
    stroke-dashoffset 50;
  }
  to {
    opacity: 1.0;
    stroke-dashoffset: 0;
  }
`;

const contentAnimation = keyframes`
  from {
    opacity: 0.0;
  }
  to {
    opacity: 1.0;
  }
`;

export const styledLineContainer = css`
  width: 2px;
  height: 100%;
  position: absolute;
  display: inline-block;
  background-color: #e5e8ed;
  border-radius: 8px;
  left: -10px;
  top: 0px;
`;

export const PageNavLeftContainer = styled.div `
  height: 8000px;
  width: 250px;
  position: absolute;
  top: 50px;

  ${media('< desktop')} {
    display: none;
  }
`;

export const PageNavLeftWrapper = styled.div `
  margin-left: -50px;
  position: sticky;
  position: -webkit-sticky;
  top: 100px;
`;

export const styledPageNavButton = css `
  font-family: 'Sailec-Medium','system-ui','-apple-system','BlinkMacSystemFont','Segoe UI','Roboto','Helvetica Neue','Helvetica','Arial','sans-serif';
  border: none;
  background: none;
  display: block;
  color: #031b4e;
  height: 100%;
  padding: 15px 20px;
  border-radius: 0px;
  white-space: inherit;
  height: auto;
  text-align: left;
`;

export const styledTab = css`
  font-family: 'Sailec-Medium', 'system-ui', '-apple-system', 'BlinkMacSystemFont', 'Segoe UI', 'Roboto',
    'Helvetica Neue', 'Helvetica', 'Arial', 'sans-serif';
  border: none;
  background: none;
  display: block;
  color: #031b4e;
  height: 50px;
  border-radius: 0px;
  margin: 0 20px;
  padding: 15px 20px;

  ${media('< desktop')} {
    padding-left: 20px;
    display: inline-block;
  }

  &:focus {
    border: none;
    box-shadow: none !important;
  }
  &.white {
    color: #fff;
  }
`;

export const styledLine = css`
  stroke: #e5e8ed;
  stroke-linecap: round;
  stroke-width: 3;
  transform: rotate(-90deg) translate(-6px, 1px) scale(4);
  z-index: 5;

  &.selected {
    stroke: #0069ff;
    animation: ${lineAnimation} 0.6s forwards;
  }

  ${media('< desktop')} {
    stroke-dasharray: 100%;
  }
`;
