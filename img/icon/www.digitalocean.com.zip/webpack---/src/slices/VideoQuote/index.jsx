/* eslint-disable camelcase */
import React from 'react';
import { css } from '@emotion/core';
import PropTypes from 'prop-types';

import BulmaSection from 'react-bulma-components/lib/components/section';
import BulmaContainer from 'react-bulma-components/lib/components/container';

import { Heading, Quote, WistiaVideo } from '../atoms';

import {
  styledHeading,
  styledSubHeading,
  styledVideoQuoteSection,
  StyledVideoQuoteContent,
  StyledVideoContainer,
  StyledQuoteContainer,
} from './VideoQuoteStyles';

const renderQuote = quoteProps => {
  const { wistia_video_id } = quoteProps;

  return (
    <StyledVideoQuoteContent>
      <StyledVideoContainer>
        <WistiaVideo wistiaId={wistia_video_id} />
      </StyledVideoContainer>
      <StyledQuoteContainer>
        <Quote quoteProps={quoteProps} />
      </StyledQuoteContainer>
    </StyledVideoQuoteContent>
  );
};

const VideoQuote = ({ input }) => {
  const {
    background_color,
    background_image,
    text_color,
    heading,
    heading_color,
    subheading,
    subheading_color,
  } = input.primary;
  return (
    <BulmaSection
      css={css`
        ${styledVideoQuoteSection}
        ${background_image ? `background-image: url(${background_image.url});` : null};
        background-color: ${background_color};
      `}
    >
      {heading && heading[0] && (
        <Heading
          renderAs="h2"
          className={text_color === 'light' ? 'h2 white' : 'h2 darkblue'}
          css={
            heading_color
              ? css`
                  color: ${heading_color} !important;
                `
              : styledHeading
          }
        >
          {heading[0].text}
        </Heading>
      )}
      {subheading && subheading[0] && (
        <Heading
          renderAs="p"
          subtitle
          className={text_color === 'light' ? 'white medium' : 'darkgrey medium'}
          css={
            heading_color
              ? css`
              ${styledSubHeading}
                color: ${subheading_color} !important;
              `
              : styledSubHeading
          }
        >
          {subheading[0].text}
        </Heading>
      )}
      <BulmaContainer>{renderQuote(input.primary)}</BulmaContainer>
    </BulmaSection>
  );
};

export default VideoQuote;

VideoQuote.propTypes = {
  input: PropTypes.object.isRequired,
};
