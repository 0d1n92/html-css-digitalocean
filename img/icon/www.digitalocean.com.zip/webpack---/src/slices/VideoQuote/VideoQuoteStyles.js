// Styles here will override Bulma styles
import { css } from '@emotion/core';
import styled from '@emotion/styled';
import media from 'css-in-js-media';

export const styledVideoQuoteSection = css`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  padding-top: 60px;
  padding-bottom: 60px;
`;

export const styledHeading = css`
  margin: 0 auto;
  text-align: center;
  margin-top: 16px !important;
`;

export const styledSubHeading = css`
  text-align: center;
`;

export const StyledVideoQuoteContent = styled.div`
  width: 100%;
  margin-top: 64px;
  display: flex;
  justify-content: center;
  align-items: center;

  ${media('< tablet')} {
    flex-direction: column;
    margin-bottom: 32px !important;
  }
`;

export const styledVideoQuoteLogoContainer = css`
  display: flex;
  align-items: center;
`;

export const StyledVideoContainer = styled.div`
  width: 100%;
  max-width: 550px;
  margin: 0 auto;
  ${media('< tablet')} {
    width: 100%;
  }
`;

export const StyledQuoteContainer = styled.div`
  max-width: 550px;
  margin-left: 64px;

  ${media('< tablet')} {
    margin-left: 0;
  }

  div {
    align-items: flex-start !important;
    ${media('< tablet')} {
      align-items: center !important;
    }
  }
`;
