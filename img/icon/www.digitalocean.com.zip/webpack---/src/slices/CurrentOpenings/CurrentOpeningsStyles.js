// Styles here will override Bulma styles
import { css } from '@emotion/core';
import styled from '@emotion/styled';
import media from 'css-in-js-media';

export const styledCurrentOpeningsSection = css`
  display: flex;
  flex-direction: column;
  justify-content: center;
`;

export const styledCurrentOpeningsContainer = css`
  width: 800px;
  max-width: 670px;
  ${media('< desktop')} {
    width: inherit;
    max-width: inherit;
  }
`;

export const styledHeading = css`
  text-align: center;
`;

export const styledSubheading = css`
  text-align: center;
  margin-top: 20px !important;
  margin-bottom: 65px !important;
`;

export const styledGrid = css`
  margin-left: 80px;
  column-count: 2;
  column-gap: 1rem;
  min-height: 400px;

  h1 {
    text-align: center;
  }

  h2 {
    text-align: center;
  }

  li {
    list-style: none;

    a {
      cursor: pointer;
    }

    p {
      margin-top: 0px;
    }
  }

  ${media('< largeDesktop')} {
    margin-left: 40px;
  }

  ${media('< desktop')} {
    display: flex;
    max-height: none;
    text-align: center;
    flex-direction: column;
    margin-left: 0px;
    margin-right: 0px;
  }
`;

export const styledColumn = css`
  padding: 12px;
  display: inline-block;
  width: 100%;
  box-sizing: border-box;

  a {
    color: #0069ff;
    font-family: 'Sailec-Bold', 'Helvetica', 'sans-serif';
    font-style: normal;
  }

  ${media('< desktop')} {
    width: 80%;
    margin: auto;
  }
`;

export const StyledDepartmentName = styled.h3`
  color: ${props => props.color};
`;
