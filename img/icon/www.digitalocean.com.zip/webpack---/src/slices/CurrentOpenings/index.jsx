/* eslint-disable camelcase */
import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';

import BulmaContainer from 'react-bulma-components/lib/components/container';
import BulmaSection from 'react-bulma-components/lib/components/section';

import { css } from '@emotion/core';
import { createRandomId } from '../../util/createRandomId';
import { Heading } from '../atoms';

import {
  styledHeading,
  styledSubheading,
  styledGrid,
  styledColumn,
  styledCurrentOpeningsSection,
  StyledDepartmentName,
} from './CurrentOpeningsStyles';

const renderHeading = (text, atts) => <Heading {...atts}>{text.text}</Heading>;

const CurrentOpenings = ({ input }) => {
  const {
    background_color,
    background_image,
    heading,
    heading_color,
    subheading,
    subheading_color,
    text_alignment,
    text_color,
  } = input.primary;
  const [jobOpenings, setJobOpenings] = useState([]);

  const createAvailableDepartmentsWithJobs = departmentsArr => {
    const departments = [];
    departmentsArr.forEach(department => {
      if (department.jobs.length <= 0) return;
      departments.push({ departmentName: department.name, jobs: department.jobs });
    });
    return departments;
  };

  useEffect(() => {
    const fetchDepartments = async () => {
      try {
        const response = await fetch('https://api.greenhouse.io/v1/boards/digitalocean98/embed/departments');
        const json = await response.json();
        setJobOpenings(createAvailableDepartmentsWithJobs(json.departments));
      } catch (e) {
        console.error(e.message);
      }
    };

    fetchDepartments();
  }, []);

  return (
    <BulmaSection
      css={css`
        ${styledCurrentOpeningsSection}
        background-color: ${background_color};
        ${background_image ? `background-image: url(${background_image.url});` : null};
        ${text_alignment === 'center' ? 'text-align: center;' : 'text-align: left;'}
      `}
    >
      <BulmaContainer>
        {heading && heading[0].text
          ? renderHeading(heading[0], {
              style: { color: heading_color || null, marginBottom: subheading && subheading[0].text ? '0' : '64px' },
              className: text_color === 'light' ? 'h2 white' : 'h2 darkblue',
              css: styledHeading,
              renderAs: 'h2',
              id: 'anchor--current-openings',
            })
          : null}
        {subheading && subheading[0].text
          ? renderHeading(subheading[0], {
              style: subheading_color ? { color: subheading_color } : null,
              className: text_color === 'light' ? 'medium white' : 'medium darkgrey',
              renderAs: 'p',
              subtitle: true,
              css: styledSubheading,
            })
          : null}
        <div css={styledGrid}>
          {jobOpenings &&
            jobOpenings.length > 0 &&
            jobOpenings.map(department => (
              <div css={styledColumn} key={createRandomId()}>
                <StyledDepartmentName color={text_color === 'light' ? '#fff' : '#031b4e'} data-testid="department_name">
                  {department.departmentName}
                </StyledDepartmentName>
                <ul>
                  {department.jobs.map(job => (
                    <li key={createRandomId()}>
                      <a href={job.absolute_url}>{job.title}</a>
                      <p data-testid="job_location">{job.location.name}</p>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
        </div>
      </BulmaContainer>
    </BulmaSection>
  );
};

export default CurrentOpenings;

CurrentOpenings.propTypes = {
  input: PropTypes.object.isRequired,
};
