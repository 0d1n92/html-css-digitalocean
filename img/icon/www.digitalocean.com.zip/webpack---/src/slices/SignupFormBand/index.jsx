/* eslint-disable */
/* eslint-disable camelcase */
import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { useForm } from 'react-hook-form';

import BulmaCard from 'react-bulma-components/lib/components/card';
import BulmaContainer from 'react-bulma-components/lib/components/container';
import BulmaHero from 'react-bulma-components/lib/components/hero';

import { RichText } from 'prismic-reactjs';
import { linkResolver } from '../../util/linkResolver';

import { createRandomId } from '../../util/createRandomId';
import { Heading, Button, LazyImage } from '../atoms';
import heroBg from '../../assets/images/bg-home-hero-3.svg';

import {
  styledHeroBox,
  styledHeroBoxTitle,
  StyledForm,
  styledHeroBoxContainerWrapper,
  StyledButtonsContainer,
  styledButton,
  styledButtonWText,
  StyledHeroCopy,
  StyledSubscript,
} from './SignupFormBandStyles';

const renderHeading = (text, atts) => <Heading {...atts}>{text.text}</Heading>;

const SignupFormBand = ({ input }) => {
  const {
    fullscreen,
    background_color,
    background_image,
    large_text,
    email_placeholder,
    form_title,
    name_placeholder,
    password_placeholder,
    headline,
    headline_color,
    subheadline,
    subheadline_color,
    submit_button_text,
    subscript,
    text_color,
  } = input.primary;

  const { fields } = input;

  const [validEmailClass, setValidEmailClass] = useState('hide-error');
  const [errorResponse, setErrorResponseMessage] = useState('');

  const { register, handleSubmit, watch, errors } = useForm();
  const onSubmit = data => {
    const getDomain = window.location.hostname;
    const devArray = ['www-static-site.web-experience.wolf.s2r1.internal.digitalocean.com','localhost'];
    const apiUrl = (devArray.indexOf(getDomain) != -1 ? 'cloud.s2r1.internal.digitalocean.com' : 'www.digitalocean.com');
    const formData = {"operationName":"createAccount","variables":{"createReq":{"name":data.name ,"password": data.password,"email": data.email}},"query":"mutation createAccount($createReq: CreateAccountRequest!) {\n  createAccount(CreateAccountRequest: $createReq) {\n    uuid\n    redirect_url\n    __typename\n  }\n}\n"};
    const myHeaders = new Headers({
      'Content-Type': 'application/json',
    });
    
    fetch(`https://${apiUrl}/graphql/public/register`, {
      method: 'POST', 
      headers: {
        'Content-Type': 'application/json',
        'apollographql-client-name': 'registration-gatsby-home-page',
        'apollographql-client-version': 'free-trial'
      },
      credentials: 'include',
      body: JSON.stringify(formData),
    })
    .then(res => {
      console.log('status two: ' + JSON.stringify(res.status))

      if (res.status === 403) {
        window.location.href =
          `https://${apiUrl}/graphql/public/test?challenge=https://${getDomain}/about/suf/`;
      }

      if (res.status === 200) {
        return res.json()
      }
    })
    .then(data => {
      console.log('data: ' + JSON.stringify(data))
      if (data.errors) {
        returnErrorResponse(data.errors[0].message);
      }

      /*if (!data.errors) {
        window.location.href = `https://cloud.digitalocean.com`
      }*/

    })
    .catch((error) => {
      console.error('Error:', error);
    });

  };

  const onChange = event => {
    const { value } = event.target;
    const checkEmailFormat = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);

    !checkEmailFormat ? setValidEmailClass('show-error error-text') : setValidEmailClass('hide-error');
  };

  const onButtonClick = event => {
    window.location.href = event.currentTarget.dataset.href;
  };

  const returnErrorResponse = data => {
    switch (data) {
      case 'unknown':
        setErrorResponseMessage('Please try your request again. If the problem persists, contact customer support.');
        break;
      case 'password_is_common':
        setErrorResponseMessage('Please choose a less-common password.');
        break;
      case 'password_is_email':
        setErrorResponseMessage('Please ensure that your password is distinct from your email address.');
        break;
      case 'password_is_name':
        setErrorResponseMessage('Please ensure that your password is distinct from your name.');
        break;
      case 'email_exists':
        setErrorResponseMessage('Sorry, that email address is already associated with an account.');
        break;
      case 'too_long':
        setErrorResponseMessage('Sorry, that email address is already associated with an account.');
        break;
      case 'password_missing_unique_chars':
        setErrorResponseMessage('Your password must contain unique charcters.');
        break;
      default:
        setErrorResponseMessage('There was a problem with your request. Please try again.');
    }
  };
  return (
    <BulmaHero
      data-testid="bulma_hero"
      css={styledHeroBoxContainerWrapper}
      style={{
        backgroundColor: background_color || '#031b4e',
        backgroundImage: background_image && background_image.url ? `url(${background_image.url})` : `url(${heroBg})`,
      }}
    >
      <BulmaHero.Body>
        <BulmaContainer>
          <StyledHeroCopy>
            {renderHeading(headline[0], {
              style: headline_color ? { color: headline_color } : null,
              className: `${text_color === 'light' ? 'h1 white' : 'h1 darkblue'} ${large_text ? 'hero-title' : ''}`,
              renderAs: 'h1',
              'data-testid': 'hero_heading',
            })}
            {renderHeading(subheadline[0], {
              style: subheadline_color && { color: subheadline_color },
              className: text_color === 'light' ? 'large white' : 'large darkgrey',
              subtitle: true,
              renderAs: 'p',
              'data-testid': 'hero_subheading',
            })}
          </StyledHeroCopy>
          <div>
            <BulmaCard css={styledHeroBox} data-testid="hero_box">
              <BulmaCard.Header.Title css={styledHeroBoxTitle}>
                {renderHeading(form_title[0], {
                  className: 'h5 darkblue',
                  renderAs: 'h5',
                  'data-testid': 'hero_box_title',
                })}
              </BulmaCard.Header.Title>
              <BulmaCard.Content>
                <StyledForm className="form-align-left" onSubmit={handleSubmit(onSubmit)}>
                  <span className="form-wrapper">
                    <span className="error-text">{errorResponse}</span>
                    <input
                      type="text"
                      name="name"
                      className={errors.name ? 'error-border' : 'error-none'}
                      placeholder={name_placeholder}
                      ref={register({ required: true, maxLength: 20 })}
                      aria-label="name field"
                    />
                    {errors.name && <span className="error-text">Name is a required field</span>}
                    <input
                      type="text"
                      name="email"
                      className={errors.email ? 'error-border' : 'error-none'}
                      placeholder={email_placeholder}
                      onChange={onChange}
                      ref={register({ required: true })}
                      aria-label="email field"
                    />
                    <span className={validEmailClass}>A valid email is required</span>
                    {errors.email && <span className="error-text">A valid email is required</span>}
                    <input
                      type="password"
                      name="password"
                      className={errors.password ? 'error-border' : 'error-none'}
                      placeholder={password_placeholder}
                      ref={register({ required: true })}
                      aria-label="password field"
                    />
                    {errors.password && <span className="error-text">Password is a required field</span>}
                    <input aria-label="submit button" type="submit" value={submit_button_text} />
                  </span>
                </StyledForm>
              </BulmaCard.Content>
              <StyledButtonsContainer>
                {fields.map(button => (
                  <Button
                    css={button.button_text !== null ? styledButtonWText : styledButton}
                    key={createRandomId()}
                    onClick={onButtonClick}
                    data-href={button.button_link.url}
                    id={button.button_text || 'github_button'}
                    aria-label={button.button_text || 'signup_button'}
                  >
                    <LazyImage src={button.icon.url} alt={button.icon.alt || button.button_text || 'icon'} />
                    {button.button_text}
                  </Button>
                ))}
              </StyledButtonsContainer>
            </BulmaCard>
            <StyledSubscript>
              <RichText render={subscript} linkResolver={linkResolver} />
            </StyledSubscript>
          </div>
        </BulmaContainer>
      </BulmaHero.Body>
    </BulmaHero>
  );
};

export default SignupFormBand;

SignupFormBand.propTypes = {
  input: PropTypes.object.isRequired,
};
