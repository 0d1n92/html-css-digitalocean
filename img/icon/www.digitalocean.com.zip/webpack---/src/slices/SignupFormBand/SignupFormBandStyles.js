import { css } from '@emotion/core';
import media from 'css-in-js-media';
import styled from '@emotion/styled';

export const styledHeroBoxContainerWrapper = css`
  background-size: cover;
  background-position: center;
  -webkit-backface-visibility: hidden;
  -webkit-transform: translateZ(0) scale(1, 1);
  transform: translateZ(0);

  .hero-body {
    padding: 0;
  }

  .container {
    height: 800px;
    display: grid;
    grid-template-columns: 1fr 370px;
    grid-template-rows: auto;
    align-items: center;

    ${media('< desktop')} {
      display: flex;
      flex-direction: column;
      margin-top: 32px;
      margin-bottom: 64px;
    }
  }
`;

export const StyledHeroCopy = styled.div`
  max-width: 670px;

  ${media('< desktop')} {
    margin: auto !important;
    text-align: center;
  }
`;

export const StyledSmallHeading = styled.div`
  display: flex;

  h6 {
    letter-spacing: 1px !important;
  }

  ${media('< desktop')} {
    margin-right: 0px;
    justify-content: center;
    h6 {
      margin-right: 10px !important;
    }
  }
`;

export const styledHeroBox = css`
  display: flex;
  flex-direction: column;
  align-items: center;
  min-width: 370px;
  margin: 0;
  border-radius: 6px;

  .card-content {
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    min-height: 220px;
    text-align: center;
    padding: 32px;
  }

  ${media('< desktop')} {
    min-width: 320px;
    max-width: 370px;
    margin-top: 32px;
  }
`;

export const styledHeroBoxTitle = css`
  flex: 0 !important;
  width: 100%;
  justify-content: center;
  border-radius: 6px 6px 0px 0px;
  background-color: #f3f5f9;
  padding: 16px 0 12px 0;

  h5 {
    margin-top: 0px;
    display: flex;
    align-items: center;
    height: 36px;
  }
`;

export const StyledForm = styled.form`
  .form-wrapper {
    display: inline-block;
    text-align: left;
  }

  .hide-error {
    display: none;
  }

  .show-error {
    display: block;
  }

  input {
    width: 100%;
    height: 48px;
    border: 1px solid #e5e8ed;
    box-sizing: border-box;
    border-radius: 3px;
    margin-bottom: 8px;

    font-family: 'Sailec-Regular';
    font-size: 16px;
    padding: 16px;
    color: #031b4e;

    :focus {
      border-color: #0069ff;
      outline: #0069ff;
    }
  }

  input.error-border {
    border: solid 1px #ca0c0c;
  }

  input[type='submit'] {
    background: #0069ff;
    border: none;
    line-height: 100%;
    font-family: 'Sailec-Bold';
    color: #fff;
    padding: 17px;
    cursor: pointer;
    margin-bottom: 0;
  }

  span.error-text {
    color: #ca0c0c;
    display: inline-block;
    font-family: 'Sailec-Regular';
    font-size: 12px;
    margin-bottom: 16px;
    text-align: left;
  }
`;

export const StyledButtonsContainer = styled.div`
  border-top: 1px solid #f3f5f9;
  width: 306px;
  padding: 32px;
  display: flex;
  justify-content: space-between;
`;

export const styledButton = css`
  height: 48px;
  padding: 16px;
  margin: 0;
  border: 1px solid #0069ff;
`;

export const styledButtonWText = css`
  height: 48px;
  padding: 13px 30px 16px 30px;
  margin: 0;
  display: flex;
  align-items: flex-start;
  border: 1px solid #0069ff;
  color: #0069ff;

  img {
    margin-top: 1px;
    margin-right: 6px;
  }
`;

export const StyledSubscript = styled.div`
  p,
  a {
    font-family: 'Sailec-Regular';
    font-size: 12px;
    text-align: center;
    color: #fff;
  }

  a:hover {
    color: white !important;
    border-bottom: dotted 1px rgba(255, 255, 255, 0.5);
  }
`;
