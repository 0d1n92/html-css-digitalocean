// Styles here will override Bulma styles
import { css } from '@emotion/core';
import styled from '@emotion/styled';
import media from 'css-in-js-media';

export const styledListGridSection = css`
  background: repeat;
  overflow: hidden;
  .container {
    justify-content: center;
    align-items: center;
    display: flex;
    flex-direction: column;
  }
`;

export const StyledGrid = styled.div`
  display: grid;
  grid-auto-flow: dense;
  grid-gap: 64px;
  grid-auto-rows: 1fr;
  grid-template-columns: ${props => props.gridTemplateColumns};
  margin-left: ${props => props.marginLeft};
  margin-top: ${props => props.marginTop};
  margin-bottom: ${props => props.marginBottom};

  ${media('< desktop')} {
    display: flex;
    flex-direction: column;
    margin-top: 25px;
    margin-left: 0px;
    margin-right: 0px;
  }
`;

export const styledColumn = css`
  padding-bottom: 28px !important;

  ${media('< desktop')} {
    text-align: center !important;
    width: 80% !important;
    margin: 0 auto;
    padding-bottom: 12px !important;
    flex-direction: column;
    align-items: center;
  }
`;

export const styledIcon = css`
  min-height: 50px;
  max-height: 128px;
  margin-right: 35px;
  display: flex;
  justify-content: flex-end;

  ${media('< desktop')} {
    margin: 40px auto 0px auto !important;
    min-width: 120px;
  }
`;

export const StyledHeadingContainer = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-bottom: 30px;

  p {
    text-align: center;
  }
`;

export const StyledFeature = styled.div`
  display: flex;
  text-align: ${props => props.textAlign};
  flex-direction: ${props => (props.iconPosition === 'top' ? 'column' : 'row')};
  margin: 0 auto;

  p {
    max-width: 580px;
    line-height: 160%;
  }

  ${media('<desktop')} {
    max-width: 80%;
    flex-direction: column;
    text-align: center;
  }

  ${media('< tablet')} {
    width: 95%;
  }
`;

export const styledTitle = css`
  margin-top: 25px !important;
  ${media('< desktop')} {
    width: 80%;
    margin: 0 auto;
    text-align: center;
  }
`;

export const styledHeading = css`
  text-align: center;
`;

export const styledSubheading = css`
  max-width: 670px;
  text-align: center;

  ${media('< desktop')} {
    margin-bottom: 60px !important;
  }
`;

export const styledLink = css`
  ${media('< desktop')} {
    width: 80%;
    margin: 20px auto;
    text-align: center;
    display: block;
  }
`;

export const styledButton = css`
  margin-top: 32px;
`;

export const StyledAnnotation = styled.p`
  margin-top: 64px;
  text-align: center;
  font-size: 10px;
  max-width: 770px;
`;
