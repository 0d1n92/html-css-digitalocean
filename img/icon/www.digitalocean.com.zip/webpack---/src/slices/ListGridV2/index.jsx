/* eslint-disable camelcase */
import React from 'react';
import PropTypes from 'prop-types';

import BulmaContainer from 'react-bulma-components/lib/components/container';
import BulmaSection from 'react-bulma-components/lib/components/section';

import { createRandomId } from '../../util/createRandomId';

import { Heading, TextLink, Button, LazyLink, LazyImage } from '../atoms';

import {
  styledIcon,
  styledTitle,
  styledLink,
  styledHeading,
  styledSubheading,
  StyledGrid,
  styledListGridSection,
  StyledFeature,
  styledButton,
  StyledAnnotation,
} from './ListGridV2Styles';

const renderHeading = (text, atts) => (
  <Heading {...atts} css={atts.css}>
    {text.text}
  </Heading>
);

const renderList = (
  icon,
  title,
  text,
  link,
  linkText,
  iconSize,
  iconPosition,
  itemHeadingColor,
  itemTextColor,
  defaultTextColor,
  contentAlignment,
) => (
  <StyledFeature textAlign={contentAlignment} iconPosition={iconPosition} key={createRandomId()}>
    {icon && icon.url ? (
      <LazyImage
        data-testid="item_icon"
        src={icon && icon.url}
        width={Number(iconSize)}
        css={styledIcon}
        style={{
          margin: contentAlignment === 'left' ? '0px 30px 0px 0px' : '0 auto',
          minWidth: iconPosition === 'left' ? '160px' : 'auto',
          maxWidth: iconSize === '48' ? '40px' : 'auto',
          alignItems: iconPosition === 'left' ? 'flex-start' : 'flex-end',
        }}
      />
    ) : null}
    <div>
      {title
        ? renderHeading(title[0], {
            'data-testid': 'item_title',
            css: styledTitle,
            style: itemHeadingColor ? { color: itemHeadingColor } : null,
            className: defaultTextColor === 'light' ? 'h5 white' : 'h5 darkblue',
            renderAs: 'h5',
          })
        : null}
      {text
        ? renderHeading(text[0], {
            'data-testid': 'item_text',
            className: defaultTextColor === 'light' ? 'white' : 'darkgrey',
            subtitle: true,
            renderAs: 'p',
            style: {
              margin: `10px ${contentAlignment === 'left' ? 0 : 'auto'}`,
              color: itemTextColor || null,
            },
          })
        : null}
      {link && link.url && linkText && linkText[0].text && (
        <TextLink data-testid="item_link_text" css={styledLink} className="medium arrow" url={link.url}>
          {linkText[0].text}
        </TextLink>
      )}
    </div>
  </StyledFeature>
);

const ListGridV2 = ({ input }) => {
  const {
    text_color,
    background_color,
    background_image,
    heading,
    heading_color,
    subheading,
    subheading_color,
    list_item_alignment_position,
    list_item_icon_position,
    list_item_icon_size,
    list_column_number,
    list_item_heading_color,
    list_item_text_color,
    cta_button_text,
    cta_button_url,
    annotation,
  } = input.primary;

  return (
    <BulmaSection
      id="ListGrid"
      css={styledListGridSection}
      style={{
        backgroundColor: background_color || '#fff',
        backgroundImage: background_image && background_image.url ? `url(${background_image.url})` : null,
      }}
    >
      <BulmaContainer>
        {heading &&
          heading[0].text &&
          renderHeading(heading[0], {
            'data-testid': 'heading',
            renderAs: 'h2',
            style: heading_color ? { color: heading_color } : null,
            className: text_color === 'light' ? 'h2 white' : 'h2 darkblue',
            css: styledHeading,
          })}
        {subheading &&
          subheading[0].text &&
          renderHeading(subheading[0], {
            'data-testid': 'subheading',
            renderAs: 'p',
            style: subheading_color ? { color: subheading_color } : null,
            className: text_color === 'light' ? 'medium white' : 'medium darkgrey',
            subtitle: true,
            css: styledSubheading,
          })}
        <StyledGrid
          gridTemplateColumns={`repeat(${list_column_number}, 1fr)`}
          marginTop={heading || subheading ? '64px' : 0}
          marginBottom={cta_button_url ? '64px' : 0}
        >
          {input.fields.map(item =>
            renderList(
              item.list_item_icon,
              item.list_item_heading,
              item.list_item_text,
              item.list_item_url_link,
              item.list_item_url_text,
              list_item_icon_size,
              list_item_icon_position,
              list_item_heading_color,
              list_item_text_color,
              text_color,
              list_item_alignment_position,
            ),
          )}
        </StyledGrid>
        {cta_button_url && cta_button_url.url ? (
          <Button
            css={styledButton}
            color={text_color === 'light' ? 'white' : 'primary'}
            outlined
            renderAs={LazyLink}
            url={cta_button_url.url}
          >
            {cta_button_text}
          </Button>
        ) : null}
        {annotation ? <StyledAnnotation>{annotation[0].text}</StyledAnnotation> : null}
      </BulmaContainer>
    </BulmaSection>
  );
};

export default ListGridV2;

ListGridV2.propTypes = {
  input: PropTypes.object.isRequired,
};
