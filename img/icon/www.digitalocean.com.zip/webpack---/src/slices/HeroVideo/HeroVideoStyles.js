import { css } from '@emotion/core';
import styled from '@emotion/styled';
import media from 'css-in-js-media';

export const styledVideoHeroSection = css`
  background: darkblue;
  padding: 0;
  margin-top: 106px;
  height: 750px;

  ${media('< desktop')} {
    margin-top: -65px;
    height: auto;
  }

  video::-webkit-media-controls-start-playback-button {
    display: none;
  }
`;

export const styledVideoHeroFullscreen = css`
  display: flex;
  flex-direction: column;
  justify-content: center;
  height: 100vh;
`;

export const styledVideoHero = css`
  z-index: 10;
  position: relative;
  height: 750px;

  div.hero-body {
    display: flex;
    flex-direction: column;
    text-align: center;
    justify-content: center;
    align-items: center;

    p.subtitle {
      margin-bottom: 40px;
      max-width: 470px;
      font-size: 24px;
      line-height: 150%;
      margin-top: 20px;
    }

    .buttons {
      justify-content: space-between;
      margin-bottom: 0px;

      .is-primary {
        margin-right: 20px;
      }

      .is-primary:nth-of-type(2) {
        margin-right: 0px !important;
      }
    }
  }
`;

export const styledButtonContainer = css`
  margin-top: 32px;
`;

export const StyledVideoPlay = styled.div`
  display: flex;
  color: #fff;
  cursor: pointer;
  transition: all 0.3s ease;
  margin-top: 32px;

  &:hover {
    transform: scale(1.04);
  }

  figure {
    width: 20px;
    height: 20px;
    margin: 0 4px 0 0;
  }

  p {
    font-size: 0.75em;
    line-height: 2em;
    margin: 0 2px;
  }
`;

export const styledModal = css`
  margin: auto;
  border-radius: 3px;
  max-width: 80%;

  ${media('< desktop')} {
    max-width: 95%;
  }

  div:only-child {
    margin: 0 auto;
    width: 100%;
    height: 100%;
    border-radius: 3px;
  }
`;

export const StyledVideoContainer = styled.div`
  position: absolute;
  border-radius: 5px;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  z-index: 1;
  opacity: 0.6;
  height: 750px;
`;

export const StyledBackgroundVideo = styled.video`
  position: absolute;
  top: 0;
  overflow: hidden;
  height: 750px;
  width: 100%;
  object-fit: cover;
`;
