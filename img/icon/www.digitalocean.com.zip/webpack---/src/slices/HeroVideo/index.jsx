/* eslint-disable jsx-a11y/media-has-caption */
/* eslint-disable camelcase */
import React, { useState } from 'react';
import PropTypes from 'prop-types';

import { css } from '@emotion/core';

import BulmaButton from 'react-bulma-components/lib/components/button';
import BulmaHero from 'react-bulma-components/lib/components/hero';
import BulmaSection from 'react-bulma-components/lib/components/section';

import { Button, Heading, Modal, WistiaVideo, LazyLink, LazyImage } from '../atoms';

import {
  StyledBackgroundVideo,
  StyledVideoContainer,
  styledVideoHero,
  styledVideoHeroSection,
  styledVideoHeroFullscreen,
  styledButtonContainer,
  StyledVideoPlay,
  styledModal,
} from './HeroVideoStyles';

const renderHeading = (text, atts) => <Heading {...atts}>{text.text}</Heading>;

const renderButton = (link, text, atts) => (
  <Button renderAs={LazyLink} {...atts} url={link.url}>
    {text.text}
  </Button>
);

const HeroVideo = ({ input }) => {
  const {
    fullscreen,
    large_text,
    text_color,
    heading,
    heading_color,
    subheading,
    subheading_color,
    cta_text_primary,
    cta_url_primary,
    cta_text_secondary,
    cta_url_secondary,
    hero_video_url,
    hero_video_placeholder_img,
    video_icon,
    video_timestamp,
    video_timestamp_color,
    video_title,
    video_title_color,
    video_wistia_id,
    hero_video_color_overlay,
  } = input.primary;

  const [modalIsShowing, setModalIsShowing] = useState(false);

  const renderVideoModal = wistiaId => (
    <Modal show={modalIsShowing} css={styledModal} onClose={() => setModalIsShowing(false)}>
      <WistiaVideo wistiaId={wistiaId} autoplay />
    </Modal>
  );

  return (
    <BulmaSection
      css={css`
        ${styledVideoHeroSection}
        ${fullscreen && styledVideoHeroFullscreen}
      `}
    >
      <BulmaHero css={styledVideoHero}>
        <BulmaHero.Body>
          {renderHeading(heading[0], {
            style: heading_color ? { color: heading_color } : null,
            className: `${text_color === 'light' ? 'h1 white' : 'h1 darkblue'} ${large_text ? 'hero-title' : ''}`,
          })}
          {renderHeading(subheading[0], {
            style: subheading_color ? { color: subheading_color } : null,
            className: text_color === 'light' ? 'large white' : 'large darkgrey',
            subtitle: true,
            renderAs: 'p',
          })}
          <BulmaButton.Group css={styledButtonContainer}>
            {renderButton(cta_url_primary, cta_text_primary[0], { color: 'primary' })}
            {renderButton(cta_url_secondary, cta_text_secondary[0], {
              color: text_color === 'light' ? 'white' : 'primary',
              outlined: true,
            })}
          </BulmaButton.Group>
          <StyledVideoPlay
            role="button"
            tabIndex="0"
            onClick={() => setModalIsShowing(true)}
            onKeyPress={() => setModalIsShowing(true)}
            id="testVideoPlayButton"
          >
            <LazyImage src={video_icon.url} width={20} bulma />
            <p style={{ color: video_title_color || (text_color === 'light' ? 'white' : '#5b6987') }}>
              {video_title[0].text}
            </p>
            <p
              style={{
                color: video_timestamp_color || (text_color === 'light' ? 'white' : '#5b6987'),
              }}
            >
              {video_timestamp[0].text}
            </p>
          </StyledVideoPlay>
        </BulmaHero.Body>
      </BulmaHero>
      <StyledVideoContainer
        css={{
          background: `${hero_video_color_overlay}`,
        }}
      />
      <StyledBackgroundVideo
        src={hero_video_url && hero_video_url.url ? hero_video_url.url : null}
        autoPlay="autoplay"
        loop="loop"
        muted="muted"
        poster={hero_video_placeholder_img && hero_video_placeholder_img.url ? hero_video_placeholder_img.url : null}
      />
      {renderVideoModal(video_wistia_id)}
    </BulmaSection>
  );
};

export default HeroVideo;

HeroVideo.propTypes = {
  input: PropTypes.object.isRequired,
};
