// Styles here will override Bulma styles
import { css } from '@emotion/core';
import styled from '@emotion/styled';
import media from 'css-in-js-media';

export const styledHeroTextSection = css`
  display: flex;
  flex-direction: column;
  justify-content: center;
  padding-top: 120px;
  padding-bottom: 120px;
  background-repeat: no-repeat;
  background-size: cover;
  background-position: bottom;
  height: 360px;

  ${media('< tablet')} {
    padding-top: 64px;
    padding-bottom: 64px;
  }
`;

export const styledHeroTextFullscreen = css`
  height: calc(100vh - 305px);
  display: flex;
  flex-direction: column;
  justify-content: center;

  ${media('< desktop')} {
    height: calc(100vh - 195px);
  }
`;

export const styledCenterHeroSearch = css`
  line-height: 120% !important;
  display: flex;
  flex-direction: column;
  align-items: center;

  h1,
  h2,
  h3,
  h4,
  h5,
  p {
    margin: 0 auto;
  }

  ${media('< desktop')} {
    width: inherit;
    max-width: inherit;
  }
`;

export const styledHeading = css`
  max-width: 670px;
  line-height: 110% !important;
`;

export const styledSubHeading = css`
  max-width: 670px !important;
`;

export const StyledSearchField = styled.div`
  margin-top: 64px;
  width: 100%;
  max-width: 670px;
  height: 18px;
  background: white;
  border-radius: 4px;
  text-align: left;
  padding: 16px 20px 15px 20px;
  color: #5b6987;
`;
