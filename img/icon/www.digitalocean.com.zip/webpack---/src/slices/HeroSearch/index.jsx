/* eslint-disable camelcase */
import React from 'react';
import PropTypes from 'prop-types';

import BulmaContainer from 'react-bulma-components/lib/components/container';
import BulmaSection from 'react-bulma-components/lib/components/section';

import { css } from '@emotion/core';
import { Heading, Search } from '../atoms';

import {
  styledHeading,
  styledSubHeading,
  styledCenterHeroSearch,
  StyledSearchField,
  styledHeroTextSection,
  styledHeroTextFullscreen,
} from './HeroSearchStyles';

const renderHeading = (text, atts) => <Heading {...atts}>{text.text}</Heading>;

const HeroSearch = ({ input }) => {
  const {
    fullscreen,
    large_text,
    text_color,
    background_color,
    background_image,
    heading,
    subheading,
    text_alignment,
    search_field_placeholder_text,
  } = input.primary;

  return (
    <BulmaSection
      css={css`
        ${styledHeroTextSection}
        background-color: ${background_color};
        ${background_image ? `background-image: url(${background_image.url});` : null};
        ${text_alignment === 'center' ? 'text-align: center;' : 'text-align: left;'}
        ${fullscreen && styledHeroTextFullscreen}
      `}
    >
      <BulmaContainer css={text_alignment === 'center' ? styledCenterHeroSearch : null}>
        {heading && heading[0]
          ? renderHeading(heading[0], {
              id: 'herotext-heading',
              className: `${text_color === 'light' ? 'h1 white' : 'h1 darkblue'} ${large_text ? 'hero-title' : ''}`,
              css: styledHeading,
              style: { margin: text_alignment === 'left' ? '0' : '' },
            })
          : null}
        {subheading && subheading[0]
          ? renderHeading(subheading[0], {
              id: 'herotext-subheading',
              className: `${text_color === 'light' ? 'large white' : 'large darkblue'}`,
              renderAs: 'p',
              subtitle: true,
              css: styledSubHeading,
              style: { margin: text_alignment === 'left' ? '0' : '' },
            })
          : null}
        <Search
          options={`{
            algolia_app_id: '6ZHEUVKJ88',
            algolia_public_key: 'c5470567eae7fa1177d43222e18ba086',
            search_on_slash: true,
            empty_state_element: 'noResultsElement',
            primary_list: ['alldocs', 'community', 'marketplace'],
            secondary_list: ['quicknav'],
            element_id: 'herosearch',
          }`}
        >
          <StyledSearchField id="herosearch"> {search_field_placeholder_text || '/'}</StyledSearchField>
        </Search>
      </BulmaContainer>
    </BulmaSection>
  );
};

export default HeroSearch;

HeroSearch.propTypes = {
  input: PropTypes.object.isRequired,
};
