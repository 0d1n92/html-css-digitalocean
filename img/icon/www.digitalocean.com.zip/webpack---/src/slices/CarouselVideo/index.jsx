/* eslint-disable camelcase */
import React from 'react';
import PropTypes from 'prop-types';
import BulmaSection from 'react-bulma-components/lib/components/section';

import { css } from '@emotion/core';
import { Carousel, Heading, WistiaVideo } from '../atoms';

import {
  styledSubHeading,
  styledCarouselVideoSection,
  styledVideoContainer,
  StyledImageText,
} from './CarouselVideoStyles';

const CarouselVideo = ({ input }) => {
  const {
    background_color,
    background_image,
    text_color,
    heading,
    heading_color,
    subheading,
    subheading_color,
  } = input.primary;

  return (
    <BulmaSection
      css={css`
        ${styledCarouselVideoSection}
        ${background_image ? `background-image: url(${background_image.url});` : null};
        background-color: ${background_color};
      `}
    >
      <Heading
        id="testCarouselVideoHeading"
        renderAs="h2"
        className={text_color === 'light' ? 'h2 white' : 'h2 darkblue'}
        css={css`
          color: ${heading_color} !important;
        `}
      >
        {heading[0].text}
      </Heading>
      <Heading
        id="testCarouselVideoSubheading"
        renderAs="h4"
        subtitle
        className={text_color === 'light' ? 'h4 grey light' : 'h4 darkblue light'}
        css={css`
          ${styledSubHeading}
          color: ${subheading_color} !important;
        `}
      >
        {subheading[0].text}
      </Heading>
      <Carousel
        fadeIn
        text_color={text_color}
        selectColor={text_color === 'light' ? '#fff' : '#1633ff'}
        id="testCarouselVideo"
      >
        {input.fields.map((field, index) => (
          <div css={styledVideoContainer}>
            <WistiaVideo wistiaId={field.wistia_video_id} />
            <StyledImageText
              id={`testCarouselVideo-${index}`}
              className={text_color === 'light' ? 'white' : 'darkblue'}
              css={css`
                color: ${field.video_text_color} !important;
              `}
            >
              {field.video_text[0].text}
            </StyledImageText>
          </div>
        ))}
      </Carousel>
    </BulmaSection>
  );
};
export default CarouselVideo;

CarouselVideo.propTypes = {
  input: PropTypes.object.isRequired,
};
