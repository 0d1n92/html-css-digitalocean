// Styles here will override Bulma styles
import { css } from '@emotion/core';
import styled from '@emotion/styled';

export const styledCarouselVideoSection = css`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  padding-top: 80px;
  padding-bottom: 80px;
`;

export const styledSubHeading = css`
  margin-top: 10px !important;
`;

export const styledVideoContainer = css`
  max-width: 870px;
  margin: 0 auto;
  margin-top: 32px;
`;

export const StyledImageText = styled.p`
  text-align: center;
  width: 100%;
  margin-top: 40px;
  &.white {
    color: #fff;
  }
  &.darkblue {
    color: #031b4e;
  }
`;
