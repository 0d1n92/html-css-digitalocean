/* eslint-disable camelcase */
import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { useForm } from 'react-hook-form';
import DatePicker from 'react-datepicker';

import BulmaContainer from 'react-bulma-components/lib/components/container';
import BulmaSection from 'react-bulma-components/lib/components/section';

import { RichText } from 'prismic-reactjs';
import { Heading } from '../atoms';
import { linkResolver } from '../../util/linkResolver';
import { encodeFormData } from '../../util/encodeFormData';
import { encodeHiddenFormValues } from '../../util/encodeHiddenFormValues';
import { encodeUrlParams } from '../../util/encodeUrlParams';
import { mktoFormDetails } from '../../util/mktoFormDetails';

import {
  StyledForm,
  styledHeading,
  styledSubheading,
  styledFormReady,
  StyledThankYouWrapper,
  StyledSubscript,
  sectionContainer,
} from './DynamicFormBuilderStyles';

const setFormNameArry = [];

const DynamicFormBuilder = ({ input }) => {
  const {
    footer_form_text,
    form_anchor_name,
    form_post_location,
    header_form_text,
    marketo_form_id,
    munchkin_account_id,
    sub_header_form_text,
    thank_you_message,
  } = input.primary;

  const [validEmailClass, setValidEmailClass] = useState('hide-error');
  const [formShow, setFormClass] = useState('form-ready anchor');
  const [thankYouShow, setThankYouClass] = useState('is-none');
  const [currentDate, setCurrentDate] = useState(new Date());
  const [eventDateValue, setEventDateValue] = useState('');
  const [alphanumericError, setAlphanumericError] = useState([]);

  const { register, handleSubmit, errors } = useForm();

  const onSubmit = data => {
    // We send the data object form field key names and setFormNameArry to the encodeFormData function
    const urlEncodeFormData = encodeFormData(Object.keys(data), setFormNameArry, data);

    // We send the data object form field key names and setFormNameArry to the hiddenValues function
    const urlEncodeFormDataHidden = encodeHiddenFormValues(Object.keys(data), setFormNameArry, data);

    // Get all querystring paramters
    const urlParamSearch = Object.fromEntries(new URLSearchParams(window.location.search));
    // Send all the querystring parameter keys, current URL, marketo form ID and muchkin account ID to the encodeUrlParams function
    const urlEncodeDataParams = Object.keys(urlParamSearch).length
      ? encodeUrlParams(Object.keys(urlParamSearch), new URL(document.location.href))
      : '';

    // Always send the Marketo form details: form ID, munchkin code, referring URL
    const urlEncodeMktoDetails = mktoFormDetails(window.location.href, marketo_form_id, munchkin_account_id);

    // Concat all the form data, hidden form data and querystring data together for the post to marketo
    const concatAllValues = urlEncodeFormData
      .concat(urlEncodeFormDataHidden)
      .concat(urlEncodeDataParams)
      .concat(urlEncodeMktoDetails);

    fetch(form_post_location, {
      method: 'POST',
      mode: 'no-cors',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: concatAllValues,
    })
      .then(response => {
        setFormClass('form-ready is-none');
        setThankYouClass('is-block');
      })
      .catch(error => {
        console.error('Error:', error);
      });
  };
  const onChange = event => {
    if (event.target.name === 'email') {
      const { value } = event.target;
      const checkEmailFormat = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);

      !checkEmailFormat ? setValidEmailClass('show-error error-text') : setValidEmailClass('hide-error');
    }

    // Logic for fields that require alphanumeric values
    if (event.target.dataset.alphanumeric === 'true') {
      const checkAplhaNumeric = /^[a-z0-9]+$/.test(event.target.value);

      !checkAplhaNumeric
        ? setAlphanumericError({ [event.target.name]: `The field ${event.target.name} requires an alphanumeric value` })
        : setAlphanumericError({ [event.target.name]: '' });
    }

    if (setFormNameArry.length === 0) {
      setFormNameArry.push({ name: event.target.dataset.field, query_name: event.target.dataset.post });
    }

    const index = setFormNameArry.findIndex(x => x.name === event.target.dataset.field);

    if (index === -1) {
      setFormNameArry.push({ name: event.target.dataset.field, query_name: event.target.dataset.post });
    }
  };

  const changeDateSelect = date => {
    setCurrentDate(date);

    const d = new Date(date);
    const month = `${d.getMonth().toString().length < 2 ? '0' : ''}${d.getMonth() + 1}`;
    const day = `${d.getDate().toString().length < 2 ? '0' : ''}${d.getDate()}`;
    const year = d.getFullYear();
    const formatDate = [year, month, day].join('-');

    setEventDateValue(formatDate);
  };

  return (
    <BulmaSection>
      <BulmaContainer>
        <StyledThankYouWrapper className={thankYouShow}>
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="48"
            height="48"
            viewBox="0 0 48 48"
            fill="none"
            aria-hidden="true"
          >
            <g clipPath="url(#clip0)">
              <path
                d="M12 26.4461L16.9 33.4001C17.0859 33.6778 17.3354 33.907 17.6277 34.0687C17.92 34.2305 18.2468 34.3201 18.5807 34.3301C18.9147 34.34 19.2462 34.2701 19.5477 34.1261C19.8492 33.9821 20.1119 33.7682 20.314 33.5021L36 13.6561"
                stroke="#00D7D2"
                strokeWidth="3"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <path
                d="M24 46.498C36.4264 46.498 46.5 36.4244 46.5 23.998C46.5 11.5716 36.4264 1.49802 24 1.49802C11.5736 1.49802 1.5 11.5716 1.5 23.998C1.5 36.4244 11.5736 46.498 24 46.498Z"
                stroke="#00D7D2"
                strokeWidth="3"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            </g>
            <defs>
              <clipPath id="clip0">
                <rect width="48" height="48" fill="white" />
              </clipPath>
            </defs>
          </svg>

          {thank_you_message && thank_you_message[0].text ? (
            <Heading css={styledSubheading} className="medium darkgrey subtitle" renderAs="p">
              {thank_you_message[0].text}
            </Heading>
          ) : null}
        </StyledThankYouWrapper>
        <span className={formShow} css={styledFormReady} id={form_anchor_name || 'form-anchor'}>
          <p className="error-text">There was a problem with your form request. Please try again.</p>
          {header_form_text ? (
            <Heading css={styledHeading} className="h2 darkblue" renderAs="h2">
              {header_form_text}
            </Heading>
          ) : null}

          {sub_header_form_text ? (
            <Heading css={styledSubheading} className="medium darkgrey subtitle" renderAs="p">
              {sub_header_form_text}
            </Heading>
          ) : null}

          <StyledForm className="form-align-left" onSubmit={handleSubmit(onSubmit)}>
            <span className="form-wrapper">
              {input.fields.map(form => (
                <>
                  {form.section_header ? (
                    <div className="sectionContainer">
                      <div className="full">
                        <h2>{form.section_header[0].text}</h2>
                        {form.section_sub_header && form.section_sub_header[0].text ? (
                          <RichText render={form.section_sub_header} linkResolver={linkResolver} />
                        ) : null}
                      </div>
                    </div>
                  ) : null}

                  {form.field_type === 'input-text' ? (
                    <div className={`${form.field_column_width} ${form.field_required && 'is-required'}`}>
                      <input
                        type="text"
                        onChange={onChange}
                        name={form.field_name}
                        className={errors[form.field_name] ? 'error-border' : 'error-none is-required'}
                        placeholder={form.field_placeholder}
                        maxLength={form.field_max_length ? form.field_max_length : ''}
                        data-field={form.field_name}
                        data-post={form.field_post_name}
                        data-alphanumeric={form.field_alphanumeric}
                        ref={register({ required: !!form.field_required })}
                      />

                      {form.field_name === 'email' ? (
                        <span className={validEmailClass}>A valid email is required</span>
                      ) : null}

                      {form.field_error_message ? (
                        <span>
                          <span>
                            {errors[form.field_name] && errors[form.field_name].type === 'required' && (
                              <span className="error-text">{form.field_error_message}</span>
                            )}
                          </span>
                          <span className={`${form.field_name}-error`}>
                            <span className="error-text">
                              {alphanumericError ? alphanumericError[form.field_name] : ''}
                            </span>
                          </span>
                        </span>
                      ) : null}
                    </div>
                  ) : null}

                  {form.field_type === 'input-password' ? (
                    <div className={`${form.field_column_width} ${form.field_required && 'is-required'}`}>
                      <input
                        type="password"
                        onChange={onChange}
                        name={form.field_name}
                        className={errors[form.field_name] ? 'error-border' : 'error-none is-required'}
                        placeholder={form.field_placeholder}
                        maxLength={form.field_max_length ? form.field_max_length : ''}
                        data-field={form.field_name}
                        data-post={form.field_post_name}
                        ref={register({ required: !!form.field_required })}
                      />

                      {form.field_name === 'email' ? (
                        <span className={validEmailClass}>A valid email is required</span>
                      ) : null}

                      {form.field_error_message ? (
                        <span>
                          {errors[form.field_name] && errors[form.field_name].type === 'required' && (
                            <span className="error-text">{form.field_error_message}</span>
                          )}
                        </span>
                      ) : null}
                    </div>
                  ) : null}

                  {form.field_type === 'input-hidden' ? (
                    <div className="input-hidden">
                      <input
                        type="hidden"
                        value={form.field_value ? form.field_value : ''}
                        name={form.field_name}
                        ref={register}
                      />
                    </div>
                  ) : null}

                  {form.field_type === 'calendar-picker' ? (
                    <div className={`${form.field_column_width} ${form.field_required && 'is-required'}`}>
                      <DatePicker
                        selected={currentDate}
                        onChange={changeDateSelect}
                        name="startDate"
                        dateFormat="yyyy-MM-dd"
                      />
                      <input
                        type="hidden"
                        onChange={onChange}
                        value={eventDateValue}
                        name={form.field_name}
                        data-field={form.field_name}
                        data-post={form.field_post_name}
                        ref={register}
                      />
                      {form.field_error_message ? (
                        <span>
                          {errors[form.field_name] && errors[form.field_name].type === 'required' && (
                            <span className="error-text">{form.field_error_message}</span>
                          )}
                        </span>
                      ) : null}
                    </div>
                  ) : null}

                  {form.field_type === 'input-submit' ? (
                    <div className={form.field_column_width}>
                      <input type="submit" value={form.field_value} />
                    </div>
                  ) : null}

                  {form.field_type === 'dropdown' ? (
                    <div className={`${form.field_column_width} select ${form.field_required && 'is-required'}`}>
                      <select
                        name={form.field_name}
                        className={errors[form.field_name] ? 'error-border' : 'error-none is-required'}
                        onChange={onChange}
                        data-field={form.field_name}
                        data-post={form.field_post_name}
                        ref={register({ required: !!form.field_required })}
                      >
                        <option value="">{form.field_placeholder}</option>
                        {form.field_value.split('|').map(item => (
                          <option key={item} value={item}>
                            {item}
                          </option>
                        ))}
                      </select>
                      <span>
                        {errors[form.field_name] && errors[form.field_name].type === 'required' && (
                          <span className="error-text">{form.field_error_message}</span>
                        )}
                      </span>
                    </div>
                  ) : null}

                  {form.field_type === 'textarea' ? (
                    <div className={`${form.field_column_width} textarea ${form.field_required && 'is-required'}`}>
                      <textarea
                        name={form.field_name}
                        placeholder={form.field_placeholder}
                        data-field={form.field_name}
                        data-post={form.field_post_name}
                        onChange={onChange}
                        className={errors[form.field_name] ? 'error-border' : 'error-none is-required'}
                        ref={register({ required: !!form.field_required })}
                      />

                      {form.field_error_message ? (
                        <span>
                          {errors[form.field_name] && errors[form.field_name].type === 'required' && (
                            <span className="error-text">{form.field_error_message}</span>
                          )}
                        </span>
                      ) : null}
                    </div>
                  ) : null}

                  {form.field_type === 'checkbox' ? (
                    <div className={`${form.field_column_width}`}>
                      <div className="checkbox-row">
                        <span className={form.field_required ? 'checkbox is-required' : 'checkbox'}>
                          {form.field_placeholder}
                        </span>
                      </div>
                      {form.field_value.split('|').map(item => (
                        <div className="checkbox-row">
                          <label htmlFor={form.field_name}>
                            <input
                              type="checkbox"
                              onChange={onChange}
                              name={form.field_name}
                              data-field={form.field_name}
                              data-post={form.field_post_name}
                              value={item}
                              ref={register({ required: !!form.field_required })}
                            />
                            {item}
                          </label>
                        </div>
                      ))}

                      {form.field_error_message ? (
                        <span>
                          {errors[form.field_name] && errors[form.field_name].type === 'required' && (
                            <span className="error-text">{form.field_error_message}</span>
                          )}
                        </span>
                      ) : null}
                    </div>
                  ) : null}
                </>
              ))}
            </span>

            <StyledSubscript>
              <RichText render={footer_form_text} linkResolver={linkResolver} />
            </StyledSubscript>
          </StyledForm>
        </span>
      </BulmaContainer>
    </BulmaSection>
  );
};

export default DynamicFormBuilder;

DynamicFormBuilder.propTypes = {
  input: PropTypes.object.isRequired,
};
