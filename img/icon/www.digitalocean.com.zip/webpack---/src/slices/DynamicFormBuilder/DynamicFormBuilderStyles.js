import { css } from '@emotion/core';
import media from 'css-in-js-media';
import styled from '@emotion/styled';

export const styledHeading = css`
  text-align: center;
  max-width: 700px;
  margin: 0 auto;
`;

export const styledSubheading = css`
  margin: 20px auto 80px auto !important;
  max-width: 670px;
  text-align: center;
`;

export const sectionContainer = css`
  width: 100%;
  text-align: center;
`;

export const StyledForm = styled.form`
  .form-wrapper {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    margin-top: 36px;
    position: relative;
    text-align: left;

    .sectionContainer {
      margin-bottom: 60px;
      width: 100%;
    }

    .full {
      width: 100%;
      text-align: center;
      position: relative;
      margin-bottom: 16px;

      &.is-required:before, &.textarea.is-required:before {
        content:"";
        background: url(https://images.prismic.io/www-static/50bfb6e8-d754-4e9f-ade8-b9a08d1ab626_asterik-blue.svg?auto=compress,format);
        background-size: 10px;
        fill:#0069ff;
        width:10px;
        height:10px;
        background-repeat:no-repeat;
        position:absolute;
        top:20px;
        right:28px;
        -webkit-transform-origin:center center;
        transform-origin:center center;
        pointer-events:none;
        z-index:2;
      }

      &.select.is-required:after, &.select:after {
        content: "";
        position: absolute;
        top: 25px;
        -webkit-transform: translateY(-50%);
        transform: translateY(-50%);
        right: 16px;
        background: url(https://images.prismic.io/www-static/ab28bfed-9412-44c9-b247-6497457a88d4_arrow-down-gray-e67c5162.svg?auto=compress,format);
        fill: rgba(3,27,78,.75);
        width: 12px;
        height: 12px;
        background-repeat: no-repeat;
        background-size: contain;
        pointer-events: none;
        right: 40px;
        z-index: 2;
      }

      &.select:after {
        right: 15px;
      }

      &.textarea.is-required:before {
        top:40px;
      }

      input[type="submit"] {
        line-height: 100%;
        font-family: Sailec-Bold;
        font-size: 16px;
        color: rgb(255, 255, 255);
        cursor: pointer;
        margin-top: 40px;
        margin-bottom: 20px;
        background: rgb(0, 105, 255);
        border-width: initial;
        border-style: none;
        border-color: initial;
        border-image: initial;
        padding: 20px;
        -moz-border-radius: 5px;
        -webkit-border-radius: 5px;
        -khtml-border-radius: 5px;
        border-radius: 5px;
      }

      input[type='text'], select, textarea {
        width: 98%;
        height: 48px;
        background: #FFF;
        border: 1px solid #e5e8ed;
        box-sizing: border-box;
        border-radius: 3px;
        margin-bottom: 8px;
        font-family: 'Sailec-Regular';
        font-size: 16px;
        padding: 16px;
        color: #5b6987;
        :focus {
          border-color: #0069ff;
          outline: #0069ff;
        }
      }

      textarea {
        color: #5b6987;
        border: 1px solid #e5e8ed;
        font-family: 'Sailec-Regular';
        font-size: 16px;
        overflow: auto;
        vertical-align: top;
        resize: vertical;
        margin: 25px 0;
        min-height: 80px;
        height: auto;
        text-indent: 10px;
        width: 98%;
        padding: 16px 0;
      }

      textarea::placeholder {
        color: #5b6987;
      }

      select::-ms-expand {
        display: none;
      }

      select {
        -webkit-appearance: none;
        -moz-appearance: none;      
        appearance: none;
        padding: 2px 30px 2px 2px;
        text-indent: 10px;
      }

      input[type="text"]::-webkit-input-placeholder { 
        color: #5b6987;
      }

      input[type="text"]::-moz-placeholder {
        color: #5b6987;
        opacity:  1;
      }

      input[type="text"]:-ms-input-placeholder { 
        color: #5b6987;
      }

      input[type="text"]::-ms-input-placeholder { 
        color: #5b6987;
      }

      input[type="text"]::placeholder {
        color: #5b6987;
      }


      .checkbox-row {
        color: #5b6987;
        font-size: 16px;
        padding: 5px 0;
        text-align: left;
      }

      span.error-text {
        color: #ca0c0c;
        display: inline-block;
        font-family: 'Sailec-Regular';
        font-size: 12px;
        margin-bottom: 16px;
        text-align: left;
      }

      .react-datepicker-wrapper {
        width: 100%;
      }

      input.error-border, select.error-border, textarea.error-border {
        border: solid 1px #ca0c0c;
      }
    }

    .half {
      margin-bottom: 16px;
      margin-left: 1%;
      margin-right: 1%;
      position: relative;
      width: 48%;

      &.is-required:before, &.textarea.is-required:before {
        content:"";
        background: url(https://images.prismic.io/www-static/50bfb6e8-d754-4e9f-ade8-b9a08d1ab626_asterik-blue.svg?auto=compress,format);
        background-size: 10px;
        fill:#0069ff;
        width:10px;
        height:10px;
        background-repeat:no-repeat;
        position:absolute;
        top:20px;
        right:16px;
        -webkit-transform-origin:center center;
        transform-origin:center center;
        pointer-events:none;
        z-index:2;
      }

      &.select.is-required:after, &.select:after {
        content: "";
        position: absolute;
        top: 25px;
        -webkit-transform: translateY(-50%);
        transform: translateY(-50%);
        right: 16px;
        background: url(https://images.prismic.io/www-static/ab28bfed-9412-44c9-b247-6497457a88d4_arrow-down-gray-e67c5162.svg?auto=compress,format);
        fill: rgba(3,27,78,.75);
        width: 12px;
        height: 12px;
        background-repeat: no-repeat;
        background-size: contain;
        pointer-events: none;
        right: 40px;
        z-index: 2;
      }

      &.select:after {
        right: 15px;
      }

       input, select, textarea {
        width: 100%;
        height: 48px;
        background: #FFF;
        border: 1px solid #e5e8ed;
        box-sizing: border-box;
        border-radius: 3px;
        margin-bottom: 8px;
        font-family: 'Sailec-Regular';
        font-size: 16px;
        padding: 16px;
        color: #5b6987;
        :focus {
          border-color: #0069ff;
          outline: #0069ff;
        }
      }

      select::-ms-expand {
        display: none;
      }

      select {
        -webkit-appearance: none;
        -moz-appearance: none;      
        appearance: none;
        padding: 2px 30px 2px 2px;
        text-indent: 10px;
      }

      input[type="text"]::-webkit-input-placeholder { 
        color: #5b6987;
      }

      input[type="text"]::-moz-placeholder {
        color: #5b6987;
        opacity:  1;
      }

      input[type="text"]:-ms-input-placeholder { 
        color: #5b6987;
      }

      input[type="text"]::-ms-input-placeholder { 
        color: #5b6987;
      }

      input[type="text"]::placeholder {
        color: #5b6987;
      }

      input.error-border, select.error-border, textarea.error-border {
        border: solid 1px #ca0c0c;
      }
      input[type='submit'] {
        background: #0069ff;
        border: none;
        line-height: 100%;
        font-family: 'Sailec-Bold';
        color: #fff;
        padding: 17px;
        cursor: pointer;
        margin-bottom: 0;
      }
      span.error-text {
        color: #ca0c0c;
        display: inline-block;
        font-family: 'Sailec-Regular';
        font-size: 12px;
        margin-bottom: 16px;
        text-align: left;
      }

      ${media('< tablet')} { 
        width: 100%;
        margin-right: 0;
        margin-left: 0;
      }
    }
  }

  .input-hidden {
    display: none;
  }

  p.form-terms {
    text-align: center;
  }

    .form-item-full-width {
      width: 100%;

      .checkbox-wrapper {
        display: inline-block;
        margin-bottom: 36px;
      }

      label {
        color: #5b6987;
        font-family: 'Sailec-Regular';
        font-size: 16px;
        margin-left: 5px;
      }

      textarea {
        color: #5b6987;
        border: 1px solid #e5e8ed;
        font-family: 'Sailec-Regular';
        font-size: 16px;
        overflow: auto;
        vertical-align: top;
        resize: vertical;
        margin: 25px 0;
        min-height: 80px;
        height: auto;
        text-indent: 10px;
        width: 100%;
      }

      textarea::placeholder {
        color: #5b6987;
      }
    }

    .form-item-half-width:nth-of-type(odd) {
      margin-right: 1%;

      ${media('< tablet')} { 
        margin-right: 0;
      }
    }

    .form-item-half-width:nth-of-type(even) {
      margin-left: 1%;

      ${media('< tablet')} { 
        margin-left: 0;
      }
    }

    .form-item-half-width {
      margin-bottom: 16px;
      position: relative;
      width: 49%;

      &.is-required:before {
        content:"";
        background: url(https://images.prismic.io/www-static/50bfb6e8-d754-4e9f-ade8-b9a08d1ab626_asterik-blue.svg?auto=compress,format);
        background-size: 10px;
        fill:#0069ff;
        width:10px;
        height:10px;
        background-repeat:no-repeat;
        position:absolute;
        top:20px;
        right:16px;
        -webkit-transform-origin:center center;
        transform-origin:center center;
        pointer-events:none;
        z-index:2;
      }

      &.select.is-required:after, &.select:after {
        content: "";
        position: absolute;
        top: 25px;
        -webkit-transform: translateY(-50%);
        transform: translateY(-50%);
        right: 16px;
        background: url(https://images.prismic.io/www-static/ab28bfed-9412-44c9-b247-6497457a88d4_arrow-down-gray-e67c5162.svg?auto=compress,format);
        fill: rgba(3,27,78,.75);
        width: 12px;
        height: 12px;
        background-repeat: no-repeat;
        background-size: contain;
        pointer-events: none;
        right: 40px;
        z-index: 2;
      }

      &.select:after {
        right: 15px;
      }

       input, select {
        width: 100%;
        height: 48px;
        background: #FFF;
        border: 1px solid #e5e8ed;
        box-sizing: border-box;
        border-radius: 3px;
        margin-bottom: 8px;
        font-family: 'Sailec-Regular';
        font-size: 16px;
        padding: 16px;
        color: #5b6987;
        :focus {
          border-color: #0069ff;
          outline: #0069ff;
        }
      }

      select::-ms-expand {
        display: none;
      }

      select {
        -webkit-appearance: none;
        -moz-appearance: none;      
        appearance: none;
        padding: 2px 30px 2px 2px;
        text-indent: 10px;
      }

      input[type="text"]::-webkit-input-placeholder { 
        color: #5b6987;
      }

      input[type="text"]::-moz-placeholder {
        color: #5b6987;
        opacity:  1;
      }

      input[type="text"]:-ms-input-placeholder { 
        color: #5b6987;
      }

      input[type="text"]::-ms-input-placeholder { 
        color: #5b6987;
      }

      input[type="text"]::placeholder {
        color: #5b6987;
      }

      input.error-border, select.error-border {
        border: solid 1px #ca0c0c;
      }
      input[type='submit'] {
        background: #0069ff;
        border: none;
        line-height: 100%;
        font-family: 'Sailec-Bold';
        color: #fff;
        padding: 17px;
        cursor: pointer;
        margin-bottom: 0;
      }
      span.error-text {
        color: #ca0c0c;
        display: inline-block;
        font-family: 'Sailec-Regular';
        font-size: 12px;
        margin-bottom: 16px;
        text-align: left;
      }

      ${media('< tablet')} { 
        width: 100%;
        margin-right: 0;
        margin-left: 0;
      }
    }
  }
  .hide-error {
    display: none;
  }
  .show-error {
    display: block;
  }

  .terms-of-service {
    font-size: 14px;
    text-align: center;

    a {
      color: #0069ff;
      text-decoration:underline;
    }
  }
`;

export const styledFormReady = css`
  display: inline-block;
  width: 100%;

  &.is-none {
    display: none;
  }

  &.anchor {
    margin-top: -120px;
    padding-top: 120px;
  }

  .error-text {
    display: none;
    color: #ca0c0c;
    font-family: 'Sailec-Regular';
    font-size: 16px;
    margin-bottom: 16px;
    text-align: center;
  }

  .error-text.show {
    display: block;
  }
`;

export const StyledThankYouWrapper = styled.div`
  display: flex;
  flex-wrap: wrap;
  justify-content: center;

  svg {
    display: inline-block;
    width: 100%;
  }

  p {
    color: #031b4e;
    font-family: 'Sailec-Light';
    font-size: 20px;
    line-height: 150%;
  }

  &.is-none {
    display: none;
  }

  &.is-block {
    display: block;
    text-align: center;
  }
`;

export const styledCards = css`
  display: grid;
  grid-auto-flow: dense;
  grid-auto-rows: 1fr;
  grid-gap: 32px;
  max-width: 1168px;
  margin-top: 64px;

  .related-card {
    display: inherit;
    margin: 15px auto;
    max-width: 300px;
    min-height: 270px;

    img {
      max-width: 300px;
    }

    p {
      font-size: 16px;
      text-align: left;
    }
  }

  ${media('< desktop')} {
    display: flex;
    flex-direction: column;
    margin-left: 0px;
    margin-right: 0px;
    margin-top: 32px !important;
  }
`;

export const styledCardBox = css`
  background: #fff;
  border: 1px solid #e5e8ed;
  border-radius: 5px;
  padding: 24px;
  margin-bottom: 0 !important;
  box-shadow: none;

  ${media('< desktop')} {
    margin-top: 32px;
  }
`;

export const styledCardContent = css`
  position: relative;
  height: 100%;

  .title {
    margin-top: 15px;
  }

  img {
    max-width: 120px;
    margin-bottom: 10px;
  }

  ${media('<= desktop')} {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
  }
`;

export const StyledSubscript = styled.div`
  p,
  a {
    font-family: 'Sailec-Regular';
    font-size: 12px;
    text-align: center;
    color: #5b6987;
  }

  a:hover {
    color: #5b6987;
    border-bottom: dotted 1px rgba(255, 255, 255, 0.5);
  }
`;
