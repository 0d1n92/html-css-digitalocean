/* eslint-disable camelcase */
import React from 'react';
import PropTypes from 'prop-types';

import BulmaContainer from 'react-bulma-components/lib/components/container';
import BulmaSection from 'react-bulma-components/lib/components/section';

import { css } from '@emotion/core';

import { Heading, Tab, LargeImgWithSideContent } from '../atoms';

import { TopTabContainer } from '../atoms/Tabs/TopTabNav';
import { styledTopTabbedContainer, styledSubheading, styledHeading } from './TopTabbedNavContentStyles';

const renderImgWithSideContent = (
  title,
  title_color,
  image,
  text,
  default_text_color,
  content_text_color,
  link_text,
  link_url,
  link_color,
  image_position,
) => (
  <LargeImgWithSideContent
    text={text}
    title={title}
    titleColor={title_color}
    defaultTextColor={default_text_color}
    contentTextColor={content_text_color}
    linkText={link_text}
    linkURL={link_url}
    linkColor={link_color}
    image={image}
    imagePosition={image_position}
  />
);

const renderHeading = (text, atts) => <Heading {...atts}>{text.text}</Heading>;

const TopTabbedNavContent = ({ input }) => {
  const { heading, subheading, background_color, text_color, heading_color, subheading_color } = input.primary;

  return (
    <BulmaSection
      css={css`
        background-color: ${background_color};
      `}
    >
      <BulmaContainer css={styledTopTabbedContainer}>
        {heading && heading[0].text
          ? renderHeading(heading[0], {
              renderAs: 'h2',
              className: `${text_color === 'light' && !heading_color ? 'h2 white' : 'h2 darkblue'}`,
              style: { color: heading_color },
              css: styledHeading,
            })
          : null}
        {subheading && subheading[0].text
          ? renderHeading(subheading[0], {
              renderAs: 'p',
              className: `${text_color === 'light' && !subheading_color ? 'medium white' : 'medium darkgrey'}`,
              style: { color: subheading_color },
              subtitle: true,
              css: styledSubheading,
            })
          : null}
        <TopTabContainer text_color={text_color}>
          {input.fields.map(item => (
            <Tab
              key={`tabbed-content-${item.tab_label[0].text}`}
              label={item.tab_label[0].text}
              icon={item.tab_icon}
              content={[
                renderImgWithSideContent(
                  item.title1,
                  item.title_color,
                  item.image,
                  item.text,
                  text_color,
                  item.text_color,
                  item.content_link_text,
                  item.link_url,
                  item.link_color,
                  item.image_position,
                ),
              ]}
              label_color={item.label_color}
              content_color={item.content_color}
            />
          ))}
        </TopTabContainer>
      </BulmaContainer>
    </BulmaSection>
  );
};

export default TopTabbedNavContent;

TopTabbedNavContent.propTypes = {
  input: PropTypes.object.isRequired,
};
