import { css } from '@emotion/core';
import media from 'css-in-js-media';

export const styledHeading = css`
  margin: 0 auto 0 auto;
  text-align: center;
`;

export const styledSubheading = css`
  margin: 56px auto 80px auto !important;
  max-width: 790px !important;
  text-align: center;

  &.subtitle {
    margin-bottom: 40px !important;
  }
`;

export const styledLink = css`
  margin: 0 0 0 30px;

  ${media('< tablet')} {
    display: block;
    text-align: center;
    width: 80%;
    margin: 0 auto 60px auto;
  }
`;

export const styledTopTabbedContainer = css`
  min-height: 600px;
`;
