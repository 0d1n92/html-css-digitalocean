// Styles here will override Bulma styles
import styled from '@emotion/styled';
import { css } from '@emotion/core';
import media from 'css-in-js-media';

export const styledSection = css`
  background-repeat: repeat;
`;

export const styledContainer = css`
  max-width: 870px;
  display: flex;
  flex-direction: column;
  align-items: center;
`;

export const StyledDocumentContainer = styled.div`
  margin-bottom: 20px;
  width: 100%;

  h4 {
    margin-bottom: 10px !important;
  }

  &:first-of-type {
    margin-top: 64px;
  }
`;

export const StyledDocumentList = styled.ul`
  width: 680px;
  list-style: none;
  display: flex;
  flex-direction: column;
  margin: 0px auto;

  li {
    height: 55px;
    display: flex;
    align-items: center;
    &:not(:last-of-type) {
      border-bottom: 1px solid ${props => props.borderColor};
    }
  }

  li a {
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-family: 'Sailec-Medium';

    width: 100%;
    &:after {
      margin-top: -6px;
      content: '›';
      font-size: 20px;
      font-family: 'Sailec-Regular';
    }
  }

  ${media('<= tablet')} {
    width: 80%;
  }
`;

export const StyledLink = styled.li``;

export const styledHeading = css`
  margin: 0 auto;
  text-align: center;
`;

export const styledSubtitle = css`
  margin: 20px auto 0 auto !important;
  max-width: 670px;
  text-align: center;
`;

export const styledSectionHeaders = css`
  margin: 32px 0 32px 0 !important;
`;
