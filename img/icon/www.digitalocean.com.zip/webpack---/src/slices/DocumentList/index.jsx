/* eslint-disable camelcase */
import React from 'react';
import PropTypes from 'prop-types';

import BulmaContainer from 'react-bulma-components/lib/components/container';
import BulmaSection from 'react-bulma-components/lib/components/section';

import { createRandomId } from '../../util/createRandomId';
import { Heading, TextLink } from '../atoms';

import {
  styledContainer,
  styledHeading,
  styledSubtitle,
  StyledDocumentContainer,
  StyledDocumentList,
  styledSectionHeaders,
} from './DocumentListStyles';

const renderHeading = (text, atts) => <Heading {...atts}>{text.text}</Heading>;

const renderLink = (data, text) =>
  data && data.url ? (
    <li key={data.text}>
      <TextLink data-testid="document_list_link" url={data.url}>
        {text}
      </TextLink>
    </li>
  ) : null;

const renderSection = (section, defaultTextColor) => {
  const {
    section_heading,
    link_1_text,
    link_1,
    link_2_text,
    link_2,
    link_3_text,
    link_3,
    link_4_text,
    link_4,
    link_5_text,
    link_5,
    link_6_text,
    link_6,
    link_7_text,
    link_7,
    link_8_text,
    link_8,
    link_9_text,
    link_9,
    link_10_text,
    link_10,
  } = section;

  return (
    <StyledDocumentContainer key={createRandomId()}>
      <StyledDocumentList borderColor={defaultTextColor === 'light' ? '#fff' : '#e5e8ed'}>
        {section_heading && section_heading[0] && section_heading[0].text
          ? renderHeading(section_heading[0], {
              css: styledSectionHeaders,
              className: defaultTextColor === 'light' ? 'h4 medium white' : 'h4 medium darkblue',
              renderAs: 'h4',
              'data-testid': 'document_list_section_heading',
            })
          : null}
        {renderLink(link_1, link_1_text)}
        {renderLink(link_2, link_2_text)}
        {renderLink(link_3, link_3_text)}
        {renderLink(link_4, link_4_text)}
        {renderLink(link_5, link_5_text)}
        {renderLink(link_6, link_6_text)}
        {renderLink(link_7, link_7_text)}
        {renderLink(link_8, link_8_text)}
        {renderLink(link_9, link_9_text)}
        {renderLink(link_10, link_10_text)}
      </StyledDocumentList>
    </StyledDocumentContainer>
  );
};

const DocumentList = ({ input }) => {
  const { heading, subheading, background_image, background_color, text_color } = input.primary;

  return (
    <BulmaSection
      style={{
        backgroundImage: `url(${background_image && background_image.url})`,
        backgroundColor: `${background_color}`,
      }}
    >
      <BulmaContainer css={styledContainer}>
        {heading &&
          heading[0].text &&
          renderHeading(heading[0], {
            css: styledHeading,
            className: text_color === 'light' ? 'h2 white' : 'h2 darkblue',
            renderAs: 'h2',
          })}
        {subheading &&
          subheading[0] &&
          subheading[0].text &&
          renderHeading(subheading[0], {
            css: styledSubtitle,
            className: text_color === 'light' ? 'medium white' : 'medium darkgrey',
            renderAs: 'p',
            subtitle: true,
          })}
        {input.fields.map(card => renderSection(card, text_color))}
      </BulmaContainer>
    </BulmaSection>
  );
};

export default DocumentList;

DocumentList.propTypes = {
  input: PropTypes.object.isRequired,
};
