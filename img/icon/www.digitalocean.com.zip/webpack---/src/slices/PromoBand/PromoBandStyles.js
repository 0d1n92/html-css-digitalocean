// Styles here will override Bulma styles
import styled from '@emotion/styled';
import { css } from '@emotion/core';
import media from 'css-in-js-media';

export const styledSection = css`
  padding-top: 64px;
  padding-bottom: 64px;
`;

export const styledBox = css`
  display: grid;
  grid-template-columns: 145px 1fr 220px;
  align-items: center;
  padding: 32px !important;
  max-width: 940px;
  border: 1px solid #e5e8ed;
  box-shadow: 0px 2px 4px rgba(1, 14, 40, 0.05);
  margin: 0 auto;

  ${media('< tablet')} {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    text-align: center;
  }
`;

export const styledIcon = css`
  max-height: 80px;
`;

export const styledHeading = css`
  margin-left: 32px !important;
  ${media('< tablet')} {
    margin: 32px 0 0 0 !important;
  }
`;

export const StyledSubheading = styled.div`
  p {
    color: #5b6987;
    margin-left: 32px;
    margin-top: 8px !important;
    margin-bottom: 0;
    font-size: 16px !important;

    ${media('< tablet')} {
      margin-left: 0;
      margin-bottom: 32px;
    }
  }
`;
