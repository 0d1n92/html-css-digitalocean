/* eslint-disable camelcase */
import React from 'react';
import PropTypes from 'prop-types';
import { RichText } from 'prismic-reactjs';

import BulmaContainer from 'react-bulma-components/lib/components/container';
import BulmaSection from 'react-bulma-components/lib/components/section';
import BulmaBox from 'react-bulma-components/lib/components/box';

import { linkResolver } from '../../util/linkResolver';
import { Heading, Button, LazyLink, LazyImage } from '../atoms';

import { styledSection, styledBox, styledIcon, styledHeading, StyledSubheading } from './PromoBandStyles';

const renderHeading = (text, atts) => (
  <Heading {...atts} css={atts.css}>
    {text.text}
  </Heading>
);

const PromoBand = ({ input }) => {
  const {
    background_color,
    heading,
    heading_color,
    subheading_color,
    subheading,
    icon,
    cta_button_link,
    cta_button_text,
  } = input.primary;

  return (
    <BulmaSection
      css={styledSection}
      style={{
        backgroundColor: background_color || '#fff',
      }}
    >
      <BulmaContainer>
        <BulmaBox css={styledBox}>
          {icon && icon.url ? <LazyImage css={styledIcon} src={icon.url} alt={icon.alt || 'icon'} /> : null}
          <div>
            {heading &&
              heading[0].text &&
              renderHeading(heading[0], {
                style: heading_color ? { color: heading_color } : null,
                className: 'h3 darkblue',
                css: styledHeading,
                renderAs: 'h3',
              })}
            {subheading && subheading[0].text && (
              <StyledSubheading styles={{ color: subheading_color || null }}>
                <RichText render={subheading} linkResolver={linkResolver} />
              </StyledSubheading>
            )}
          </div>
          {cta_button_link && cta_button_link.url ? (
            <Button renderAs={LazyLink} url={cta_button_link.url} color="primary">
              {cta_button_text}
            </Button>
          ) : null}
        </BulmaBox>
      </BulmaContainer>
    </BulmaSection>
  );
};

export default PromoBand;

PromoBand.propTypes = {
  input: PropTypes.object.isRequired,
};
