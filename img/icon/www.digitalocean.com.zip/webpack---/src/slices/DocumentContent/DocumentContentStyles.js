// Styles here will override Bulma styles
import styled from '@emotion/styled';
import { css } from '@emotion/core';
import media from 'css-in-js-media';

export const StyledDocument = styled.div`
  max-width: 870px;
  margin: auto;
  text-align: left;
  display: flex;
  flex-direction: column;
  overflow-wrap: break-word;

  h1 {
    margin: 32px 0 16px 0 !important;
  }

  h2 {
    font-family: 'Sailec-Bold';
  }

  h3,
  h4,
  h5,
  h6 {
    font-family: 'Sailec-Regular';
  }

  p img {
    margin: 16px 0;
    max-width: 100%;
  }
`;

export const styledCardsSection = css`
  background-repeat: repeat;
`;

export const styledCardsContainer = css`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;

  ${media('< desktop')} {
    h2,
    p {
      margin-left: 20px;
      margin-right: 20px;
      text-align: center;
    }
  }
`;

export const styledHeading = css`
  text-align: left;
`;

export const styledSubheading = css`
  margin: 20px auto 20px 0 !important;
  max-width: 670px;
  text-align: left;
`;

export const styledLightRichText = css`
  p,
  h1,
  h2,
  h3,
  h4,
  h5,
  h6 {
    color: #fff;
    font-weight: normal;
  }

  p a {
    font-family: 'Sailec-Regular';
    text-decoration: underline;
    color: #0069ff;
  }

  strong {
    font-family: 'Sailec-Bold';
    font-weight: normal;
  }

  ul {
    margin-left: 32px;
    li {
      padding: 8px 0;
    }
  }
`;

export const styledDarkRichText = css`
  h1,
  h2,
  h3,
  h4,
  h5,
  h6 {
    color: #031b4e !important;
    margin-top: 32px;
    margin-bottom: 16px;
  }

  h1,
  h2 {
    font-weight: 400;
  }

  p,
  span,
  ul,
  ol {
    color: #5b6987;
  }

  a {
    font-family: 'Sailec-Regular';
    text-decoration: underline;
    color: #0069ff !important;
  }

  ul,
  ol {
    margin-left: 32px;
    li {
      padding: 8px 0;
    }
  }
`;
