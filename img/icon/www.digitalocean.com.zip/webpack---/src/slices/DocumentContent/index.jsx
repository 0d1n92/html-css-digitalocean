/* eslint-disable camelcase */
import React from 'react';
import PropTypes from 'prop-types';
import { RichText } from 'prismic-reactjs';

import BulmaContainer from 'react-bulma-components/lib/components/container';
import BulmaSection from 'react-bulma-components/lib/components/section';

import { linkResolver } from '../../util/linkResolver';

import { Heading, BreadcrumbNav } from '../atoms';

import {
  styledHeading,
  styledSubheading,
  styledLightRichText,
  styledDarkRichText,
  StyledDocument,
} from './DocumentContentStyles';

const DocumentContent = ({ input }) => {
  const {
    text_color,
    heading,
    heading_color,
    subheading,
    subheading_color,
    background_image,
    background_color,
    document_content_text,
  } = input.primary;

  return (
    <BulmaSection
      style={{
        backgroundColor: background_color || '#fff',
        backgroundImage: background_image && background_image.url ? `url(${background_image.url})` : null,
      }}
    >
      <BulmaContainer>
        <StyledDocument>
          <BreadcrumbNav data-testid="breadcrumb" breadcrumbs={input.fields} />
          {heading && heading[0].text ? (
            <Heading
              style={heading_color ? { color: heading_color } : null}
              css={styledHeading}
              className={text_color === 'light' ? 'white' : 'darkblue'}
              renderAs="h1"
              data-testid="heading"
            >
              {heading[0].text}
            </Heading>
          ) : null}
          {subheading && subheading[0].text ? (
            <Heading
              style={subheading_color ? { color: subheading_color } : null}
              css={styledSubheading}
              className={text_color === 'light' ? 'medium white' : 'medium darkgrey'}
              subtitle
              renderAs="p"
              data-testid="subheading"
            >
              {subheading[0].text}
            </Heading>
          ) : null}
          <div data-testid="document_text" css={text_color === 'light' ? styledLightRichText : styledDarkRichText}>
            <RichText render={document_content_text} linkResolver={linkResolver} />
          </div>
        </StyledDocument>
      </BulmaContainer>
    </BulmaSection>
  );
};

export default DocumentContent;

DocumentContent.propTypes = {
  input: PropTypes.object.isRequired,
};
