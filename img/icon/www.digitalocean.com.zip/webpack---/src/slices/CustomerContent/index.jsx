/* eslint-disable camelcase */
import React from 'react';
import PropTypes from 'prop-types';
import { RichText } from 'prismic-reactjs';

import BulmaSection from 'react-bulma-components/lib/components/section';
import BulmaContainer from 'react-bulma-components/lib/components/container';
import BulmaBox from 'react-bulma-components/lib/components/box';

import { Button, Heading, LazyLink, LazyImage } from '../atoms';
import {
  styledCustomerContentText,
  styledCustomerDetailsItem,
  styledCustomerDetailsTerm,
  styledCustomerDetailsName,
  styledCustomerContentStickyMenu,
  styledCustomerContentContainer,
  styledCardBox,
  styledCardContent,
  styledCustomerDetails,
  styledCustomerContentBreadcrumb,
  styledCustomerContentBreadcrumbLink,
  styledCustomerDetailsButton,
  styledCustomerContentSection,
} from './CustomerContentStyles';

import { linkResolver } from '../../util/linkResolver';

const renderButton = (link, text, atts) => (
  <Button {...atts} renderAs={LazyLink} url={link.url} css={styledCustomerDetailsButton}>
    {text}
  </Button>
);

const renderCard = (image, link) => (
  <BulmaBox data-testid="card" css={styledCardBox} renderAs="div">
    <LazyLink url={link.url} css={styledCardContent}>
      {image && image.url ? <LazyImage src={image.url} alt={image.alt || 'customer icon'} /> : null}
    </LazyLink>
  </BulmaBox>
);

const renderHeading = (text, atts) => <Heading {...atts}>{text.text}</Heading>;

const CustomerContent = ({ input }) => {
  const {
    background_image,
    background_color,
    breadcrumb,
    logo,
    copy1,
    copy1_text,
    copy2,
    copy2_text,
    copy3,
    copy3_text,
    copy4,
    copy4_text,
    content,
    logo_link,
    button_text,
    button_link,
    button_color,
    text_color,
    heading,
    heading_color,
  } = input.primary;

  return (
    <BulmaSection
      css={styledCustomerContentSection}
      style={
        background_image && background_image.url
          ? { backgroundImage: `url(${background_image.url})` }
          : { backgroundColor: `${background_color}` }
      }
    >
      {heading
        ? renderHeading(heading[0], {
            renderAs: 'h2',
            className: `${text_color === 'light' && !heading_color ? 'h2 white' : 'h2 darkblue'}`,
            style: { color: heading_color },
          })
        : null}
      <BulmaContainer>
        <div css={styledCustomerContentContainer}>
          <div id="testCustomerContentMenu" css={styledCustomerContentStickyMenu}>
            {renderCard(logo, logo_link)}
            <dl css={styledCustomerDetails}>
              <div css={styledCustomerDetailsItem}>
                <dt css={styledCustomerDetailsTerm}>{copy1}</dt>
                <dd css={styledCustomerDetailsName}>{copy1_text}</dd>
              </div>
              <div css={styledCustomerDetailsItem}>
                <dt css={styledCustomerDetailsTerm}>{copy2}</dt>
                <dd css={styledCustomerDetailsName}>{copy2_text}</dd>
              </div>
              <div css={styledCustomerDetailsItem}>
                <dt css={styledCustomerDetailsTerm}>{copy3}</dt>
                <dd css={styledCustomerDetailsName}>{copy3_text}</dd>
              </div>
              <div css={styledCustomerDetailsItem}>
                <dt css={styledCustomerDetailsTerm}>{copy4}</dt>
                <dd css={styledCustomerDetailsName}>{copy4_text}</dd>
              </div>
            </dl>
            {button_text &&
              renderButton(button_link, button_text, {
                color: `${button_color === 'white' ? 'white' : 'primary'}`,
              })}
          </div>
          <div css={styledCustomerContentText}>
            <LazyLink css={styledCustomerContentBreadcrumbLink} url="https://www.digitalocean.com/customers">
              Customer Stories
            </LazyLink>
            <span id="testCustomerContentBreadcrumb" css={styledCustomerContentBreadcrumb}>
              {breadcrumb}
            </span>
            <div id="testCustomerContent" style={text_color === 'light' ? { color: 'white' } : null}>
              {content && content[0] ? <RichText render={content} linkResolver={linkResolver} /> : null}
            </div>
          </div>
        </div>
      </BulmaContainer>
    </BulmaSection>
  );
};
export default CustomerContent;

CustomerContent.propTypes = {
  input: PropTypes.object.isRequired,
};
