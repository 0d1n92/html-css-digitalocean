// Styles here will override Bulma styles
import { css } from '@emotion/core';
import media from 'css-in-js-media';

export const styledCustomerContentSection = css`
  display: flex;
  flex-direction: column;
  align-items: center;
`;

export const styledCustomerContentContainer = css`
  display: flex;

  ${media('< tablet')} {
    flex-direction: column;
    padding: 16px;
  }
`;

export const styledCustomerContentStickyMenu = css`
  position: sticky;
  width: 25%;
  align-self: flex-start;
  top: 130px;
  margin-bottom: 16px;

  ${media('< tablet')} {
    position: inherit;
    width: 100%;
  }
`;

export const styledCustomerContentCard = css`
  img {
    margin: 0px !important;
  }
`;

export const styledCustomerContentText = css`
  padding-left: 64px;
  max-width: 860px;
  color: #031b4e;
  ${media('< tablet')} {
    padding: 0px;
  }

  h1,
  h2,
  h3,
  h4,
  h5,
  h6 {
    font-family: 'Sailec-Bold';
    font-weight: 400;
  }
  h2,
  h3,
  h4,
  h5,
  h6 {
    line-height: 1.3;
    margin: 3rem 0 0;
  }

  h1 {
    font-size: 2.4rem;
  }
  h2 {
    font-size: 1.7rem;
  }
  h3 {
    font-size: 1.3rem;
  }
  img {
    max-width: 100%;
  }
  ul {
    margin: 1.25rem 0 0;
    padding-left: 32px;
    color: #5b6987;
    font-size: 16px;
    line-height: 160%;
    font-weight: 400;
  }
  li {
    margin: 0.25rem 0;
  }
  a {
    color: #0069ff;
    text-decoration: underline;
    text-decoration-skip-ink: auto;
    font-family: 'Sailec-Regular';
    font-weight: normal;
  }

  iframe {
    width: 100%;
  }
`;

export const styledCustomerDetails = css`
  margin-bottom: 24px;
`;

export const styledCustomerDetailsItem = css`
  margin-bottom: 16px;
`;

export const styledCustomerDetailsTerm = css`
  text-transform: uppercase;
  color: rgba(3, 27, 78, 0.7);
  opacity: 0.6;
  font-size: 14px;
  font-family: 'Sailec-Medium';
`;

export const styledCustomerDetailsName = css`
  color: rgba(3, 27, 78, 0.7);
  margin-left: 0;
  font-size: 16px;
`;

export const styledCustomerDetailsButton = css`
  ${media('< tablet')} {
    width: 100%;
  }
`;

export const styledCustomerContentBreadcrumbLink = css`
  color: #005fe6;
  text-decoration: underline;
  font-family: 'Sailec-Regular';
`;

export const styledCustomerContentBreadcrumb = css`
  color: rgba(3, 27, 78, 0.7);
  ::before {
    color: rgba(3, 27, 78, 0.7);
    content: '›';
    margin-left: 8px;
    margin-right: 8px;
  }
`;

// custom card styles
export const styledCardBox = css`
  background: #fff;
  border: 1px solid #e5e8ed;
  border-radius: 5px;
  padding: 24px;
  margin-bottom: 24px !important;
  cursor: pointer;
  box-shadow: 0 2px 4px rgba(3, 27, 78, 0.06) !important;
  transition: all 0.5s ease;

  :hover {
    box-shadow: 0 10px 20px rgba(3, 27, 78, 0.1) !important;
    transform: scale(1.01);
    background-color: #fff !important;
  }

  ${media('< desktop')} {
    margin-top: 32px;
  }
`;

export const styledCardContent = css`
  position: relative;
  height: 100%;

  img {
    max-width: 100%;
  }

  ${media('<= desktop')} {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
  }
`;
