/* eslint-disable camelcase */
import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { RichText } from 'prismic-reactjs';

import BulmaContainer from 'react-bulma-components/lib/components/container';
import BulmaSection from 'react-bulma-components/lib/components/section';
import modalClose from '../../assets/images/modal-close.svg';
import linkedinSmall from '../../assets/images/linkedin-small.svg';

import { createRandomId } from '../../util/createRandomId';
import { linkResolver } from '../../util/linkResolver';

import { Heading, Modal, TextLink, LazyLink, LazyImage } from '../atoms';

import {
  styledModalNameExit,
  styledPeopleGrid,
  styledHeading,
  styledSubheading,
  styledModal,
  StyledRichText,
  StyledPeopleSection,
  StyledPeopleContainer,
  StyledPeople,
  StyledPeopleInfo,
  styledLink,
  StyledClose,
  StyledModalImageContainer,
  styledImg,
  StyledModalPeopleInfo,
} from './PeopleGridStyles';

const renderHeading = (text, atts) => <Heading {...atts}>{text.text}</Heading>;

const RenderPeople = (people, defaultTextColor) => {
  const { people_bio, people_image, people_linkedin_url, people_name, people_role } = people;
  const [modalIsShowing, setModalIsShowing] = useState(false);

  return (
    <StyledPeople key={createRandomId()}>
      {people_image && people_image.url && (
        <LazyImage
          alt={people_image.url || 'DigitalOcen team member'}
          src={people_image.url}
          data-testid="people-image"
        />
      )}
      {
        <StyledPeopleInfo>
          {people_name && people_name[0].text
            ? renderHeading(people_name[0], {
                className: defaultTextColor === 'light' ? 'h5 white' : 'h5 darkblue',
                renderAs: 'h5',
                'data-testid': 'people_name',
              })
            : null}
          {people_role && people_role[0].text ? <p>{people_role[0].text}</p> : null}
        </StyledPeopleInfo>
      }
      <Modal show={modalIsShowing} css={styledModal} onClose={() => setModalIsShowing(false)}>
        <StyledClose onClick={() => setModalIsShowing(false)} onKeyDown={() => setModalIsShowing(false)}>
          <LazyImage alt={modalClose || 'modal close'} src={modalClose} />
        </StyledClose>
        {((people_image && people_image.url) || (people_linkedin_url && people_linkedin_url.url)) && (
          <StyledModalImageContainer>
            {people_image && people_image.url && (
              <LazyImage alt={people_image.url || 'DigitalOcean team member'} src={people_image.url} css={styledImg} />
            )}
            {people_linkedin_url && people_linkedin_url.url && (
              <LazyLink url={people_linkedin_url.url}>
                <LazyImage alt={people_linkedin_url.url || 'Linkedin icon'} src={linkedinSmall} />
              </LazyLink>
            )}
          </StyledModalImageContainer>
        )}
        <StyledModalPeopleInfo>
          <div css={styledModalNameExit}>
            {people_name && people_name[0].text
              ? renderHeading(people_name[0], {
                  className: 'h3 darkblue',
                  renderAs: 'h3',
                  'data-testid': 'modal_people_name',
                })
              : null}
          </div>
          {people_role && people_role[0].text
            ? renderHeading(people_role[0], {
                className: 'h6 darkgrey',
                renderAs: 'h6',
                'data-testid': 'modal_people_role',
              })
            : null}
          <StyledRichText>
            <RichText render={people_bio} linkResolver={linkResolver} />
          </StyledRichText>
        </StyledModalPeopleInfo>
      </Modal>
      {people_bio && people_bio[0].text && (
        <TextLink
          css={styledLink}
          className="medium"
          onKeyDown={() => setModalIsShowing(true)}
          onClick={() => setModalIsShowing(true)}
          data-testid="read-bio"
        >
          Read Bio
        </TextLink>
      )}
    </StyledPeople>
  );
};

const PeopleGrid = ({ input }) => {
  const {
    text_color,
    heading,
    heading_color,
    subheading,
    subheading_color,
    background_image,
    background_color,
  } = input.primary;

  return (
    <BulmaSection
      css={StyledPeopleSection}
      style={{
        backgroundImage: background_image && background_image.url ? `url(${background_image.url})` : null,
        backgroundColor: background_color ? `${background_color}` : null,
      }}
    >
      <BulmaContainer css={StyledPeopleContainer}>
        {heading && heading[0].text
          ? renderHeading(heading[0], {
              style: heading_color ? { color: heading_color } : null,
              css: styledHeading,
              className: text_color === 'light' ? 'h2 white' : 'h2 darkblue',
              renderAs: 'h2',
            })
          : null}
        {subheading && subheading[0].text
          ? renderHeading(subheading[0], {
              style: subheading_color ? { color: subheading_color } : null,
              css: styledSubheading,
              className: text_color === 'light' ? 'medium white' : 'medium darkgrey',
              subtitle: true,
              renderAs: 'p',
            })
          : null}
        <div css={styledPeopleGrid}>{input.fields.map(person => RenderPeople(person, text_color))}</div>
      </BulmaContainer>
    </BulmaSection>
  );
};

export default PeopleGrid;

PeopleGrid.propTypes = {
  input: PropTypes.object.isRequired,
};
