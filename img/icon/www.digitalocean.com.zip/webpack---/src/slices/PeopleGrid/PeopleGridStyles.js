// Styles here will override Bulma styles
import styled from '@emotion/styled';
import { css } from '@emotion/core';
import media from 'css-in-js-media';

export const StyledPeopleSection = css`
  background-repeat: repeat;
  display: flex;
  min-height: 400px;
  padding-bottom: 64px;
`;

export const StyledPeopleContainer = css`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;

  ${media('< desktop')} {
    h2,
    p {
      margin-left: 20px;
      margin-right: 20px;
      text-align: center;
    }
  }
`;

export const styledHeading = css`
  margin: 0 auto;
  text-align: center;
`;

export const styledSubheading = css`
  margin: 20px auto 80px auto !important;
  max-width: 670px;
  text-align: center;
`;

export const styledPeopleGrid = css`
  display: grid;
  grid-auto-flow: dense;
  grid-auto-rows: 1fr;
  grid-template-columns: repeat(4, minmax(220px, 1fr));
  width: 100%;
  margin-top: 64px;
  margin-bottom: 20px;
  grid-gap: 64px;
  text-align: center;

  ${media('< largeDesktop')} {
    grid-template-columns: repeat(4, minmax(180px, 1fr));
  }

  ${media('< desktop')} {
    margin-left: 0px;
    margin-right: 0px;
    grid-template-columns: repeat(2, minmax(260px, 1fr));
  }

  ${media('< tablet')} {
    display: flex;
    flex-direction: column;
    li:not(:first-of-type) {
      margin-top: 50px !important;
    }
  }
`;

export const StyledPeople = styled.li`
  display: flex;
  align-items: center;
  flex-direction: column;
  list-style: none;
  position: relative;
  height: 100%;
  justify-content: center;

  .title {
    margin-top: 15px;
  }

  img {
    width: 250px;
    margin-bottom: 10px;
    border-radius: 50%;

    ${media('< largeDesktop')} {
      width: 250px;
    }
  }

  ${media('<= desktop')} {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
  }
`;

export const styledButton = css`
  margin-top: 60px;
  margin-bottom: 40px;
`;

export const StyledPeopleInfo = styled.div`
  p {
    margin: 5px 0 !important;
  }
`;

export const styledLink = css`
  margin-top: 5px;
  cursor: pointer;
`;

export const styledModal = css`
  border-radius: 3px;
  position: fixed;
  top: 100px;
  display: flex;
  padding: 24px;
  width: 640px;
  background: #fff;
  overflow: scroll;
  max-height: 720px;

  ${media('< desktop')} {
    max-width: 80%;
  }

  ${media('< tablet')} {
    display: flex;
    flex-direction: column;
    align-items: center;
    max-height: 90vh;
    top: 20px;
  }
`;

export const StyledRichText = styled.div`
  display: flex;
  flex-direction: column;
  flex: auto;
  margin-top: 20px;
`;

export const StyledModalImageContainer = styled.div`
  display: flex;
  flex-direction: column;
  flex: 4;
  max-width: 250px;
  margin-right: 16px;

  img {
    max-width: 200px;
    align-items: center;
    display: flex;
    margin: 10px auto;
    background-size: cover;
  }

  a {
    display: flex;
    width: fit-content;
    margin: 15px auto;
    cursor: pointer;

    img {
      border-radius: initial;
      width: 24px;
    }
  }

  ${media('< tablet')} {
    display: block;
    max-width: 100%;
    img {
      margin: auto;
    }
  }
`;

export const styledImg = css`
  width: 200px;
  max-height: 100%;
  border-radius: 50%;
  margin: 15px 50px 0px 10px;
  background-size: cover;
`;

export const StyledModalPeopleInfo = styled.div`
  flex: 8;
  h6 {
    margin-top: 8px !important;
  }

  ${media('< tablet')} {
    h6 {
      text-align: center;
    }
  }
`;

export const styledModalNameExit = css`
  display: flex;
  justify-content: space-between;

  h3 {
    margin: 10px 0 0 0 !important;
  }

  ${media('< tablet')} {
    h3 {
      margin: 16px auto 0 auto !important;
      text-align: center;
    }
  }
`;

export const StyledClose = styled.div`
  position: absolute;
  right: 18px;
  img {
    margin-top: 12px;
    margin-right: 10px;
    height: 16px;
    width: 16px;
    cursor: pointer;
  }
  svg {
    fill: #5b6987;
  }
`;
