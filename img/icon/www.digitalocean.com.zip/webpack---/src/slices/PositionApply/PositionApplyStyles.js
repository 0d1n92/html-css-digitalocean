// Styles here will override Bulma styles
import { css } from '@emotion/core';
import styled from '@emotion/styled';
import media from 'css-in-js-media';

export const styledCurrentOpeningsSection = css`
  display: flex;
  flex-direction: column;
  justify-content: center;
  background-repeat: no-repeat;
  padding-bottom: 0;
`;

export const StyledIframe = styled.div`
  margin-top: 180px;
  width: 100%;

  ${media('< desktop')} {
    div.altru-widget-container[id^='altru-widget-'] {
      display: none;
    }
  }
`;

export const StyledPositionHeader = styled.div`
  h1,
  h4 {
    color: #fff;
  }

  position: relative;
  text-align: center;
  width: 100%;
`;

export const styledIframeContainer = css`
  width: 100%;
`;
