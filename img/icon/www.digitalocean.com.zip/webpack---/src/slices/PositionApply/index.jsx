/* eslint-disable camelcase */
import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import { Helmet } from 'react-helmet';

import BulmaContainer from 'react-bulma-components/lib/components/container';
import BulmaSection from 'react-bulma-components/lib/components/section';

import { css } from '@emotion/core';

import {
  styledCurrentOpeningsSection,
  StyledPositionHeader,
  styledIframeContainer,
  StyledIframe,
} from './PositionApplyStyles';

const PositionApply = ({ input }) => {
  const { background_color, background_image } = input.primary;
  const [jobTitle, setJobTitle] = useState('');
  const [jobLocation, setJobLocation] = useState('');

  useEffect(() => {
    let ghreApi = '';

    if (typeof window === 'undefined' || !window.document) {
      // return
    } else {
      const url_string = document.location.href;
      const url = new URL(url_string);
      const jid = url.searchParams.get('gh_jid');
      ghreApi = `https://api.greenhouse.io/v1/boards/digitalocean98/jobs/${jid}`;

      const script = document.createElement('script');
      script.src = 'https://boards.greenhouse.io/embed/job_board/js?for=digitalocean98';
      document.body.appendChild(script);

      setTimeout(function() {
        Grnhse.Iframe.load(); //eslint-disable-line
      }, 500);
    }

    const getData = async () => {
      const resp = await fetch(ghreApi);
      const data = await resp.json();

      setJobTitle(data.title);
      setJobLocation(data.location.name);
    };
    getData();
  }, []);

  return (
    <span>
      <Helmet>
        <script src="https://widget.altrulabs.com/main.js" data-altru-widget-id="5694" />
        <title>DigitalOcean - {jobTitle}</title>
        <meta property="og:title" content={jobTitle} />
        <meta name="twitter:title" content={jobTitle} />
        <meta
          name="twitter:description"
          content={jobTitle ? `DigitalOcean: ${jobTitle}: ${jobLocation}` : 'DigitalOcean'}
        />
        <meta
          property="og:description"
          content={jobTitle ? `DigitalOcean: ${jobTitle}: ${jobLocation}` : 'DigitalOcean'}
        />
      </Helmet>
      <BulmaSection
        css={css`
          ${styledCurrentOpeningsSection}
          background-color: ${background_color};
          ${background_image ? `background-image: url(${background_image.url});` : null};
        `}
      >
        <BulmaContainer css={styledIframeContainer}>
          <StyledPositionHeader>
            <span>
              <h1 className="h1 white">{jobTitle}</h1>
              <h4>{jobLocation}</h4>
            </span>
          </StyledPositionHeader>
          <StyledIframe>
            <div id="grnhse_app" />
          </StyledIframe>
        </BulmaContainer>
      </BulmaSection>
    </span>
  );
};

export default PositionApply;

PositionApply.propTypes = {
  input: PropTypes.object.isRequired,
};
