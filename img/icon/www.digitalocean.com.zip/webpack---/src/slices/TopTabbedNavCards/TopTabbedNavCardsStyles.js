import { css, keyframes } from '@emotion/core';
import media from 'css-in-js-media';

const contentAnimation = keyframes`
  from {
    opacity: 0.0;
  }
  to {
    opacity: 1.0;
  }
`;

export const styledHeading = css`
  margin: 60px auto 0 auto;
`;

export const styledSubheading = css`
  margin: 0 auto;
  max-width: 100% !important;
`;

export const styledHeadingContainer = css`
  text-align: center;
`;

export const styledCards = css`
  display: grid;
  grid-auto-flow: row;
  grid-auto-rows: 1fr;
  grid-gap: 32px;
  max-width: 1168px;
  text-align: left;
  margin: 64px auto 0 auto;
  justify-content: space-between;
  animation: ${contentAnimation} 0.2s ease-in forwards;

  ${media('< largeDesktop')} {
    grid-template-columns: repeat(4, minmax(210px, 1fr));
  }

  ${media('< desktop')} {
    display: flex;
    justify-content: flex-start;
    flex-direction: column;
    margin-top: 0px;
    margin-left: 0px;
    margin-right: 0px;
  }

  /* Styles that customize Cards atom to work as needed for TopTabbedNavCards*/
  img {
    max-height: 50px;
    min-height: 40px;
  }

  .box {
    padding: 30px !important;

    p {
      margin-bottom: 0;
    }
  }
`;

export const styledLink = css`
  margin-top: 64px;
  display: flex;
  justify-content: center;
  align-items: baseline;
`;
