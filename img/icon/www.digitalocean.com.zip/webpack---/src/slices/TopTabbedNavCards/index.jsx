/* eslint-disable camelcase */
import React from 'react';
import PropTypes from 'prop-types';

import BulmaContainer from 'react-bulma-components/lib/components/container';
import BulmaSection from 'react-bulma-components/lib/components/section';

import { css } from '@emotion/core';

import { Heading, Tab, Card, TextLink } from '../atoms';

import {
  styledHeading,
  styledSubheading,
  styledHeadingContainer,
  styledCards,
  styledLink,
} from './TopTabbedNavCardsStyles';
import { TopTabContainer } from '../atoms/Tabs/TopTabNav';

const renderHeading = (text, atts) => <Heading {...atts}>{text.text}</Heading>;

const renderCard = (image, title, title_color, text, text_color, link) => {
  if (image || title || text)
    return (
      <Card image={image} title={title} title_color={title_color} text={text} text_color={text_color} link={link} />
    );
  return null;
};

const renderCards = item => {
  const { heading, heading_color, subheading, subheading_color, text_color, cta_link_text, cta_link_url } = item;
  return (
    <>
      {heading && heading[0].text
        ? renderHeading(heading[0], {
            renderAs: 'h3',
            className: `${text_color === 'light' && !heading_color ? 'h3 white' : 'h3 darkblue'}`,
            style: { color: heading_color },
            css: styledHeading,
          })
        : null}
      {subheading && subheading[0].text
        ? renderHeading(subheading[0], {
            renderAs: 'p',
            className: `${text_color === 'light' && !subheading_color ? 'medium white' : 'medium darkgrey'}`,
            style: { color: subheading_color },
            subtitle: true,
            css: styledSubheading,
          })
        : null}
      <div
        css={styledCards}
        style={{
          gridTemplateColumns: `repeat(${Number(item.columns)}, 1fr)`,
          textAlign: `${item.card_content_alignment === 'center' ? 'center' : 'left'}`,
        }}
        data-testid="cards_container"
      >
        {renderCard(
          item.card_1_image,
          item.card_1_title,
          item.title_color,
          item.card_1_text,
          item.text_color,
          item.card_1_link_url,
        )}
        {renderCard(
          item.card_2_image,
          item.card_2_title,
          item.title_color,
          item.card_2_text,
          item.text_color,
          item.card_2_link_url,
        )}
        {renderCard(
          item.card_3_image,
          item.card_3_title,
          item.title_color,
          item.card_3_text,
          item.text_color,
          item.card_3_link_url,
        )}
        {renderCard(
          item.card_4_image,
          item.card_4_title,
          item.title_color,
          item.card_4_text,
          item.text_color,
          item.card_4_link_url,
        )}
        {renderCard(
          item.card_5_image,
          item.card_5_title,
          item.title_color,
          item.card_5_text,
          item.text_color,
          item.card_5_link_url,
        )}
        {renderCard(
          item.card_6_image,
          item.card_6_title,
          item.title_color,
          item.card_6_text,
          item.text_color,
          item.card_6_link_url,
        )}
        {renderCard(
          item.card_7_image,
          item.card_7_title,
          item.title_color,
          item.card_7_text,
          item.text_color,
          item.card_7_link_url,
        )}
        {renderCard(
          item.card_8_image,
          item.card_8_title,
          item.title_color,
          item.card_8_text,
          item.text_color,
          item.card_8_link_url,
        )}
        {renderCard(
          item.card_9_image,
          item.card_9_title,
          item.title_color,
          item.card_9_text,
          item.text_color,
          item.card_9_link_url,
        )}
        {renderCard(
          item.card_10_image,
          item.card_10_title,
          item.title_color,
          item.card_10_text,
          item.text_color,
          item.card_10_link_url,
        )}
        {renderCard(
          item.card_11_image,
          item.card_11_title,
          item.title_color,
          item.card_11_text,
          item.text_color,
          item.card_11_link_url,
        )}
        {renderCard(
          item.card_12_image,
          item.card_12_title,
          item.title_color,
          item.card_12_text,
          item.text_color,
          item.card_12_link_url,
        )}
      </div>
      {cta_link_text && cta_link_url && cta_link_url.url ? (
        <TextLink url={cta_link_url.url} className="medium arrow" css={styledLink}>
          {cta_link_text}
        </TextLink>
      ) : null}
    </>
  );
};

const TopTabbedNavCards = ({ input }) => {
  const {
    heading,
    subheading,
    background_image,
    background_color,
    text_color,
    heading_color,
    subheading_color,
  } = input.primary;

  return (
    <BulmaSection
      css={css`
        background-image: url(${background_image ? background_image.url : ''});
        background-color: ${background_color};
      `}
    >
      <BulmaContainer css={styledHeadingContainer}>
        {heading && heading[0].text
          ? renderHeading(heading[0], {
              renderAs: 'h2',
              className: `${text_color === 'light' && !heading_color ? 'h2 white' : 'h2 darkblue'}`,
              style: { color: heading_color },
            })
          : null}
        {subheading && subheading[0].text
          ? renderHeading(subheading[0], {
              renderAs: 'h4',
              className: `${text_color === 'light' && !subheading_color ? 'h4 white' : 'h4 darkgrey'}`,
              style: { color: subheading_color },
              subtitle: true,
              css: styledSubheading,
            })
          : null}

        <TopTabContainer text_color={text_color} data-testid="top_tab_container">
          {input.fields.map(item => (
            <Tab
              key={`tabbed-content-${item.tab_label[0].text}`}
              label={item.tab_label[0].text}
              icon={item.tab_icon}
              content={[renderCards(item)]}
              label_color={item.label_color}
              content_color={item.content_color}
            />
          ))}
        </TopTabContainer>
      </BulmaContainer>
    </BulmaSection>
  );
};

export default TopTabbedNavCards;

TopTabbedNavCards.propTypes = {
  input: PropTypes.object.isRequired,
};
