// Styles here will override Bulma styles
import styled from '@emotion/styled';
import { css } from '@emotion/core';
import media from 'css-in-js-media';

export const StyledSubnote = styled.div`
  text-align: center;
`;

export const StyledToolTip = styled.div`
  position: relative;
  display: inline-block;
  margin: 3px 0 0 8px;
  cursor: pointer;

  :hover span {
    visibility: visible;
    opacity: 1;
  }
  ${media('< tablet')} {
    position: absolute;
    right: 6%;
  }
`;
export const StyledToolTipText = styled.span`
  visibility: hidden;
  width: 300px;
  background-color: #031b4e;
  text-align: left;
  padding: 10px;
  border-radius: 6px;
  font-size: 12px;

  p {
    color: #fff !important;
  }

  /* Position the tooltip text */
  position: absolute;
  z-index: 1;
  bottom: 125%;
  left: 50%;
  margin-left: -60px;

  ${media('< tablet')} {
    left: -230px;
  }

  /* Fade in tooltip */
  opacity: 0;
  transition: opacity 0.3s;

  ::after {
    content: '';
    position: absolute;
    top: 100%;
    left: 18%;
    margin-left: -5px;
    border-width: 5px;
    border-style: solid;
    border-color: #031b4e transparent transparent transparent;

    ${media('< tablet')} {
      display: none;
    }
  }
`;

export const styledPricingSection = css`
  background-repeat: repeat;
  background-size: cover;
`;

export const styledPricingContainer = css`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
`;

export const StyledRecommend = styled.span`
  position: absolute;
  right: 32px;
  color: white;
  font-size: 12px;
  background-color: #0069ff;
  border-radius: 50px;
  padding: 5px 10px;
`;

export const StyledBullets = styled.ul`
  list-style: none;
  li {
    display: flex;
    align-items: flex-start;
    justify-content: flex-start;
    margin: 18px 0;

    p {
      margin: 0;
    }

    img {
      width: 16px;
      height: 16px;
      margin: 3px 8px 0 0;
    }
  }
`;

export const styledHeading = css`
  margin: 0 auto;
  text-align: center;
`;

export const styledSubtitle = css`
  margin: 20px auto 80px auto !important;
  max-width: 670px;
  text-align: center;
`;

export const StyledNote = styled.div`
  text-align: left;
  display: flex;
  width: 100%;
  align-items: flex-start;
  border-top: 1px solid #e5e8ed;

  span {
    color: #0069ff;
    margin-right: 10px;
    margin-top: 20px;
  }
`;

export const StyledCards = styled.div`
  display: flex;
  max-width: 1170px;
  margin: 64px auto;
  box-shadow: 0px 8px 13px 0px #000000 5%;
  background-color: #fff;
  border-radius: 3px;

  .recommended {
    background-color: #f2f8ff;
    border: 1px solid #0069ff;
    position: relative;
  }

  ${media('< desktop')} {
    flex-direction: column;
    width: 95%;
  }
`;

export const StyledCol = styled.div`
  padding: 36px;
  border: 1px solid #e5e8ed;

  ${media('> desktop')} {
    &:first-of-type {
      border-right: none;
    }

    &:last-of-type {
      border-left: none;
    }
  }
  p {
    margin: 8px 0 0 0;
  }
`;

export const styledButton = css`
  margin-top: 60px;
`;

export const StyledPricing = styled.p`
  font-weight: 900;
  color: #031b4e;
  height: 77px;
  margin: 32px 0 !important;
  display: flex;
  align-items: center;

  span.price {
    font-size: 58px;
    padding: 0 6px;
  }
`;
