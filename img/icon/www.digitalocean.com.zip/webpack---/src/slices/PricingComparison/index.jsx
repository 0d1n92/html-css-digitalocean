/* eslint-disable camelcase */
import React from 'react';
import PropTypes from 'prop-types';
import { RichText } from 'prismic-reactjs';

import BulmaContainer from 'react-bulma-components/lib/components/container';
import BulmaSection from 'react-bulma-components/lib/components/section';

import { Heading, Button, LazyLink, LazyImage } from '../atoms';

import { createRandomId } from '../../util/createRandomId';
import { linkResolver } from '../../util/linkResolver';
import tooltipicon from '../../assets/images/tooltipicon.svg';

import {
  styledPricingSection,
  styledPricingContainer,
  styledHeading,
  styledSubtitle,
  styledButton,
  StyledToolTip,
  StyledToolTipText,
  StyledSubnote,
  StyledBullets,
  StyledRecommend,
  StyledCol,
  StyledNote,
  StyledCards,
  StyledPricing,
} from './PricingComparisonStyles';

// function to render each bullet out
const renderBullet = (bullet, icon_bullet) =>
  bullet.bullet_text && (
    <li>
      <LazyImage src={icon_bullet.url || null} alt="bullet icon" />
      <RichText render={bullet.bullet_text} linkResolver={linkResolver} />

      {bullet.bullet_tooltip && bullet.bullet_tooltip[0].text !== '' && (
        <StyledToolTip>
          <LazyImage src={tooltipicon} alt="tooltip icon" />
          <StyledToolTipText>
            <RichText render={bullet.bullet_tooltip} linkResolver={linkResolver} />
          </StyledToolTipText>
        </StyledToolTip>
      )}
    </li>
  );

const PricingComparison = ({ input }) => {
  const {
    text_color,
    background_color,
    background_image,
    button_color,
    cta_button_text,
    cta_button_url,
    heading,
    heading_color,
    subheading,
    subheading_color,
    subnote,
    target_name,
  } = input.primary;
  const { fields } = input;

  // this maps all of the bullets into arrays to make code DRYer
  const bullets = fields.map(row => [
    { bullet_text: row.bullet1 && [row.bullet1[0]], bullet_tooltip: row.bullet1_tooltip && [row.bullet1_tooltip[0]] },
    { bullet_text: row.bullet2 && [row.bullet2[0]], bullet_tooltip: row.bullet2_tooltip && [row.bullet2_tooltip[0]] },
    { bullet_text: row.bullet3 && [row.bullet3[0]], bullet_tooltip: row.bullet3_tooltip && [row.bullet3_tooltip[0]] },
    { bullet_text: row.bullet4 && [row.bullet4[0]], bullet_tooltip: row.bullet4_tooltip && [row.bullet4_tooltip[0]] },
    { bullet_text: row.bullet5 && [row.bullet5[0]], bullet_tooltip: row.bullet5_tooltip && [row.bullet5_tooltip[0]] },
    { bullet_text: row.bullet6 && [row.bullet6[0]], bullet_tooltip: row.bullet6_tooltip && [row.bullet6_tooltip[0]] },
    { bullet_text: row.bullet7 && [row.bullet7[0]], bullet_tooltip: row.bullet7_tooltip && [row.bullet7_tooltip[0]] },
    { bullet_text: row.bullet8 && [row.bullet8[0]], bullet_tooltip: row.bullet8_tooltip && [row.bullet8_tooltip[0]] },
    { bullet_text: row.bullet9 && [row.bullet9[0]], bullet_tooltip: row.bullet9_tooltip && [row.bullet9_tooltip[0]] },
    {
      bullet_text: row.bullet10 && [row.bullet10[0]],
      bullet_tooltip: row.bullet10_tooltip && [row.bullet10_tooltip[0]],
    },
    {
      bullet_text: row.bullet11 && [row.bullet11[0]],
      bullet_tooltip: row.bullet11_tooltip && [row.bullet11_tooltip[0]],
    },
    {
      bullet_text: row.bullet12 && [row.bullet12[0]],
      bullet_tooltip: row.bullet12_tooltip && [row.bullet12_tooltip[0]],
    },
    {
      bullet_text: row.bullet13 && [row.bullet13[0]],
      bullet_tooltip: row.bullet13_tooltip && [row.bullet13_tooltip[0]],
    },
    {
      bullet_text: row.bullet14 && [row.bullet14[0]],
      bullet_tooltip: row.bullet14_tooltip && [row.bullet14_tooltip[0]],
    },
    {
      bullet_text: row.bullet15 && [row.bullet15[0]],
      bullet_tooltip: row.bullet15_tooltip && [row.bullet15_tooltip[0]],
    },
    {
      bullet_text: row.bullet16 && [row.bullet16[0]],
      bullet_tooltip: row.bullet16_tooltip && [row.bullet16_tooltip[0]],
    },
  ]);

  return (
    <BulmaSection
      id="testPricingSection"
      css={styledPricingSection}
      style={{
        backgroundImage: `url(${background_image && background_image.url})`,
        backgroundColor: background_color,
        paddingTop: `${!heading && !subheading ? '64px' : null}`,
        paddingBottom: `${!heading && !subheading ? '64px' : null}`,
      }}
    >
      <BulmaContainer css={styledPricingContainer} id={target_name}>
        {heading && heading[0].text ? (
          <Heading
            style={heading_color ? { color: heading_color } : null}
            css={styledHeading}
            className={text_color === 'light' ? 'h2 white' : 'h2 darkblue'}
            renderAs="h2"
          >
            {heading[0].text}
          </Heading>
        ) : null}
        {subheading && subheading[0].text ? (
          <Heading
            style={subheading_color ? { color: subheading_color } : null}
            css={styledSubtitle}
            subtitle
            className={text_color === 'light' ? 'medium white' : 'medium darkgrey'}
            renderAs="p"
          >
            {subheading[0].text}
          </Heading>
        ) : null}

        <StyledCards>
          {fields.map((col, i) => {
            const { title1, subtitle, recommended, pricing_copy, price, note_copy, note, interval, icon_bullet } = col;
            return (
              <StyledCol className={recommended ? 'recommended' : ''} key={createRandomId()}>
                {recommended && <StyledRecommend>Recommended</StyledRecommend>}
                <Heading className="h4 lightblue" renderAs="h4">
                  {title1[0].text}
                </Heading>
                <Heading className={text_color === 'light' ? 'medium white' : 'medium darkgrey'}>
                  <RichText render={subtitle} linkResolver={linkResolver} />
                </Heading>
                <StyledPricing>
                  {pricing_copy || null} <span className="price">${price || 0}</span> / {interval || null} {note && '*'}
                </StyledPricing>
                <StyledBullets>{bullets[i].map(bullet => renderBullet(bullet, icon_bullet))}</StyledBullets>
                {note && note_copy && (
                  <StyledNote>
                    <span>*</span>
                    <RichText render={note_copy} linkResolver={linkResolver} />
                  </StyledNote>
                )}
              </StyledCol>
            );
          })}
        </StyledCards>
        {subnote && (
          <StyledSubnote className={text_color === 'light' ? 'medium white' : 'medium darkgrey'}>
            <RichText render={subnote} linkResolver={linkResolver} />
          </StyledSubnote>
        )}
        {cta_button_url && cta_button_url.url ? (
          <Button css={styledButton} color={button_color} renderAs={LazyLink} url={cta_button_url.url}>
            {cta_button_text}
          </Button>
        ) : null}
      </BulmaContainer>
    </BulmaSection>
  );
};

export default PricingComparison;

PricingComparison.propTypes = {
  input: PropTypes.object.isRequired,
};
