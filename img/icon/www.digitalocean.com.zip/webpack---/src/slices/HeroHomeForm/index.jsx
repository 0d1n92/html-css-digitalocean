/* eslint-disable */
/* eslint-disable camelcase */
import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { useForm } from 'react-hook-form';

import BulmaCard from 'react-bulma-components/lib/components/card';
import BulmaContainer from 'react-bulma-components/lib/components/container';
import BulmaHero from 'react-bulma-components/lib/components/hero';

import { RichText } from 'prismic-reactjs';
import { linkResolver } from '../../util/linkResolver';

import { createRandomId } from '../../util/createRandomId';
import { Heading, Button, LazyImage } from '../atoms';
import heroBg from '../../assets/images/bg-home-hero-3.svg';

import {
  styledHeroBox,
  styledHeroBoxTitle,
  StyledForm,
  styledHeroBoxContainerWrapper,
  StyledButtonsContainer,
  styledButton,
  styledSubmit,
  styledButtonWText,
  StyledHeroCopy,
  StyledSubscript,
} from './HeroHomeFormStyles';

const renderHeading = (text, atts) => <Heading {...atts}>{text.text}</Heading>;

const HeroHomeForm = ({ input }) => {
  const {
    fullscreen,
    background_color,
    background_image,
    large_text,
    email_placeholder,
    form_title,
    name_placeholder,
    password_placeholder,
    headline,
    headline_color,
    subheadline,
    subheadline_color,
    submit_button_text,
    subscript,
    text_color,
  } = input.primary;

  const { fields } = input;

  const [validEmailClass, setValidEmailClass] = useState('hide-error');
  const [errorResponse, setErrorResponseMessage] = useState('');

  const { register, handleSubmit, watch, errors } = useForm();
  /*const onSubmit = data => {
    fetch('https://cloud.digitalocean.com/graphql/public/register', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        operationName: 'createAccount',
        variables: { createReq: { name: data.name, password: data.password, email: data.email } },
        query:
          'mutation createAccount($createReq: CreateAccountRequest!) {\n  createAccount(CreateAccountRequest: $createReq) {\n    uuid\n    redirect_url\n    __typename\n  }\n}\n',
      }),
    })
      .then(response => {
       
        if (response.status === 200 && response.errors) {
          returnErrorResponse(response.errors[0].message);
        }

        if (response.status === 200 && !response.errors) {
          window.location.href = 'https://cloud.digitalocean.com';
        }

        if (response.status === 403) {
          window.location.href =
            'https://cloud.digitalocean.com/graphql/public/test?challenge=https://www.digitalocean.com/';
        }
        
      })
      .catch(error => {
        console.error('Error:', error);
      });
  };*/

  const onChange = event => {
    const { value } = event.target;
    const checkEmailFormat = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);

    !checkEmailFormat ? setValidEmailClass('show-error error-text') : setValidEmailClass('hide-error');
  };

  const onButtonClick = event => {
    window.location.href = event.currentTarget.dataset.href;
  };

  const returnErrorResponse = data => {
    switch (data) {
      case 'unknown':
        setErrorResponseMessage('Please try your request again. If the problem persists, contact customer support.');
        break;
      case 'password_is_common':
        setErrorResponseMessage('Please choose a less-common password.');
        break;
      case 'password_is_email':
        setErrorResponseMessage('Please ensure that your password is distinct from your email address.');
        break;
      case 'password_is_name':
        setErrorResponseMessage('Please ensure that your password is distinct from your name.');
        break;
      case 'email_exists':
        setErrorResponseMessage('Sorry, that email address is already associated with an account.');
        break;
      case 'too_long':
        setErrorResponseMessage('Sorry, that email address is already associated with an account.');
        break;
    }
  };
  return (
    <BulmaHero
      data-testid="bulma_hero"
      css={styledHeroBoxContainerWrapper}
      style={{
        backgroundColor: background_color || '#031b4e',
        backgroundImage: background_image && background_image.url ? `url(${background_image.url})` : `url(${heroBg})`,
      }}
    >
      <BulmaHero.Body>
        <BulmaContainer>
          <StyledHeroCopy>
            {renderHeading(headline[0], {
              style: headline_color ? { color: headline_color } : null,
              className: `${text_color === 'light' ? 'h1 white' : 'h1 darkblue'} ${large_text ? 'hero-title' : ''}`,
              renderAs: 'h1',
              'data-testid': 'hero_heading',
            })}
            {renderHeading(subheadline[0], {
              style: subheadline_color && { color: subheadline_color },
              className: text_color === 'light' ? 'large white' : 'large darkgrey',
              subtitle: true,
              renderAs: 'p',
              'data-testid': 'hero_subheading',
            })}
          </StyledHeroCopy>
          <div>
            <BulmaCard css={styledHeroBox} data-testid="hero_box">
              <BulmaCard.Header.Title css={styledHeroBoxTitle}>
                {renderHeading(form_title[0], {
                  className: 'h5 darkblue',
                  renderAs: 'h5',
                  'data-testid': 'hero_box_title',
                })}
              </BulmaCard.Header.Title>
              <BulmaCard.Content>
                <StyledForm
                  className="form-align-left"
                  action="https://cloud.digitalocean.com/registrations"
                  method="post"
                >
                  <span className="form-wrapper">
                    <span className="error-text">{errorResponse}</span>
                    <input
                      aria-label="signup button"
                      type="text"
                      minLength="2"
                      name="user[name]"
                      placeholder="First Name"
                      required
                    />
                    <input aria-label="email" type="email" name="user[email]" placeholder="Email Address" required />
                    <input
                      aria-label="password"
                      type="password"
                      minLength="8"
                      name="user[password]"
                      placeholder="Password"
                      required
                    />
                    <Button css={styledSubmit} type="submit" color="primary">
                      {submit_button_text}
                    </Button>
                  </span>
                </StyledForm>
              </BulmaCard.Content>
              <StyledButtonsContainer>
                {fields.map(button => (
                  <Button
                    css={button.button_text !== null ? styledButtonWText : styledButton}
                    key={createRandomId()}
                    onClick={onButtonClick}
                    data-href={button.button_link.url}
                    id={button.button_text || 'github_button'}
                    aria-label={button.button_text || 'signup_button'}
                  >
                    <LazyImage src={button.icon.url} alt={button.icon.alt || button.button_text || 'icon'} />
                    {button.button_text}
                  </Button>
                ))}
              </StyledButtonsContainer>
            </BulmaCard>
            <StyledSubscript>
              <RichText render={subscript} linkResolver={linkResolver} />
            </StyledSubscript>
          </div>
        </BulmaContainer>
      </BulmaHero.Body>
    </BulmaHero>
  );
};

export default HeroHomeForm;

HeroHomeForm.propTypes = {
  input: PropTypes.object.isRequired,
};
