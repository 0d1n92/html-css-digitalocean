import styled from '@emotion/styled';
import { css } from '@emotion/core';
import media from 'css-in-js-media';

export const StyledPressNews = styled.div`
  max-width: 900px;
  margin: auto;

  ${media('< desktop')} {
    .columns {
      flex-direction: column;
      align-items: center;
      text-align: center;
    }

    .column {
      width: 80%;
      margin: auto;
    }
  }
`;

export const styledHeading = css`
  margin: 60px auto 0 auto;
  text-align: center;
`;

export const styledSubheading = css`
  margin: 20px auto 80px auto !important;
  max-width: 850px;
  text-align: center;
`;

export const styledMainArticleContainer = css`
  margin-right: 40px;
  word-break: break-all !important;
  display: flex;
  flex-direction: column;
  align-items: flex-start;

  .image img {
    margin-bottom: 20px;
    height: auto;
  }

  ${media('< desktop')} {
    margin: auto;
    text-align: center;
    align-items: center;
    .image img {
      margin-bottom: 20px;
    }
  }
`;

export const styledCompanyLogo = css`
  height: auto !important;
  margin-left: 0px;
  margin-bottom: 24px;

  ${media('< desktop')} {
    margin: auto;
  }
`;

export const styledButton = css`
  margin-top: 20px;
`;

export const StyledNewsList = styled.ul`
  display: flex;
  flex-direction: column;
  list-style: none;
  max-height: 350px;
  overflow: scroll;

  li {
    margin-top: 10px;
  }

  .subtitle {
    margin-bottom: 15px;
  }

  ${media('< desktop')} {
    margin-top: 20px;

    li {
      margin-top: 20px;
    }
  }
`;

export const styledColumnImage = css`
  ${media('< desktop')} {
    display: flex;
  }
  ${media('< tablet')} {
    margin: auto;
  }
`;

export const StyledRichText = styled.div`
  p {
    color: ${props => props.color};
  }
`;

export const StyledCompanyDate = styled.div`
  display: flex;
  align-items: center;
  font-size: 11px;
  margin-top: 12px;
  margin-bottom: 15px;

  ${media('< desktop')} {
    justify-content: center;
  }
`;

export const StyledCompany = styled.span`
  margin-right: 4px;
  margin-bottom: 2px;
`;

export const StyledMiddleDot = styled.span`
  display: inline-flex;
  vertical-align: bottom;
  font-size: 15px;
  margin-right: 4px;
`;

export const StyledDate = styled.span`
  margin-bottom: 2px;
`;

export const styledSubArticleTitleLink = css`
  font-size: 16px;
`;

export const styledMainArticleLink = css`
  font-size: 36px;
  word-break: normal;

  ${media('< desktop')} {
    margin-top: 20px;
  }
`;

export const StyledParagraph = styled.p`
  line-height: 150%;
  font-family: 'Sailec-Bold' !important;
  text-transform: uppercase;

  /* color */
  &.white {
    color: #fff;
  }
  &.darkgrey {
    color: #5b6987;
  }
`;
