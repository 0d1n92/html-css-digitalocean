/* eslint-disable camelcase */
import React from 'react';
import PropTypes from 'prop-types';
import { RichText } from 'prismic-reactjs';

import BulmaColumns from 'react-bulma-components/lib/components/columns';
import BulmaContainer from 'react-bulma-components/lib/components/container';
import BulmaSection from 'react-bulma-components/lib/components/section';
import { linkResolver } from '../../util/linkResolver';

import { Button, Heading, TextLink, LazyLink, LazyImage } from '../atoms';

import {
  styledButton,
  styledCompanyLogo,
  styledSubArticleTitleLink,
  styledMainArticleContainer,
  styledMainArticleLink,
  styledHeading,
  styledSubheading,
  StyledNewsList,
  StyledCompanyDate,
  StyledCompany,
  StyledDate,
  StyledMiddleDot,
  StyledPressNews,
  StyledRichText,
  StyledParagraph,
} from './PressNewsStyles';

const renderHeading = (text, atts) => (
  <Heading {...atts} css={atts.css}>
    {text.text}
  </Heading>
);

const renderCompanyDate = (companyName, unformattedDate, defaultTextColor) => {
  const getFormattedDate = dateStr => {
    const dateArr = new Date(dateStr).toString().split(' ');
    return `${dateArr[1]} ${dateArr[2]}, ${dateArr[3]}`;
  };

  return (
    <StyledCompanyDate>
      <StyledParagraph className={defaultTextColor === 'light' ? 'white' : 'darkgrey'}>
        <StyledCompany data-testid="article_company_name">{companyName[0].text}</StyledCompany>
        <StyledMiddleDot>&#183;</StyledMiddleDot>
        <StyledDate data-testid="article_date">{getFormattedDate(unformattedDate)}</StyledDate>
      </StyledParagraph>
    </StyledCompanyDate>
  );
};

const renderListItem = (item, defaultTextColor, titleColor) => {
  const { sub_article_company_name, sub_article_date, sub_article_title, sub_article_url } = item;
  return (
    <li key={sub_article_title[0].text}>
      <TextLink
        data-testid="sub_article_title"
        css={styledSubArticleTitleLink}
        style={{ color: titleColor || (defaultTextColor === 'light' ? '#fff' : '#031b4e') }}
        url={sub_article_url.url}
      >
        {sub_article_title[0].text}
      </TextLink>
      {renderCompanyDate(sub_article_company_name, sub_article_date, defaultTextColor)}
    </li>
  );
};

const PressNews = ({ input }) => {
  const {
    text_color,
    background_color,
    background_image,
    cta_button_text,
    cta_button_url,
    heading,
    heading_color,
    main_article_company_name,
    main_article_content,
    main_article_url,
    main_article_date,
    main_article_title,
    main_article_logo,
    main_article_content_color,
    main_article_title_color,
    sub_article_title_color,
    subheading,
    subheading_color,
  } = input.primary;

  return (
    <BulmaSection
      style={{
        backgroundImage: background_image && background_image.url ? `url(${background_image.url})` : null,
        backgroundColor: background_color || null,
      }}
    >
      <BulmaContainer>
        <StyledPressNews>
          {heading &&
            heading[0].text &&
            renderHeading(heading[0], {
              style: {
                color: heading_color || null,
                marginBottom: !subheading ? '64px' : null,
              },
              css: styledHeading,
              className: text_color === 'light' ? 'h2 white' : 'h2 darkblue',
              renderAs: 'h2',
            })}
          {subheading &&
            subheading[0].text &&
            renderHeading(subheading[0], {
              style: subheading_color ? { color: subheading_color } : null,
              css: styledSubheading,
              className: text_color === 'light' ? 'medium white' : 'medium darkgrey',
              subtitle: true,
            })}
          <BulmaColumns>
            <BulmaColumns.Column css={styledMainArticleContainer} size={7}>
              {main_article_logo && main_article_logo.url && (
                <LazyImage
                  data-testid="main_article_logo"
                  css={styledCompanyLogo}
                  src={main_article_logo.url}
                  width={128}
                />
              )}
              <TextLink
                data-testid="main_article_title"
                css={styledMainArticleLink}
                style={{
                  color: main_article_title_color || (text_color === 'light' ? '#fff' : '#031b4e'),
                }}
                url={main_article_url && main_article_url.url && main_article_url.url}
              >
                {main_article_title[0].text}
              </TextLink>
              {main_article_company_name &&
                main_article_date &&
                renderCompanyDate(main_article_company_name, main_article_date, text_color)}
              <StyledRichText color={main_article_content_color || (text_color === 'light' ? '#fff' : '#5b6987')}>
                <RichText render={main_article_content} linkResolver={linkResolver} />
              </StyledRichText>
              {cta_button_text && (
                <Button
                  css={styledButton}
                  color={text_color === 'light' ? 'white' : 'primary'}
                  outlined
                  url={cta_button_url.url}
                  renderAs={LazyLink}
                >
                  {cta_button_text}
                </Button>
              )}
            </BulmaColumns.Column>
            <BulmaColumns.Column>
              <StyledNewsList>
                {input.fields.map(item => renderListItem(item, text_color, sub_article_title_color))}
              </StyledNewsList>
            </BulmaColumns.Column>
          </BulmaColumns>
        </StyledPressNews>
      </BulmaContainer>
    </BulmaSection>
  );
};

export default PressNews;

PressNews.propTypes = {
  input: PropTypes.object.isRequired,
};
