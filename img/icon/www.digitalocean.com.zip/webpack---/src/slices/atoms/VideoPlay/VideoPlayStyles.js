import styled from '@emotion/styled';

export const StyledVideoPlay = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  color: #fff;
  cursor: pointer;
  transition: all 0.3s ease;
  margin-top: 32px;

  &:hover {
    transform: scale(1.04);
  }

  img {
    margin-right: 3px;
  }

  figure {
    width: 20px;
    height: 20px;
    margin: 0 4px 0 0;
  }

  p {
    font-size: 0.75em;
    line-height: 2em;
    margin: 0 2px;
  }
`;
