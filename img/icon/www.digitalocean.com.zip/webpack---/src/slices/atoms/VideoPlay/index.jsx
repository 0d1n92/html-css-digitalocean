import React from 'react';

import { LazyImage } from '..';
import playLight from '../../../assets/images/play-light.svg';
import playDark from '../../../assets/images/play-dark.svg';
import { StyledVideoPlay } from './VideoPlayStyles';

const VideoPlay = (
  video_title,
  video_timestamp,
  video_timestamp_color,
  text_color,
  onClickSetModalIsShowing,
  onKeyPressSetModalIsShowing,
  className,
) => {
  return (
    <StyledVideoPlay
      className={className}
      role="button"
      tabIndex="0"
      onClick={() => onClickSetModalIsShowing(true)}
      onKeyPress={() => onKeyPressSetModalIsShowing(true)}
      id="testVideoPlayButton"
    >
      <LazyImage src={text_color === 'light' ? playLight : playDark} width={20} bulma />
      <p style={{ color: text_color === 'light' ? 'white' : '#5b6987' }}>{video_title[0].text}</p>
      <p
        style={{
          color: video_timestamp_color || (text_color === 'light' ? 'white' : '#5b6987'),
        }}
      >
        {video_timestamp[0].text}
      </p>
    </StyledVideoPlay>
  );
};

export default VideoPlay;
