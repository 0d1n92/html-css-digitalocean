/* eslint-disable camelcase */
import React, { useState, useEffect, useRef } from 'react';
import PropTypes from 'prop-types';

import BulmaButton from 'react-bulma-components/lib/components/button';
import BulmaContainer from 'react-bulma-components/lib/components/container';
import BulmaColumns from 'react-bulma-components/lib/components/columns';

import { css } from '@emotion/core';
import { createRandomId } from '../../../../util/createRandomId';
import {
  styledTab,
  styledButton,
  styledLineContainer,
  styledLine,
  styledContent,
  styledContentWrapper,
  styledSlidingTabsContainer,
  styledTabContent,
  tabScrollAnchor,
} from '../TabsStyles';

import Button from '../../Button';
import LazyLink from '../../LazyLink';

// This component exists solely to provide an interface
// to use in the <TabsContainer /> component, so that we can
// take these <Tab /> components and control them.
/* eslint-disable no-unused-vars */
export const SlidingTab = ({ label, content }) => null;

const ControlledTab = ({ label, label_color, id, text_color, isSelected, onClick }) => {
  const activeLabelColor = isSelected && text_color === 'light' ? '#fff' : 'rgba(3, 27, 78, 1)';
  const labelColor = !isSelected && text_color === 'light' ? 'rgba(225, 225, 225, 0.6)' : 'rgba(3, 27, 78, 0.6)';
  const activeLineColor = isSelected && text_color === 'light' ? '#fff' : '#0069ff';

  return (
    <BulmaButton
      id={id}
      className={text_color === 'light' ? 'white' : 'darkblue'}
      style={{ color: label_color || isSelected ? '' : 'rgba(3, 27, 78, 0.6)' }}
      onClick={onClick}
      css={styledTab}
    >
      {label}
      <svg css={styledLineContainer}>
        <line
          x1="1.5"
          x2="1.5"
          y1="2px"
          y2="48px"
          css={styledLine}
          className={isSelected ? 'selected' : ''}
          style={{ stroke: isSelected && activeLineColor }}
        />
      </svg>
    </BulmaButton>
  );
};

export const SlidingTabsContainer = props => {
  const { children, text_color, button_text, button_link, button_color } = props;
  const [selected, setSelected] = useState(0);
  const [isScrolling, setScrolling] = useState(false);
  const contents = useRef([]);
  const anchors = useRef([]);

  useEffect(() => {
    const scrollObserver = new IntersectionObserver(
      ([entries]) => {
        if (entries.isIntersecting && entries.intersectionRatio > 0.5 && !isScrolling) {
          const newSelected = Number(entries.target.getAttribute('data-tab-id'));
          setSelected(newSelected);
        }
      },
      { thresholdMargin: 60, threshold: [0.5] },
    );

    contents.current.forEach(el => {
      scrollObserver.observe(el);
    });
  });

  const scrollTo = index => {
    if (anchors.current[index]) {
      setScrolling(true);
      anchors.current[index].scrollIntoView({ behavior: 'smooth' });
      setSelected(index);
      window.setTimeout(() => {
        setScrolling(false);
      }, 500);
    }
  };

  return (
    <BulmaContainer>
      <BulmaColumns>
        <BulmaColumns.Column size={2} css={styledSlidingTabsContainer}>
          {React.Children.map(children || null, (child, i) => (
            <ControlledTab
              {...child.props}
              id={`testControlledTab-${i}`}
              text_color={text_color}
              key={createRandomId()}
              isSelected={selected === i}
              onClick={() => scrollTo(i)}
            />
          ))}
          {button_link && button_link.url ? (
            <Button
              css={styledButton}
              className={button_color === 'primary' ? 'white' : 'primary'}
              color={button_color === 'white' ? 'white' : 'primary'}
              outlined={!!button_color.includes('outline')}
              renderAs={LazyLink}
              url={button_link.url}
            >
              {button_text}
            </Button>
          ) : null}
        </BulmaColumns.Column>
        <BulmaColumns.Column css={styledContentWrapper}>
          <div id="testTabContent" css={styledTabContent}>
            {React.Children.map(children, (child, index) => {
              if (child === null) {
                return null;
              }
              const contentClass = css`
                ${styledContent}
                animation: none;
              `;
              return (
                <div
                  css={contentClass}
                  ref={el => {
                    contents.current[index] = el;
                  }}
                  data-tab-id={index}
                  key={createRandomId()}
                >
                  <div
                    ref={el => {
                      anchors.current[index] = el;
                    }}
                    css={tabScrollAnchor}
                  />
                  {React.Children.map(child.props.children, content => (
                    <>{content}</>
                  ))}
                </div>
              );
            })}
          </div>
        </BulmaColumns.Column>
      </BulmaColumns>
    </BulmaContainer>
  );
};

SlidingTabsContainer.propTypes = {
  children: PropTypes.oneOfType([PropTypes.arrayOf(PropTypes.node), PropTypes.node]).isRequired,
  text_color: PropTypes.string.isRequired,
  button_text: PropTypes.string.isRequired,
  button_link: PropTypes.object.isRequired,
  button_color: PropTypes.string.isRequired,
};
SlidingTab.propTypes = {
  label: PropTypes.string.isRequired,
  label_color: PropTypes.string,
};
ControlledTab.propTypes = {
  label: PropTypes.string.isRequired,
  label_color: PropTypes.string,
  id: PropTypes.string.isRequired,
  text_color: PropTypes.string.isRequired,
  isSelected: PropTypes.bool.isRequired,
  onClick: PropTypes.func.isRequired,
};
ControlledTab.defaultProps = {
  label_color: null,
};
