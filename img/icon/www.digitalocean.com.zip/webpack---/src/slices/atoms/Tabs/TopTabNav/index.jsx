/* eslint-disable camelcase */
import React, { useState, useEffect } from 'react';
import PropTypes from 'prop-types';
import Prism from 'prismjs';

import BulmaButton from 'react-bulma-components/lib/components/button';
import BulmaContainer from 'react-bulma-components/lib/components/container';
import BulmaColumns from 'react-bulma-components/lib/components/columns';

import { RichText } from 'prismic-reactjs';
import { css } from '@emotion/core';
import { linkResolver } from '../../../../util/linkResolver';
import { createRandomId } from '../../../../util/createRandomId';
import {
  styledTab,
  styledLineContainer,
  styledTabContainer,
  styledTabName,
  styledContent,
  styledColumns,
  StyledLineBackground,
  StyledLine,
} from './TopTabNavStyles';

import LazyImage from '../../LazyImage';

// This component exists solely to provide an interface
// to use in the <TabsContainer /> component, so that we can
// take these <Tab /> components and control them.
/* eslint-disable no-unused-vars */
export const Tab = ({ label, content }) => null;

const ControlledTab = ({ label, label_color, icon, id, text_color, isSelected, onClick }) => {
  const getButtonTextColor = (selected, textColor) => {
    if (!selected && textColor === 'light') return 'rgba(255,255,255,.5)';
    if (selected && textColor === 'light') return 'rgba(255,255,255,.1)';
    if (selected && textColor === 'dark') return '';
    return 'rgba(3, 27, 78, 0.6)';
  };

  const activeLabelColor = isSelected && text_color === 'light' ? '#fff' : '#031b4e';

  return (
    <>
      <BulmaButton
        id={id}
        className={text_color === 'light' ? 'white' : 'darkblue'}
        style={{
          color: label_color || getButtonTextColor(isSelected, text_color),
        }}
        onClick={onClick}
        css={styledTab}
      >
        <div css={styledTabName} style={{ color: isSelected ? activeLabelColor : '' }}>
          {icon && icon.url && <LazyImage id="testQuoteLogo" src={icon.url} />}
          {label}
        </div>
        <svg css={styledLineContainer}>
          <StyledLine
            x1="1.5"
            x2="1.5"
            y1="2px"
            y2="48px"
            selectedStrokeColor={text_color === 'light' ? 'rgba(255,255,255,1)' : '#0069ff'}
            strokeColor={text_color === 'light' ? '' : '#e5e8ed'}
            className={isSelected ? 'selected' : ''}
          />
        </svg>
      </BulmaButton>
    </>
  );
};

export const TopTabContainer = props => {
  const { children, text_color } = props;
  const [selected, setSelected] = useState(0);
  const selectedContent = children[selected].props.content;

  useEffect(() => {
    if (props.codeBlock) setTimeout(() => Prism.highlightAll(), 0);
  }, [selected]);

  return (
    <BulmaContainer data-testid="top_tab_container">
      <BulmaColumns css={styledColumns}>
        <BulmaColumns.Column css={styledTabContainer}>
          <StyledLineBackground
            backgroundColor={text_color === 'light' ? 'rgba(255,255,255,.5)' : '#e5e8ed'}
            className="styledLineBackground "
          />
          {React.Children.map(children || null, (child, i) => (
            <ControlledTab
              {...child.props}
              id={`testControlledTab-${i}`}
              text_color={text_color}
              key={`tab-${child.props.label}`}
              isSelected={selected === i}
              onClick={() => setSelected(i)}
            />
          ))}
        </BulmaColumns.Column>
        <BulmaColumns.Column>
          <BulmaColumns gapless id="testTabContent">
            {selectedContent.map(content => {
              if (content === null) {
                return null;
              }
              if (!Array.isArray(content)) {
                return (
                  <BulmaColumns.Column key={createRandomId()}>
                    <div css={styledContent}>{content}</div>
                  </BulmaColumns.Column>
                );
              }
              const contentColor = children[selected].props.content_color;
              const contentClass = css`
                ${styledContent}
                &.white {
                  color: #fff;
                  p {
                    color: #fff;
                  }
                }
                &.content-color {
                  color: ${contentColor};
                  p {
                    color: ${contentColor};
                  }
                }
              `;
              return (
                <BulmaColumns.Column size={selectedContent.length > 1 ? 'half' : null} key={createRandomId()}>
                  <div css={contentClass}>
                    <RichText render={content} linkResolver={linkResolver} />
                  </div>
                </BulmaColumns.Column>
              );
            })}
          </BulmaColumns>
        </BulmaColumns.Column>
      </BulmaColumns>
    </BulmaContainer>
  );
};

TopTabContainer.propTypes = {
  children: PropTypes.oneOfType([PropTypes.arrayOf(PropTypes.node), PropTypes.node]).isRequired,
  text_color: PropTypes.string,
  codeBlock: PropTypes.node,
};

TopTabContainer.defaultProps = {
  text_color: null,
  codeBlock: null,
};

Tab.propTypes = {
  label: PropTypes.string.isRequired,
  content: PropTypes.array.isRequired,
  label_color: PropTypes.string,
  content_color: PropTypes.string,
};

ControlledTab.propTypes = {
  label: PropTypes.string.isRequired,
  label_color: PropTypes.string,
  icon: PropTypes.object,
  id: PropTypes.string.isRequired,
  text_color: PropTypes.string,
  isSelected: PropTypes.bool.isRequired,
  onClick: PropTypes.func.isRequired,
};

ControlledTab.defaultProps = {
  label_color: null,
  icon: {},
  text_color: null,
};
