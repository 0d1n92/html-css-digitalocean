// Styles here will override Bulma styles
import { css, keyframes } from '@emotion/core';
import styled from '@emotion/styled';
import media, { setBreakPoints } from 'css-in-js-media';

setBreakPoints({ phone: 550, tablet: 768, desktop: 1216 });

const lineAnimation = keyframes`
  from {
    opacity: 0.0;
    stroke-dashoffset 50;
  }
  to {
    opacity: 1.0;
    stroke-dashoffset: 0;
  }
`;

const contentAnimation = keyframes`
  from {
    opacity: 0.0;
  }
  to {
    opacity: 1.0;
  }
`;

export const styledTabContainer = css`
  ${media('< tablet')} {
    overflow: hidden;
    overflow-x: scroll;
    white-space: nowrap;
    scrollbar-width: none;
    justify-content: center;
    display: flex;
  }
  ${media('< phone')} {
    justify-content: flex-start;
  }
`;

export const styledSlidingTabsContainer = css`
  position: sticky;
  top: 110px;
  display: block;
  height: 100%;
  ${media('< desktop')} {
    display: none;
  }
`;

export const styledContentWrapper = css`
  max-width: 968px;
  margin: 0 auto !important;
`;

export const styledContent = css`
  position: relative;
  animation: ${contentAnimation} 0.2s ease-in forwards;
  display: flex;
  flex-direction: column;

  h1,
  h2,
  h3,
  h5,
  h6 {
    font-family: 'Sailec-Bold', 'system-ui', '-apple-system', 'BlinkMacSystemFont', 'Segoe UI', 'Roboto',
      'Helvetica Neue', 'Helvetica', 'Arial', 'sans-serif';
    color: #031b4e;
    line-height: 120%;
    margin-top: 25px;
    margin-bottom: 10px;
    font-weight: normal;
  }

  h1 {
    font-size: 44px;
  }

  h2 {
    font-size: 36px;
  }

  h3 {
    font-size: 30px;
    letter-spacing: -0.5px;
  }

  h4 {
    font-size: 24px;
    letter-spacing: 0;
    font-family: 'Sailec-Light', 'system-ui', '-apple-system', 'BlinkMacSystemFont', 'Segoe UI', 'Roboto',
      'Helvetica Neue', 'Helvetica', 'Arial', 'sans-serif';
    font-weight: normal;
    line-height: 160%;
  }

  h5 {
    font-size: 18px;
    letter-spacing: 0;
  }
  a {
    color: #0069ff;
    text-decoration: underline;
    font-weight: bold;
  }
  a:hover {
    color: #1633ff !important;
  }
  .block-img {
    margin: 0;
    display: flex;
    justify-content: flex-start;
    align-items: flex-end;
    min-height: 48px;

    ${media('< tablet')} {
      justify-content: center;
    }
  }

  p {
    margin: 0 0 10px 0;
  }
`;

export const styledTab = css`
  font-family: 'Sailec-Medium', 'system-ui', '-apple-system', 'BlinkMacSystemFont', 'Segoe UI', 'Roboto',
    'Helvetica Neue', 'Helvetica', 'Arial', 'sans-serif';
  border: none;
  background: none;
  display: block;
  color: #031b4e;
  height: 100%;
  padding: 15px 20px;
  border-radius: 0px;
  white-space: inherit;
  height: auto;
  text-align: left;

  ${media('< tablet')} {
    display: inline-block;
  }

  &:focus {
    border: none;
    box-shadow: none !important;
  }
  &.white {
    color: #fff;
  }
`;

export const styledButton = css`
  margin-top: 32px;
`;

export const styledLineContainer = css`
  width: 2px;
  height: 100%;
  position: absolute;
  display: inline-block;
  background-color: #e5e8ed;
  border-radius: 8px;
  left: 0px;
  top: 0px;
  ${media('< tablet')} {
    width: 100%;
    height: 3px;
    top: 54px;
    left: 0px;
  }
`;

export const styledLine = css`
  stroke-linecap: round;
  stroke-width: 2;
  stroke-dasharray: 150%;
  &.selected {
    animation: ${lineAnimation} 0.6s forwards;
  }
  ${media('< tablet')} {
    stroke-dasharray: 100%;
    transform: rotate(-90deg) translate(-6px, 1px) scale(4);
  }
`;

export const tabScrollAnchor = css`
  position: absolute;
  top: -135px;
  display: block;
  width: 100%;
  height: 30px;
`;

export const styledTabContent = css`
  margin-left: 100px;

  ${media('< desktop')} {
    margin-left: 0;

    div:last-child div {
      margin-bottom: 0;
    }
  }
`;

export const StyledContentContainer = styled.div`
  display: grid;

  grid-gap: 30px;
  grid-template-columns: 1fr 1fr;

  ${media('< tablet')} {
    margin-top: 40px;
    grid-template-columns: 1fr;
    grid-gap: 40px;
    text-align: center;
  }
`;
