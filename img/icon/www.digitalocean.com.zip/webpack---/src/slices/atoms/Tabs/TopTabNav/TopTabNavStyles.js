// Styles here will override Bulma styles
import { css, keyframes } from '@emotion/core';
import media from 'css-in-js-media';
import styled from '@emotion/styled';

const lineAnimation = keyframes`
  from {
    opacity: 0.0;
    stroke-dashoffset 50;
  }
  to {
    opacity: 1.0;
    stroke-dashoffset: 0;
  }
`;

const contentAnimation = keyframes`
  from {
    opacity: 0.0;
  }
  to {
    opacity: 1.0;
  }
`;

export const styledTabContainer = css`
  display: flex;
  flex: 1 0 auto;
  margin-top: 12px !important;
  margin-left: auto;
  margin-right: auto;
  justify-content: center;
  width: 80%;

  ${media('< desktop')} {
    justify-content: flex-start;
    flex-wrap: nowrap;
    max-height: 74px;
    width: 93%;
    overflow: auto;
    scrollbar-width: none;
    &.column {
      flex-basis: auto;
    }

    ${media('< tablet')} {
      margin-top: 100px;
    }
`;

export const styledContent = css`
  margin: auto;
  width: 100%;
  animation: ${contentAnimation} 0.2s ease-in forwards;
`;

export const styledTab = css`
  font-family: 'Sailec-Medium', 'system-ui', '-apple-system', 'BlinkMacSystemFont', 'Segoe UI', 'Roboto',
    'Helvetica Neue', 'Helvetica', 'Arial', 'sans-serif';
  border: none;
  background: none;
  display: block;
  color: #031b4e;
  height: 50px;
  border-radius: 0px;
  margin: 0 20px;
  padding: 0;

  ${media('< desktop')} {
    padding-left: 20px;
    display: inline-block;
  }

  &:focus {
    border: none;
    box-shadow: none !important;
  }
  &.white {
    color: #fff;
  }
`;

export const StyledLineBackground = styled.div`
  width: 100%;
  max-width: 1168px;
  height: 3px;
  position: absolute;
  display: inline-block;
  background-color: ${props => props.backgroundColor};
  border-radius: 8px;
  top: 80px;

  ${media('< desktop')} {
    width: 97%;
  }

  ${media('< tablet')} {
    top: 68px;
  }
`;
// changed from original tabStyles
export const styledLineContainer = css`
  position: absolute;
  display: inline-block;
  border-radius: 8px;
  width: 100%;
  height: 3px;
  top: 56px;
  left: 0px;
  z-index: 4;
`;

export const styledLine = css`
  stroke: #e5e8ed;
  stroke-linecap: round;
  stroke-width: 3;
  transform: rotate(-90deg) translate(-6px, 1px) scale(4);
  z-index: 5;

  &.selected {
    stroke: #0069ff;
    animation: ${lineAnimation} 0.6s forwards;
  }

  ${media('< desktop')} {
    stroke-dasharray: 100%;
  }
`;

export const StyledLine = styled.line`
  stroke: ${props => props.strokeColor};
  stroke-linecap: round;
  stroke-width: 3;
  transform: rotate(-90deg) translate(-6px, 1px) scale(4);
  z-index: 5;

  &.selected {
    stroke: ${props => props.selectedStrokeColor};
    animation: ${lineAnimation} 0.6s forwards;
  }

  ${media('< desktop')} {
    stroke-dasharray: 100%;
  }
`;

export const styledColumns = css`
  flex-direction: column;
  .column {
    max-width: 100%;
  }
`;

export const styledTabName = css`
  display: flex;
  align-items: center;

  img {
    margin-right: 5px;
    margin-left: 0px;
    width: 24px !important;
    height: 24px !important;
  }
`;
