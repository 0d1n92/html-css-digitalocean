/* eslint-disable camelcase */
import React, { useState } from 'react';
import PropTypes from 'prop-types';

import BulmaButton from 'react-bulma-components/lib/components/button';
import BulmaContainer from 'react-bulma-components/lib/components/container';
import BulmaColumns from 'react-bulma-components/lib/components/columns';

import { RichText } from 'prismic-reactjs';
import { css } from '@emotion/core';
import { linkResolver } from '../../../../util/linkResolver';
import { createRandomId } from '../../../../util/createRandomId';
import {
  styledTab,
  styledLineContainer,
  styledLine,
  styledTabContainer,
  styledContent,
  StyledContentContainer,
} from '../TabsStyles';

// This component exists solely to provide an interface
// to use in the <TabsContainer /> component, so that we can
// take these <Tab /> components and control them.
/* eslint-disable no-unused-vars */
export const Tab = ({ label, content }) => null;

const ControlledTab = ({ label, label_color, id, text_color, isSelected, onClick }) => {
  const activeLabelColor = isSelected && text_color === 'light' ? '#fff' : 'rgba(3, 27, 78, 1)';
  const labelColor = !isSelected && text_color === 'light' ? 'rgba(225, 225, 225, 0.6)' : 'rgba(3, 27, 78, 0.6)';
  const activeLineColor = isSelected && text_color === 'light' ? '#fff' : '#0069ff';

  return (
    <BulmaButton
      id={id}
      className={text_color === 'light' ? 'white' : 'darkblue'}
      style={{
        color: label_color || isSelected ? activeLabelColor : labelColor,
      }}
      onClick={onClick}
      css={styledTab}
    >
      {label}
      <svg
        css={styledLineContainer}
        style={{ backgroundColor: text_color === 'light' ? 'rgba(225, 225, 225, 0.6)' : '#e5e8ed' }}
      >
        <line
          x1="1.5"
          x2="1.5"
          y1="2px"
          y2="4000px"
          css={styledLine}
          className={isSelected ? 'selected' : ''}
          style={{ stroke: isSelected && activeLineColor }}
        />
      </svg>
    </BulmaButton>
  );
};

export const TabsContainer = props => {
  const { children, text_color } = props;
  const [selected, setSelected] = useState(0);

  const selectedContent = children[selected].props.content;

  return (
    <BulmaContainer>
      <BulmaColumns>
        <BulmaColumns.Column size={3} css={styledTabContainer}>
          {React.Children.map(children || null, (child, i) => (
            <ControlledTab
              {...child.props}
              id={`testControlledTab-${i}`}
              text_color={text_color}
              key={`tab-${child.props.label}`}
              isSelected={selected === i}
              onClick={() => setSelected(i)}
            />
          ))}
        </BulmaColumns.Column>
        <BulmaColumns.Column>
          <StyledContentContainer className="tab-container">
            {selectedContent.map(content => {
              if (content === null) {
                return null;
              }
              if (!Array.isArray(content)) {
                return (
                  <BulmaColumns.Column key={createRandomId()}>
                    <div css={styledContent} style={{ color: text_color === 'light' ? '#fff' : '' }}>
                      {content}
                    </div>
                  </BulmaColumns.Column>
                );
              }
              const contentColor = children[selected].props.content_color;
              const contentClass = css`
                ${styledContent}
                &.white {
                  color: #fff;
                  p {
                    color: #fff;
                  }
                  h4 {
                    color: #fff;
                  }
                }
                &.content-color {
                  color: ${contentColor};
                  p {
                    color: ${contentColor};
                  }
                }
                &.darkgrey {
                  h4 {
                    color: #5b6987;
                  }
                }
              `;
              return (
                <div
                  css={contentClass}
                  className={text_color === 'light' ? 'white' : 'darkgrey'}
                  key={createRandomId()}
                >
                  <RichText render={content} linkResolver={linkResolver} />
                </div>
              );
            })}
          </StyledContentContainer>
        </BulmaColumns.Column>
      </BulmaColumns>
    </BulmaContainer>
  );
};

TabsContainer.propTypes = {
  children: PropTypes.oneOfType([PropTypes.arrayOf(PropTypes.node), PropTypes.node]).isRequired,
  text_color: PropTypes.string.isRequired,
};

Tab.propTypes = {
  label: PropTypes.string.isRequired,
  content: PropTypes.array.isRequired,
  label_color: PropTypes.string,
  content_color: PropTypes.string,
};

ControlledTab.propTypes = {
  label: PropTypes.string.isRequired,
  label_color: PropTypes.string,
  id: PropTypes.string.isRequired,
  text_color: PropTypes.string,
  isSelected: PropTypes.bool.isRequired,
  onClick: PropTypes.func.isRequired,
};

ControlledTab.defaultProps = {
  label_color: null,
  text_color: null,
};
