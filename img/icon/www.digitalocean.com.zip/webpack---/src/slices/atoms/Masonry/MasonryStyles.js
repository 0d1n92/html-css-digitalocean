import styled from '@emotion/styled';
import media from 'css-in-js-media';

export const MasonryDiv = styled.div`
  margin-top: 64px;
  display: grid;
  grid-auto-flow: column;
  grid-gap: ${props => props.gap || `1em`};
  column-gap: 30px;
  margin-right: auto;

  ${media('< tablet')} {
    display: flex;
    flex-direction: column;
  }
`;

export const Col = styled.div`
  ${media('> tablet')} {
    &:nth-child(odd) {
      .box {
        :nth-child(odd) {
          height: 378px !important;
          // align-self: flex-start;
          max-width: 268px !important;
        }

        :nth-child(even) {
          height: 422px !important;
          max-width: 268px !important;
          // align-self: flex-end;
        }
      }
    }

    &:nth-child(even) {
      .box {
        :nth-child(even) {
          height: 378px !important;
          max-width: 268px !important;
          // align-self: flex-start;
        }

        :nth-child(odd) {
          height: 422px !important;
          max-width: 268px !important;
          // align-self: flex-end;
        }
      }
    }

    display: grid;
    grid-gap: ${props => props.gap || `30px`};
  }
`;
