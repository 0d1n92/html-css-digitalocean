// Styles here will override Bulma styles
// Type styles are pulled from https://www.figma.com/file/agxGswaact804GZ0vsZEXn/Typography?node-id=1%3A2
import { css } from '@emotion/core';
import media from 'css-in-js-media';

export const styledHeading = css`
  margin: 0 auto;
  max-width: 870px;

  /* h1 */
  &.title {
    font-family: 'Sailec-Bold', 'system-ui', '-apple-system', 'BlinkMacSystemFont', 'Segoe UI', 'Roboto',
      'Helvetica Neue', 'Helvetica', 'Arial', 'sans-serif';
    font-size: 44px;
    font-weight: normal;
    letter-spacing: -1px;
    margin-bottom: 0;

    &.hero-title {
      font-size: 58px;
      line-height: 120%;
    }

    ${media('< tablet')} {
      &.hero-title {
        font-size: 31px !important;
      }
    }
  }

  &.h2 {
    font-size: 36px;
    line-height: 110%;
  }

  &.h3 {
    font-size: 30px;
    line-height: 120%;
    letter-spacing: -0.5px;
  }

  &.h4 {
    font-size: 24px;
    line-height: 120%;
    letter-spacing: 0;
  }

  &.h5 {
    font-size: 18px;
    line-height: 120%;
    letter-spacing: 0;
  }

  &.h6 {
    font-size: 14px;
    line-height: 120%;
    letter-spacing: 0;
    text-transform: uppercase;
  }

  /* Subtitle */
  &.subtitle {
    margin-top: 20px !important;
  }
  &.subtitle,
  &.subtitle p {
    max-width: 770px;
    margin-bottom: 0 !important;

    /* font sizes */
    &.large,
    &.large p {
      font-family: 'Sailec-Light';
      font-size: 24px;
      line-height: 150%;
    }

    &.medium,
    &.medium p {
      font-family: 'Sailec-Light';
      font-size: 20px;
      line-height: 150%;
    }

    &.small,
    &.small p {
      font-size: 18px;
      line-height: 160%;
    }

    &.tiny,
    &.tiny p {
      font-size: 12px;
      letter-spacing: 0.0625em;
      margin-top: 5px !important;
    }

    /* font weights */
    &.light,
    &.light p {
      font-family: 'Sailec-Light';
    }
    &.regular,
    &.regular p {
      font-family: 'Sailec-Regular';
    }
  }

  /* color */
  &.transparentWhite,
  &.transparentWhite p {
    color: hsla(0, 0%, 100%, 0.6);
  }
  &.white,
  &.white p {
    color: #fff;
  }
  &.grey,
  &.grey p {
    color: #e5e8ed;
  }
  &.darkgrey,
  &.darkgrey p {
    color: #5b6987;
  }
  &.darkblue,
  &.darkblue p {
    color: #031b4e;
  }

  &.lightblue,
  &.lightblue p {
    color: #0069ff;
  }

  /* RichText links */
  a {
    color: #0069ff;
    font-family: 'Sailec-Regular';

    :hover {
      color: #1633ff !important;
    }
  }
`;
