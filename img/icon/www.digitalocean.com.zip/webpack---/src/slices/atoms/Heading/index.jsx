import React from 'react';
import PropTypes from 'prop-types';

import { RichText } from 'prismic-reactjs';

import BulmaHeading from 'react-bulma-components/lib/components/heading';
import { styledHeading } from './HeadingStyles';

import { linkResolver } from '../../../util/linkResolver';

const Heading = props => {
  const { children } = props;
  if (children[0] && children[0].type) {
    return (
      <div {...props} css={styledHeading}>
        <RichText render={children} linkResolver={linkResolver} />
      </div>
    );
  }
  return (
    <BulmaHeading {...props} css={styledHeading}>
      {children}
    </BulmaHeading>
  );
};

export default Heading;

Heading.propTypes = {
  children: PropTypes.oneOfType([
    PropTypes.arrayOf(PropTypes.object),
    PropTypes.arrayOf(PropTypes.node),
    PropTypes.node,
  ]).isRequired,
};
