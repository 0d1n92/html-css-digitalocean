import styled from '@emotion/styled';
import media from 'css-in-js-media';

export const StyledCompanyDate = styled.div`
  display: flex;
  align-items: center;
  font-size: 11px;
  margin-top: 12px;
  margin-bottom: 15px;

  ${media('< desktop')} {
    justify-content: center;
  }
`;

export const StyledCompany = styled.span`
  margin-right: 4px;
  margin-bottom: 2px;
`;

export const StyledMiddleDot = styled.span`
  display: inline-flex;
  vertical-align: bottom;
  font-size: 15px;
  margin-right: 4px;
`;

export const StyledDate = styled.span`
  margin-bottom: 2px;
`;

export const StyledParagraph = styled.p`
  line-height: 150%;
  font-family: 'Sailec-Bold' !important;
  text-transform: uppercase;

  /* color */
  &.white {
    color: #fff;
  }

  &.darkgrey {
    color: #5b6987;
  }
`;
