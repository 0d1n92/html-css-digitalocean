import { StyledCompanyDate, StyledCompany, StyledDate, StyledMiddleDot, StyledParagraph } from './CompanyDateStyles';

export const renderCompanyDate = (companyName, unformattedDate, defaultTextColor) => {
  const getFormattedDate = dateStr => {
    const date = new Date(dateStr);
    const dateRemovedOffset = new Date(date.getTime() - date.getTimezoneOffset() * -60000);
    const dateArr = dateRemovedOffset.toString().split(' ');

    return `${dateArr[1]} ${dateArr[2]}, ${dateArr[3]}`;
  };

  return (
    <StyledCompanyDate className="company-date">
      <StyledParagraph className={defaultTextColor === 'light' ? 'white' : 'darkgrey'}>
        <StyledCompany data-testid="article_company_name">{companyName[0].text}</StyledCompany>
        <StyledMiddleDot>&#183;</StyledMiddleDot>
        <StyledDate data-testid="article_date">{getFormattedDate(unformattedDate)}</StyledDate>
      </StyledParagraph>
    </StyledCompanyDate>
  );
};
