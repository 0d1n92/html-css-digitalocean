import React from 'react';
import { Link } from 'gatsby';
import PropTypes from 'prop-types';

import { setLinkUrl } from '../../../util/setLinkUrl';

const LazyLink = props => {
  const { children, url } = props;
  const renderedLink = setLinkUrl(url);

  return renderedLink ? (
    <>
      {renderedLink.indexOf('/') === 0 ? (
        <Link to={renderedLink} {...props}>
          {children}
        </Link>
      ) : (
        <a href={renderedLink} {...props}>
          {children}
        </a>
      )}
    </>
  ) : (
    <>
      <div {...props}>{children}</div>
    </>
  );
};

export default LazyLink;

LazyLink.propTypes = {
  children: PropTypes.node.isRequired,
  url: PropTypes.node,
};

LazyLink.defaultProps = {
  url: null,
};
