import React, { useEffect, useState } from 'react';
import PropTypes from 'prop-types';
import { Helmet } from 'react-helmet';

// This atom uses the Algolia Universal Search widget found here https://github.internal.digitalocean.com/digitalocean/algolia-universal-search
// *note* through the options you must pass the algolia_app_id, algolia_public_key, an element_id to get the modal to work, and some values in the primary_list

// Example of options you can pass - check out repo above for more
// {
//   algolia_app_id: '6ZHEUVKJ88',
//   algolia_public_key: 'c5470567eae7fa1177d43222e18ba086',
//   search_on_slash: true,
//   empty_state_element: 'noResultsElement',
//   primary_list: ['quicknav', 'alldocs'],
//   element_id: 'searchelement',
// }

const Search = props => {
  const { options, children } = props;

  // function to create and inject scripts for our internal Algolia Universal Search widget
  const loadUniversalScript = (url, cb) => {
    if (typeof document !== 'undefined') {
      const script = document.createElement('script');
      script.type = 'text/javascript';
      script.id = 'algolia-universal-search-script';
      script.onload = () => {
        cb();
      };

      script.src = url;
      document.body.appendChild(script);
    }
  };

  useEffect(() => {
    // on render of page with this Search atom if there are options passed and there isn't already a loaded search inject the Search scripts
    if (
      typeof document !== 'undefined' &&
      options &&
      document.getElementsByClassName('algolia-universal-search').length < 1
    ) {
      loadUniversalScript('https://assets.digitalocean.com/labs/search.js.gz', () => {
        const script = document.createElement('script');
        script.async = false;
        script.id = 'algolia-universal-search-options';
        const scriptParamsContent = document.createTextNode(`new UniversalSearch(${options}).start()`);
        script.appendChild(scriptParamsContent);
        document.body.appendChild(script);
      });
    }
    return () => {
      // Remove all scripts from document on render of page w/o Search
      if (document.getElementsByClassName('algolia-universal-search').length > 0) {
        document.body.removeChild(document.querySelectorAll('.algolia-universal-search')[0]);
        document.body.removeChild(document.getElementById('algolia-universal-search-script'));
        document.body.removeChild(document.getElementById('algolia-universal-search-options'));
      }
    };
  }, []);

  return <>{children}</>;
};

export default Search;

Search.propTypes = {
  options: PropTypes.string.isRequired,
  children: PropTypes.oneOfType([
    PropTypes.arrayOf(PropTypes.object),
    PropTypes.arrayOf(PropTypes.node),
    PropTypes.node,
  ]).isRequired,
};
