/* eslint-disable camelcase */
import React from 'react';
import PropTypes from 'prop-types';
import { css } from '@emotion/core';

import openQuoteDark from '../../../assets/images/open-quote-dark.svg';
import openQuoteLight from '../../../assets/images/open-quote-light.svg';
import closeQuoteDark from '../../../assets/images/close-quote-dark.svg';
import closeQuoteLight from '../../../assets/images/close-quote-light.svg';

import {
  styledQuoteLogo,
  styledQuoteLogoContainer,
  styledQuoteAuthor,
  styledQuotePosition,
  styledQuoteContainer,
  styledQuoteAvatar,
  styledQuoteImage,
  styledQuote,
  styledTextLink,
} from './QuoteStyles';

// eslint-disable-next-line import/no-cycle
import { LazyImage, TextLink } from '..';

const Quote = ({ quoteProps }) => {
  const {
    company,
    author,
    align_content,
    author_details,
    logo,
    text_color,
    quote,
    quote_color,
    position,
    avatar,
    quote_size,
    link,
    link_text,
  } = quoteProps;

  const authorDetails =
    author_details && author_details[0] && author_details[0].text ? author_details[0].text : author_details;

  return (
    <>
      <div
        css={styledQuoteLogoContainer}
        style={
          align_content === 'center' ? { textAlign: 'center', justifyContent: 'center', alignItems: 'center' } : null
        }
      >
        {logo ? (
          <LazyImage
            id={logo.alt}
            src={logo.url}
            css={css`
                ${styledQuoteLogo}
                width: ${logo.dimensions.width}px;
              `}
            alt={logo.alt || 'company logo'}
          />
        ) : null}
      </div>
      <p
        className={text_color === 'light' ? 'white quote' : 'darkgrey quote'}
        css={
          quote_color
            ? css`
                ${styledQuote}
                color: ${quote_color} !important;
                font-size: ${quote_size === 'large' ? '24px' : '20px'};
            `
            : css`
              ${styledQuote}
              font-size: ${quote_size === 'large' ? '24px' : '20px'};
            `
        }
      >
        <LazyImage
          css={styledQuoteImage}
          src={text_color === 'light' ? openQuoteLight : openQuoteDark}
          alt="open quote"
        />
        {quote[0].text}
        <LazyImage
          css={styledQuoteImage}
          className="close-quote"
          src={text_color === 'light' ? closeQuoteLight : closeQuoteDark}
          alt="close quote"
        />
      </p>
      <div
        id={(author && author[0] && author[0].text) || 'author'}
        css={styledQuoteContainer}
        style={
          align_content === 'center' || !avatar
            ? { textAlign: 'left', justifyContent: 'center', alignItems: 'center' }
            : { textAlign: 'left' }
        }
      >
        {link && link.url && (
          <TextLink css={styledTextLink} className="regular" url={link && link.url}>
            {link_text}
          </TextLink>
        )}
        {avatar ? (
          <LazyImage
            src={avatar.url}
            css={styledQuoteAvatar}
            style={align_content === 'center' ? { marginBottom: '10px' } : null}
          />
        ) : null}
        <>
          {author && author[0] && author[0].text ? (
            <p
              className={text_color === 'light' ? 'white' : 'darkgrey'}
              css={
                quote_color
                  ? css`
                      ${styledQuoteAuthor}
                        color: ${quote_color} !important;
                      `
                  : styledQuoteAuthor
              }
            >
              {author[0].text}
            </p>
          ) : null}
          <p
            className={text_color === 'light' ? 'white' : 'darkgrey'}
            css={
              quote_color
                ? css`
                      ${styledQuotePosition}
                        color: ${quote_color} !important;
                      `
                : styledQuotePosition
            }
          >
            {!company || !position ? `${authorDetails}` : `${position[0].text}, ${company[0].text}`}
          </p>
        </>
      </div>
    </>
  );
};

export default Quote;

Quote.propTypes = {
  quoteProps: PropTypes.object.isRequired,
};
