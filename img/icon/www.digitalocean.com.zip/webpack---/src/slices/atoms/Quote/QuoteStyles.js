// Styles here will override Bulma styles
import { css } from '@emotion/core';

export const styledQuoteLogo = css`
  margin: 0;
  max-width: 200px;
`;

export const styledQuoteContainer = css`
  display: flex;
  flex-direction: column;
  img {
    border-radius: 50%;
  }
  p {
    &.white {
      color: #fff;
    }
    &.darkgrey {
      color: #5b6987;
    }
  }
`;

export const styledQuoteLogoContainer = css`
  display: flex;
  align-items: center;
`;

export const styledQuoteAvatar = css`
  padding: 0;
  margin: 0 12px 0px 0;
  width: 50px;
  img {
    border-radius: 500px;
  }
`;

export const styledQuoteAuthor = css`
  margin-top: 0px !important;
  margin-bottom: 0px;
`;

export const styledQuotePosition = css`
  margin-top: 4px !important;
  margin-bottom: 0px;
  font-size: 12px !important;
  font-family: 'Sailec-Light', 'Helvetica', sans-serif;
  &.darkgrey {
    color: #99a1b3;
  }
`;

export const styledQuote = css`
  line-height: 150%;
  font-family: 'Sailec-Light', 'Helvetica', sans-serif;
  margin-top: 30px;
  margin-bottom: 30px;
  &.white {
    color: #fff;
  }
  &.darkgrey {
    color: #5b6987;
  }
`;

export const styledQuoteImage = css`
  width: 20px;
  display: inline-block;
  margin: 0;
  margin-right: 8px;
  &.close-quote {
    width: 8px;
    margin-left: 8px;
  }
`;

export const styledTextLink = css`
  font-size: 16px;
  margin: -8px 0 20px 0;
`;
