import React from 'react';
import PropTypes from 'prop-types';

import { fadeIn } from './LazyImageStyles';

const LazyImage = props => {
  const { src, alt, className, width, height, maxWidth, maxHeight, size, key, style } = props;

  return (
    <img
      data-src={src}
      src={src}
      alt={alt}
      className={`${className} lazyload blur-up`}
      css={fadeIn}
      width={width}
      height={height}
      maxwidth={maxWidth}
      maxheight={maxHeight}
      size={size}
      key={key}
      style={style}
    />
  );
};

export default LazyImage;

LazyImage.propTypes = {
  src: PropTypes.string.isRequired,
  alt: PropTypes.string,
  className: PropTypes.string,
  width: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  height: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  maxWidth: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  maxHeight: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
  size: PropTypes.string,
  key: PropTypes.string,
  style: PropTypes.object,
};

LazyImage.defaultProps = {
  alt: 'image',
  className: null,
  width: null,
  height: null,
  maxWidth: null,
  maxHeight: null,
  size: null,
  key: null,
  style: null,
};
