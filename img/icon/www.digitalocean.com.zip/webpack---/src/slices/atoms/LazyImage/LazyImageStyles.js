// Styles here will override Bulma styles
import { css } from '@emotion/core';

export const fadeIn = css`
  &.blur-up {
    -webkit-filter: blur(5px);
    filter: blur(5px);
    transition: filter 100ms, -webkit-filter 100ms;
  }

  &.blur-up.lazyloaded {
    -webkit-filter: blur(0);
    filter: blur(0);
  }

  img {
    animation: fadeInAnimation 0.5s both;

    @keyframes fadeInAnimation {
      from {
        opacity: 0;
        -webkit-filter: blur(5px);
        filter: blur(5px);
        transition: filter 100ms, -webkit-filter 100ms;
      }
      to {
        opacity: 1;
        -webkit-filter: blur(0);
        filter: blur(0);
      }
    }
  }
`;
