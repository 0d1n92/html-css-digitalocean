// Styles here will override Bulma styles
import { css } from '@emotion/core';

export const styledButton = css`
  font-family: 'Sailec-Bold', 'Helvetica', 'san-serif';
  font-size: 1em;
  padding: 30px 30px 28px 30px;

  /* Blue button - primary blue is set in _variables stylesheet */
  &.is-primary {
    transition: all 0.3s ease;

    :hover {
      color: #fff !important;
      background-color: #1633ff !important;
      transition: all 0.3s ease;
    }

    &.is-outlined {
      border: 1px solid #0069ff;
      color: #0069ff;

      :hover {
        color: #0069ff !important;
        border-color: #0069ff;
        background-color: #f2f8ff !important;
      }
    }
  }
  /* White button */
  &.is-white {
    color: #0069ff !important;
    transition: all 0.3s ease;

    :hover {
      color: #0069ff;
      background: rgba(225, 225, 225, 0.9) !important;
      transition: all 0.3s ease;
    }

    /* White outlined button */
    &.is-outlined {
      color: #fff !important;

      :hover {
        color: #fff !important;
        border: 1px solid #fff;
      }
    }
  }

  /* general outlined button styles */
  &.is-outlined {
    background: transparent;
    transition: all 0.3s ease;

    :hover {
      background-color: rgba(255, 255, 255, 0.1) !important;
      transition: all 0.3s ease;
    }
  }
`;
