import React from 'react';
import PropTypes from 'prop-types';

import BulmaButton from 'react-bulma-components/lib/components/button';
import { styledButton } from './ButtonStyles';

const Button = props => {
  const { children } = props;

  return (
    <BulmaButton {...props} css={styledButton}>
      {children}
    </BulmaButton>
  );
};

export default Button;

Button.propTypes = {
  children: PropTypes.node.isRequired,
};
