import { css } from '@emotion/core';
import media from 'css-in-js-media';
import styled from '@emotion/styled';

export const styledCarouselContainer = css`
  width: 100%;
  height: auto;
  display: block;
  margin-top: 64px;
`;

export const styledCarouselWrapper = css`
  ${media('< tablet')} {
    margin: 0 auto !important;
  }
`;

export const StyledCarouselContentContainer = styled.div`
  width: 100%;
  overflow-x: hidden;

  ${media('> tablet')} {
    position: relative;
  }
`;

export const styledCarouselContent = css`
  height: 100%;
  display: inline-block;
`;

export const styledCarouselButtonContainer = css`
  display: flex;
  justify-content: flex-start;
  align-items: center;
  ${media('< desktop')} {
    display: none;
  }
  &.right {
    justify-content: flex-end;
  }
`;

export const styledCarouselButton = css`
  z-index: 19;
  transition: opacity 0.2s;
  &:hover {
    cursor: pointer;
  }
  .flipped {
    transform: rotateZ(180deg);
  }
  .last {
    opacity: 0.6;
  }
`;

export const styledCarouselSelectContainer = css`
  width: 100%;
  display: flex;
  justify-content: center;
  margin-top: 32px;
`;

export const styledCarouselDotContainer = css`
  display: flex;
  justify-content: center;
`;

export const styledCarouselSelectButton = css`
  border-radius: 100%;
  border: 2px solid white;
  width: 10px;
  height: 10px;
  font-size: 0;
  line-height: 0;
  display: block;
  padding: 3px;
  cursor: pointer;
  outline: 0;
  margin: 0 6px;
  background-color: transparent;
  &.selected {
    opacity: 1;
    background-color: white;
  }
`;

export const styledTestimonialQuote = css`
  /* styles for children that only apply to the CarouselTestimonial slice */
  min-height: auto;

  div {
    display: inline-flex;
  }

  .selected {
    background: #fff;
    display: inline-flex;
    justify-content: center;
    align-items: center;
    border: 1px solid #f3f5f9;
    box-sizing: border-box;
    box-shadow: 0px 2px 4px rgba(1, 14, 40, 0.05);
    border-radius: 6px;

    .container {
      max-width: 826px;
      justify-content: center;
      align-items: center;
    }
  }
`;

export const StyledCustomerStoryInfoContainer = styled.div`
  position: relative;
`;

export const StyledCustomerStoryInfo = styled.div`
  position: absolute;
  border-radius: 5px;
  width: 335px;
  height: 250px;
  background-color: white;
  right: 150px;
  bottom: 0;
  box-shadow: 0px 8px 16px rgba(1, 14, 40, 0.05);

  h5 {
    margin-left: 30px;
    margin-top: 30px;
    margin-bottom: 0px;
    font-size: 16px;
    color: #031b4e;
  }

  p {
    margin: 22px 30px 26px 30px;
    font-family: 'Sailec-Regular';
    color: #031b4e;
    overflow: scroll;
    max-height: 150px;
  }

  &.visible {
    visibility: visible;
    opacity: 1;
    transition: opacity 0.2s linear;
  }

  &.hidden {
    visibility: hidden;
    opacity: 0;
  }

  ${media('< desktop')} {
    display: flex;
    flex-direction: column;
    position: relative;
    margin: 32px auto;
    right: 0;

    width: 250px;
    height: 180px;
  }
`;

export const StyledCustomerStoryBubble = styled.div`
  position: absolute;
  display: flex;
  width: 50px;
  height: 50px;
  background: white;
  filter: drop-shadow(0px 4px 20px rgba(0, 0, 0, 0.25));
  right: -24px;
  top: -24px;
  border-radius: 50%;

  img {
    width: 38px;
    margin: auto;
  }
`;
