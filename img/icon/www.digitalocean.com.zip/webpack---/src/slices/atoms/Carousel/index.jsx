/* eslint-disable camelcase */
import React, { useState, useEffect, forwardRef, useImperativeHandle } from 'react';
import PropTypes from 'prop-types';
import BulmaContainer from 'react-bulma-components/lib/components/container';
import BulmaColumns from 'react-bulma-components/lib/components/columns';
import { css } from '@emotion/core';
import { motion, useAnimation } from 'framer-motion';
import {
  styledCarouselContent,
  StyledCarouselContentContainer,
  styledCarouselWrapper,
  styledCarouselButton,
  styledCarouselSelectContainer,
  styledCarouselSelectButton,
  styledCarouselButtonContainer,
  styledCarouselDotContainer,
  styledTestimonialQuote,
  styledCarouselContainer,
  StyledCustomerStoryInfo,
  StyledCustomerStoryBubble,
  StyledCustomerStoryInfoContainer,
} from './CarouselStyles';

import rightArrowWhite from '../../../assets/images/arrow-right-white.svg';
import rightArrowBlack from '../../../assets/images/arrow-right-black.svg';
import leftArrowGrey from '../../../assets/images/arrow-left-grey.svg';
import leftArrowLightGrey from '../../../assets/images/arrow-left-lightgrey.svg';
// eslint-disable-next-line import/no-cycle
import { TextLink, LazyImage } from '..';

const clamp = (number, min, max) => Math.max(min, Math.min(number, max));

const Carousel = forwardRef((props, ref) => {
  const [containerWidth, setContainerWidth] = React.useState(0);
  const [selected, setSelected] = React.useState(0);

  const {
    children,
    id,
    text_color,
    fadeIn,
    selectColor,
    type,
    setCurrentCarouselIndex,
    maxWidth,
    fields,
    hideArrows,
    customerStory,
    externalSetSelected,
  } = props;

  const [isBeingDragged, setIsBeingDragged] = useState(false);
  const containerRef = React.useRef();

  const getContainerWidth = () => {
    if (containerRef.current) {
      setContainerWidth(containerRef.current.getBoundingClientRect().width);
    }
  };

  useEffect(() => {
    window.addEventListener('resize', getContainerWidth);

    getContainerWidth();
  });

  useEffect(() => {
    if (setCurrentCarouselIndex) setCurrentCarouselIndex(selected);
  }, [selected]);

  const changeSelected = value => {
    setSelected(clamp(value, 0, children.length - 1));
  };

  useImperativeHandle(ref, () => ({
    changeSelected,
    selected,
  }));

  const previousArrow = text_color === 'light' ? rightArrowWhite : rightArrowBlack;
  const nextArrow = text_color === 'light' ? rightArrowWhite : rightArrowBlack;

  const disabledArrow = text_color === 'light' ? leftArrowLightGrey : leftArrowGrey;

  return (
    <BulmaContainer css={styledCarouselContainer} style={{ maxWidth: maxWidth && maxWidth }} id={id}>
      <BulmaColumns gapless>
        {!hideArrows && (
          <BulmaColumns.Column size={1} css={styledCarouselButtonContainer}>
            <TextLink
              onClick={() => {
                changeSelected(selected - 1);
              }}
              css={styledCarouselButton}
            >
              <LazyImage
                alt="Previous"
                className={selected > 0 ? 'flipped' : ''}
                src={selected > 0 ? previousArrow : disabledArrow}
              />
            </TextLink>
          </BulmaColumns.Column>
        )}
        <BulmaColumns.Column
          mobile={{ size: 12 }}
          tablet={{ size: 12 }}
          desktop={{ size: 10 }}
          css={styledCarouselWrapper}
        >
          <StyledCarouselContentContainer ref={containerRef}>
            <div
              style={{ width: containerWidth * children.length }}
              css={type === 'testimonial' ? styledTestimonialQuote : null}
            >
              <CarouselScrollContainer
                setIsBeingDragged={setIsBeingDragged}
                setSelected={changeSelected}
                externalSetSelected={externalSetSelected}
                currentSelected={selected}
                width={containerWidth}
              >
                {React.Children.map(children || null, (child, i) => (
                  <CarouselContent
                    hideArrows={hideArrows}
                    fadeIn={fadeIn}
                    selected={selected === i}
                    width={containerWidth}
                  >
                    {child}
                  </CarouselContent>
                ))}
              </CarouselScrollContainer>
            </div>
          </StyledCarouselContentContainer>
        </BulmaColumns.Column>
        {!hideArrows && (
          <BulmaColumns.Column size={1} css={styledCarouselButtonContainer} className="right">
            <TextLink
              onClick={() => {
                changeSelected(selected + 1);
                if (externalSetSelected) externalSetSelected(selected + 1);
              }}
              css={styledCarouselButton}
            >
              <LazyImage
                alt="Next"
                className={selected === children.length - 1 ? 'flipped' : ''}
                src={selected !== children.length - 1 ? nextArrow : disabledArrow}
              />
            </TextLink>
          </BulmaColumns.Column>
        )}
      </BulmaColumns>
      <div css={styledCarouselSelectContainer} className="carousel-select-container">
        <div css={styledCarouselDotContainer}>
          {React.Children.map(children || null, (child, i) => (
            <button
              type="button"
              aria-label={`slide ${i + 1} selection dot`}
              onMouseUp={() => setIsBeingDragged(false)}
              onMouseDown={() => setIsBeingDragged(true)}
              css={css`
              ${styledCarouselSelectButton} 
              border: 2px solid ${selectColor}; 
              &.selected {
                background-color: ${selectColor};
              }
            `}
              className={i === selected ? 'selected' : ''}
              onClick={() => {
                setSelected(i);
                if (externalSetSelected) externalSetSelected(i);
              }}
            />
          ))}
        </div>
        {customerStory && (
          <StyledCustomerStoryInfoContainer>
            <StyledCustomerStoryInfo className={isBeingDragged ? 'hidden' : 'visible'}>
              <h5>
                {fields[selected].customer_story_name[0] && fields[selected].customer_story_name[0].text} from{' '}
                {fields[selected].customer_story_company[0] && fields[selected].customer_story_company[0].text}
              </h5>
              <p>{fields[selected].customer_story_text[0] && fields[selected].customer_story_text[0].text}</p>
              <StyledCustomerStoryBubble>
                <img
                  alt="customer-story-icon"
                  src={fields[selected].customer_story_icon && fields[selected].customer_story_icon.url}
                />
              </StyledCustomerStoryBubble>
            </StyledCustomerStoryInfo>
          </StyledCustomerStoryInfoContainer>
        )}
      </div>
    </BulmaContainer>
  );
});

const CarouselScrollContainer = props => {
  const { children, setSelected, currentSelected, width, setIsBeingDragged, externalSetSelected } = props;
  const controls = useAnimation();
  const position = -(currentSelected * width);
  const [dragged, setDragged] = useState(false);
  controls.start({ x: position });
  return (
    <motion.div
      className="draggable"
      drag="x"
      onDrag={(event, info) => {
        if (!dragged) {
          if (info.offset.x < -(width / 2)) {
            setSelected(currentSelected + 1);
            if (externalSetSelected) externalSetSelected(currentSelected + 1);
            controls.stop();

            setDragged(true);
          } else if (info.offset.x > width / 2) {
            setSelected(currentSelected - 1);
            if (externalSetSelected) externalSetSelected(currentSelected - 1);
            controls.stop();

            setDragged(true);
          }
        }
      }}
      onDragStart={() => {
        setIsBeingDragged(true);
      }}
      onDragEnd={() => {
        controls.start({ x: position });
        setDragged(false);
        setIsBeingDragged(false);
      }}
      animate={controls}
      transition={{ duration: 0.3 }}
    >
      {children}
    </motion.div>
  );
};

const CarouselContent = props => {
  const { children, width, selected, fadeIn } = props;
  return (
    <div
      css={css`
        ${styledCarouselContent}
        ${fadeIn
          ? `transition: opacity 2s;
            opacity: 0;
            &.selected {
              opacity: 1;
            }`
          : ''}
      `}
      className={selected ? 'selected' : ''}
      style={{ width }}
    >
      {children}
    </div>
  );
};

export default Carousel;

Carousel.propTypes = {
  text_color: PropTypes.string,
  id: PropTypes.string,
  children: PropTypes.oneOfType([PropTypes.arrayOf(PropTypes.node), PropTypes.node]).isRequired,
  fadeIn: PropTypes.bool,
  type: PropTypes.string,
  selectColor: PropTypes.string,
  setCurrentCarouselIndex: PropTypes.func,
  fields: PropTypes.array,
  maxWidth: PropTypes.string,
  hideArrows: PropTypes.bool,
  customerStory: PropTypes.bool,
  externalSetSelected: PropTypes.func,
};
Carousel.defaultProps = {
  fadeIn: false,
  id: 'carousel',
  type: null,
  text_color: null,
  maxWidth: null,
  selectColor: null,
  setCurrentCarouselIndex: null,
  hideArrows: null,
  customerStory: null,
  externalSetSelected: null,
  fields: null,
  maxWidth: null,
};
CarouselScrollContainer.propTypes = {
  children: PropTypes.oneOfType([PropTypes.arrayOf(PropTypes.node), PropTypes.node]).isRequired,
  setSelected: PropTypes.func.isRequired,
  currentSelected: PropTypes.number.isRequired,
  width: PropTypes.number.isRequired,
  externalSetSelected: PropTypes.func,
  setIsBeingDragged: PropTypes.func,
};
CarouselScrollContainer.defaultProps = {
  externalSetSelected: null,
  setIsBeingDragged: null,
};
CarouselContent.propTypes = {
  children: PropTypes.oneOfType([PropTypes.arrayOf(PropTypes.node), PropTypes.node]).isRequired,
  width: PropTypes.number.isRequired,
  selected: PropTypes.bool.isRequired,
  fadeIn: PropTypes.bool.isRequired,
};
