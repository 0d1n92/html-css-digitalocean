/* eslint-disable camelcase */
import React from 'react';
import { Helmet } from 'react-helmet';
import PropTypes from 'prop-types';
import { StyledVideoModalClose } from './WistiaVideoStyles';
import modalVideoClose from '../../../assets/images/modal-close-video.svg';

const WistiaVideo = ({ wistiaId, autoplay, onModalVideoClose }) => (
  <>
    <Helmet>
      <script src={`https://fast.wistia.com/embed/medias/${wistiaId}.jsonp`} async />
      <script src="https://fast.wistia.com/assets/external/E-v1.js" async />
    </Helmet>
    <div
      id="testVideoQuoteVideo"
      className="wistia_responsive_padding"
      css={{ padding: '56.25% 0 0 0', position: 'relative' }}
    >
      {onModalVideoClose && (
        <StyledVideoModalClose onClick={onModalVideoClose && onModalVideoClose}>
          <img alt="close-svg" src={modalVideoClose} />
        </StyledVideoModalClose>
      )}
      <div
        className="wistia_responsive_wrapper"
        css={{
          height: '100%',
          left: '0',
          position: 'absolute',
          top: '0',
          width: '100%',
        }}
      >
        <div
          className={`wistia_embed wistia_async_${wistiaId} videoFoam=true autoPlay=${autoplay}`}
          css={{ height: '100%', position: 'relative', width: '100%' }}
        >
          <div
            className="wistia_swatch"
            css={{
              height: '100%',
              left: '0',
              opacity: '0',
              overflow: 'hidden',
              position: 'absolute',
              top: '0',
              transition: 'opacity 200ms',
              width: '100%',
            }}
          >
            <img
              src={`https://fast.wistia.com/embed/medias/${wistiaId}/swatch`}
              css={{
                filter: 'blur(5px)',
                height: '100%',
                objectFit: 'contain',
                width: '100%',
              }}
              alt="video"
              aria-hidden="true"
            />
          </div>
        </div>
      </div>
    </div>
  </>
);

export default WistiaVideo;

WistiaVideo.propTypes = {
  wistiaId: PropTypes.string.isRequired,
  autoplay: PropTypes.bool,
  onModalVideoClose: PropTypes.func,
};

WistiaVideo.defaultProps = {
  autoplay: false,
  onModalClose: null,
};
