import styled from '@emotion/styled';

export const StyledVideoModalClose = styled.div`
  position: absolute;
  width: 48px;
  height: 48px;
  top: 176px;
  z-index: 1000;
  top: 16px;
  right: 16px;
  background: #010e28;
  opacity: 0.48;
  border-radius: 4px;
  display: flex;
  cursor: pointer;

  img {
    margin: auto;
  }
`;
