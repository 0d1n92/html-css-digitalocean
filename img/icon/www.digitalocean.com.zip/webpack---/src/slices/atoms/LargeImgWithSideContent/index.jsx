import React from 'react';
import PropTypes from 'prop-types';

import BulmaColumns from 'react-bulma-components/lib/components/columns';

import {
  styledContentColumn,
  styledColumnImage,
  styledLink,
  styledHeading,
  styledColumns,
} from './LargeImgWithSideContentStyles.js';
import { createRandomId } from '../../../util/createRandomId';

// eslint-disable-next-line import/no-cycle
import { Heading, TextLink, LazyImage } from '..';

const renderHeading = (text, atts, headingCss) => (
  <Heading {...atts} css={headingCss}>
    {text}
  </Heading>
);

const LargeImgWithSideContent = ({
  title,
  titleColor,
  image,
  text,
  defaultTextColor,
  contentTextColor,
  linkText,
  linkURL,
  linkColor,
  imagePosition,
}) => {
  const imagePos = imagePosition === 'left' ? 'row' : 'row-reverse';

  return (
    <BulmaColumns css={styledColumns} style={{ flexDirection: imagePosition ? imagePos : null }} key={createRandomId()}>
      <BulmaColumns.Column css={styledColumnImage}>
        <LazyImage data-testid="large_img_side_content_img" src={image && image.url} />
      </BulmaColumns.Column>
      <BulmaColumns.Column css={styledContentColumn}>
        {title &&
          title[0].text &&
          renderHeading(
            title[0].text,
            {
              className: `${defaultTextColor === 'light' ? 'h3 white' : 'h3 darkblue'}`,
              renderAs: 'h3',
              style: { color: titleColor, marginTop: '0px' },
              'data-testid': 'large_img_side_content_title',
            },
            styledHeading,
          )}

        {text &&
          text[0] &&
          renderHeading(text, {
            className: defaultTextColor === 'light' ? 'medium white subtitle' : 'medium darkgrey subtitle',
            style: { color: contentTextColor || null },
          })}
        {linkText ? (
          <TextLink
            data-testid="large_img_side_content_text_link"
            css={styledLink}
            url={linkURL && linkURL.url}
            style={{ color: linkColor }}
            className="arrow"
          >
            {linkText && linkText[0].text}
          </TextLink>
        ) : null}
      </BulmaColumns.Column>
    </BulmaColumns>
  );
};

export default LargeImgWithSideContent;

LargeImgWithSideContent.propTypes = {
  title: PropTypes.array,
  titleColor: PropTypes.string,
  image: PropTypes.object.isRequired,
  text: PropTypes.array.isRequired,
  defaultTextColor: PropTypes.string,
  contentTextColor: PropTypes.string,
  linkText: PropTypes.oneOfType([PropTypes.string, PropTypes.array]),
  linkURL: PropTypes.object,
  linkColor: PropTypes.string,
  imagePosition: PropTypes.string,
};

LargeImgWithSideContent.defaultProps = {
  title: null,
  titleColor: null,
  defaultTextColor: null,
  contentTextColor: null,
  linkText: null,
  linkURL: null,
  linkColor: null,
  imagePosition: null,
};
