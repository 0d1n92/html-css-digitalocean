import { css } from '@emotion/core';
import media from 'css-in-js-media';

export const styledColumns = css`
  display: flex;
  justify-content: center;
  align-items: center;

  &.is-multiline:nth-of-type(2n-2) {
    flex-direction: row-reverse;
    div:nth-of-type(2n-2) {
      margin-right: 64px;
    }
    ${media('< desktop')} {
      flex-direction: column !important;
      div:nth-of-type(2n-2) {
        margin-right: 0;
      }
    }
  }

  ${media('< desktop')} {
    flex-direction: column !important;
    .column {
      flex-basis: auto;
    }
  }
`;

export const styledSubheading = css`
  text-align: center;
  margin: 10px auto 0 auto !important;
`;

export const styledContainerHeading = css`
  text-align: center;
  margin-top: 32px !important;
`;

export const styledHeading = css`
  margin: 64px 0 0 0;
  line-height: 1.2;
  ul {
    font-size: 18px;
    margin-top: 10px;
    margin-left: 32px;
  }
  ${media('< desktop')} {
    text-align: center;
    width: 100%;
    margin: 20px auto 0 auto;
  }
`;

export const styledLink = css`
  margin-top: 20px !important;
  display: block;
  ${media('< tablet')} {
    display: block;
    text-align: center;
    width: 80%;
    margin: 20px auto 0 auto;
  }
`;

export const styledColumnImage = css`
  img {
    margin: 32px auto;
    max-width: 570px;
  }

  ${media('< desktop')} {
    max-width: 320px !important;
    img {
      margin: 18px 0;
      max-width: 320px !important;
    }
  }

  figure {
    margin: auto;
    img {
      margin: 32px auto;
      max-width: 570px;
    }
    ${media('< desktop')} {
      max-width: 320px !important;
      img {
        margin: 18px 0;
        max-width: 320px !important;
      }
    }
  }
`;

export const styledContentColumn = css`
  display: flex;
  flex-direction: column;
  justify-content: center;

  div.subtitle {
    margin-top: 16px !important;
  }

  p {
    margin-top: 0 !important;
  }

  ${media('< desktop')} {
    text-align: center;
    margin: auto;
  }
`;
