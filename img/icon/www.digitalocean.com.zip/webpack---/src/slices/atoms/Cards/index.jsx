/* eslint-disable camelcase */
/* eslint-disable import/no-cycle */
import React from 'react';
import PropTypes from 'prop-types';
import { RichText } from 'prismic-reactjs';
import CardThumbnailPlay from '../../../assets/images/card-thumbnail-play.svg';

import BulmaBox from 'react-bulma-components/lib/components/box';

import { linkResolver } from '../../../util/linkResolver';

import { createRandomId } from '../../../util/createRandomId';
import Heading from '../Heading/index.jsx';

import { LazyLink, LazyImage } from '..';

import {
  styledCardBox,
  styledCardBoxLink,
  styledCardContent,
  styledCardImageOnly,
  styledThumbnailPlay,
  StyledCardText,
} from './CardsStyles';

const renderCardText = (text, text_color) =>
  text_color ? (
    <StyledCardText>
      <RichText render={text} linkResolver={linkResolver} />
    </StyledCardText>
  ) : (
    <RichText render={text} linkResolver={linkResolver} />
  );

const Card = ({ image, title, title_color, text, text_color, link, modal, thumbnail_play }) => (
  <BulmaBox
    data-testid="card"
    css={(link && link.url) || modal ? styledCardBoxLink : styledCardBox}
    key={createRandomId()}
    renderAs={LazyLink}
    url={link && link.url ? link.url : null}
  >
    <div css={image && !title && !text ? styledCardImageOnly : styledCardContent}>
      {image && image.url ? (
        <div style={{ position: 'relative' }}>
          <LazyImage src={image.url} alt={image.alt || 'card icon'} />
          {thumbnail_play && <img css={styledThumbnailPlay} src={CardThumbnailPlay} />}
        </div>
      ) : null}

      {title && title[0] && title[0].text ? (
        <Heading style={title_color ? { color: title_color } : null} className="h5 darkblue" renderAs="h5">
          {title[0].text}
        </Heading>
      ) : null}
      {text && text[0] ? renderCardText(text, text_color) : null}
    </div>
  </BulmaBox>
);
export default Card;

Card.propTypes = {
  image: PropTypes.object,
  title: PropTypes.array,
  title_color: PropTypes.string,
  text: PropTypes.array,
  text_color: PropTypes.string,
  link: PropTypes.object,
  modal: PropTypes.bool,
};

Card.defaultProps = {
  image: {},
  title: {},
  title_color: null,
  text: null,
  text_color: null,
  link: null,
  modal: false,
};
