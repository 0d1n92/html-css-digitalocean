// Styles here will override Bulma styles
import styled from '@emotion/styled';
import { css } from '@emotion/core';
import media from 'css-in-js-media';

export const styledCardsSection = css`
  background-repeat: repeat;
`;

export const styledCardsContainer = css`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;

  ${media('< desktop')} {
    h2,
    p {
      margin-left: 20px;
      margin-right: 20px;
      text-align: center;
    }
  }
`;

export const styledHeading = css`
  margin: 60px auto 0 auto;
  text-align: center;
`;

export const styledSubtitle = css`
  margin: 20px auto 80px auto !important;
  max-width: 670px;
  text-align: center;
`;

export const styledCards = css`
  display: grid;
  grid-auto-flow: dense;
  grid-auto-rows: 1fr;
  grid-gap: 32px;
  max-width: 1168px;

  ${media('< desktop')} {
    display: flex;
    flex-direction: column;
    margin-left: 0px;
    margin-right: 0px;
  }
`;

export const styledCardBox = css`
  background: #fff;
  border: 1px solid #e5e8ed;
  border-radius: 5px;
  padding: 24px;
  margin-bottom: 0 !important;
  box-shadow: none;

  ${media('< desktop')} {
    margin-top: 32px;
  }
`;

export const styledCardBoxLink = css`
  background: #fff;
  border: 1px solid #e5e8ed;
  border-radius: 5px;
  padding: 24px;
  margin-bottom: 0 !important;
  cursor: pointer;
  box-shadow: 0 2px 4px rgba(3, 27, 78, 0.06) !important;
  transition: all 0.5s ease;

  :hover {
    box-shadow: 0 10px 20px rgba(3, 27, 78, 0.1) !important;
    transform: scale(1.01);
    background-color: #fff !important;
  }

  ${media('< desktop')} {
    margin-top: 32px;
  }
`;

export const styledCardContent = css`
  position: relative;
  height: 100%;

  .title {
    margin-top: 15px;
  }

  img {
    max-width: 100%;
    margin-bottom: 10px;
  }

  a {
    color: #0069ff;
    font-family: 'Sailec-Bold', 'Helvetica', 'sans-serif';
    font-style: normal;
  }

  ${media('<= desktop')} {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
  }
`;

export const styledCardImageOnly = css`
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 32px 0;
`;

export const styledButton = css`
  margin-top: 60px;
  margin-bottom: 40px;
`;

export const StyledCardText = styled.div`
  p {
    color: ${props => props.color};
  }
`;

export const styledThumbnailPlay = css`
  right: 0;
  position: absolute;
`;
