import React from 'react';
import PropTypes from 'prop-types';
import { GoogleMap, LoadScript, Marker } from '@react-google-maps/api';

const Map = props => {
  const { isMarkerShown, lat, lng, googleAPIKey } = props;

  return (
    <LoadScript id="script-loader" googleMapsApiKey={googleAPIKey}>
      <GoogleMap
        id="example-map"
        zoom={11}
        center={{ lat, lng }}
        mapContainerStyle={{
          minHeight: '444px',
          borderBottomLeftRadius: '5px',
          borderBottomRightRadius: '5px',
        }}
      >
        {isMarkerShown && <Marker position={{ lat, lng }} />}
      </GoogleMap>
    </LoadScript>
  );
};

export default Map;

Map.propTypes = {
  isMarkerShown: PropTypes.bool.isRequired,
  lat: PropTypes.node.isRequired,
  lng: PropTypes.node.isRequired,
  googleAPIKey: PropTypes.string.isRequired,
};
