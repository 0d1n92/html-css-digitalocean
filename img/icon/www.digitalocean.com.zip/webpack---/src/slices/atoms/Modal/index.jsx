import React from 'react';
import PropTypes from 'prop-types';

import { StyledModalBackground, StyledModalWrapper } from './ModalStyles';

const Modal = props => {
  const { show, onClose, children } = props;

  return (
    <>
      <StyledModalBackground
        style={show ? { display: 'flex' } : { display: 'none' }}
        onClick={() => onClose()}
        onKeyDown={() => onClose()}
      />
      <StyledModalWrapper {...props} style={show ? { display: 'flex' } : { display: 'none' }}>
        {children}
      </StyledModalWrapper>
    </>
  );
};

export default Modal;

Modal.propTypes = {
  onClose: PropTypes.func.isRequired,
  show: PropTypes.bool.isRequired,
  children: PropTypes.oneOfType([PropTypes.object, PropTypes.array]).isRequired,
};
