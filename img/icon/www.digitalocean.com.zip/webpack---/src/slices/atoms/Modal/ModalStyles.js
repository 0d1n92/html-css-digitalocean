// Styles here will override Bulma styles
import styled from '@emotion/styled';

export const StyledModalBackground = styled.div`
  display: none;
  background: rgba(229, 232, 237, 0.9);
  width: 100vw;
  height: 100vh;
  position: fixed;
  z-index: 50;
  top: 0;
  left: 0;
`;

export const StyledModalWrapper = styled.div`
  z-index: 100;
  display: none;
  position: absolute;
  padding: 20px;
  align-items: flex-start;
  text-align: left;
  top: 0;
  margin-left: auto;
  margin-right: auto;
  left: 0;
  right: 0;
`;
