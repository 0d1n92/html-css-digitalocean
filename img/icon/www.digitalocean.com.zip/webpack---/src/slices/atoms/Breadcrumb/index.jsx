import React from 'react';
import PropTypes from 'prop-types';

import { createRandomId } from '../../../util/createRandomId';
import { StyledBreadcrumbNav } from './BreadcrumbStyles';

import LazyLink from '../LazyLink';

const renderBreadcrumb = breadcrumb => (
  <li key={createRandomId()}>
    <LazyLink
      className={breadcrumb.breadcrumb_active ? 'active' : null}
      url={breadcrumb && breadcrumb.breadcrumb_link && breadcrumb.breadcrumb_link.url}
    >
      {breadcrumb && breadcrumb.breadcrumb_text && breadcrumb.breadcrumb_text[0].text}
    </LazyLink>
  </li>
);

const BreadcrumbNav = props => {
  const { breadcrumbs } = props;

  return (
    <StyledBreadcrumbNav {...props}>{breadcrumbs.map(breadcrumb => renderBreadcrumb(breadcrumb))}</StyledBreadcrumbNav>
  );
};

export default BreadcrumbNav;

BreadcrumbNav.propTypes = {
  breadcrumbs: PropTypes.array.isRequired,
};
