import styled from '@emotion/styled';

export const StyledBreadcrumbNav = styled.ul`
  display: flex;
  margin-bottom: 16px;

  /* Display list items side by side */
  li {
    list-style: none;
    font-size: 16px;
  }

  /* Add a slash symbol (/) before/behind each list item */
  li + li:before {
    color: #5b6987;
    padding: 8px;
    content: '›';
  }

  /* Add a color to all links inside the list */
  li a,
  li div {
    font-family: 'Sailec-Regular';
    color: #0069ff;
    text-underline-position: below;
    text-decoration: underline;
    text-decoration-skip-ink: auto;
    display: inline-block;
  }

  /* Add a color on mouse-over */
  li a:hover {
    color: #005fe6;
  }

  .active {
    text-decoration: none;
    color: #5b6987;
  }
`;
