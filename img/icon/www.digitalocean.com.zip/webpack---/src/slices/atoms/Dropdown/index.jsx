import { useRef, useState } from 'react';
import PropTypes from 'prop-types';

import { DropdownContainer, styledDropdown } from './DropdownStyles.js';
import Dropdown from '../../../assets/images/dropdown.svg';

const DropdownMenu = ({ dropdownItems, onPressFilter }) => {
  const dropdownRef = useRef(null);
  const [isActive, setIsActive] = useState(false);
  const [selectedDropdownItem, setSelectedDropdownItem] = useState('All');
  const [selectedDropdownItemIndex, setSelectedDropdownItemIndex] = useState(null);
  const onClick = () => setIsActive(!isActive);

  return (
    <DropdownContainer>
      <div className="menu-container">
        <div>
          <button type="button" onClick={onClick} className="menu-trigger">
            <p>{selectedDropdownItem}</p>
          </button>
          <button type="button" css={styledDropdown} onClick={onClick}>
            <img alt="dropdown" src={Dropdown} />
          </button>
        </div>

        <nav ref={dropdownRef} className={`menu ${isActive ? 'active' : 'inactive'}`}>
          <ul>
            <li>
              <button
                type="button"
                className={selectedDropdownItem === 'All' ? 'selected' : null}
                onClick={() => {
                  onPressFilter('all');
                  setSelectedDropdownItem('All');
                  setIsActive(false);
                  setSelectedDropdownItemIndex(null);
                }}
                onKeyPress={() => {
                  onPressFilter('all');
                  setSelectedDropdownItem('All');
                  setIsActive(false);
                }}
              >
                <p>All</p>
              </button>
            </li>
            {dropdownItems.map((item, index) => (
              <li>
                <button
                  type="button"
                  className={`${index === selectedDropdownItemIndex && 'selected'}`}
                  onClick={() => {
                    onPressFilter(item.toLowerCase());
                    setSelectedDropdownItem(item);
                    setSelectedDropdownItemIndex(index);
                    setIsActive(false);
                  }}
                  onKeyPress={() => {
                    onPressFilter(item.toLowerCase());
                    setSelectedDropdownItem(item);
                    setSelectedDropdownItemIndex(index);
                    setIsActive(false);
                  }}
                >
                  <p>{item}</p>
                </button>
              </li>
            ))}
          </ul>
        </nav>
      </div>
    </DropdownContainer>
  );
};

export default DropdownMenu;

DropdownMenu.propTypes = {
  dropdownItems: PropTypes.arrayOf(PropTypes.node),
  onPressFilter: PropTypes.func,
};

DropdownMenu.defaultProps = {
  dropdownItems: null,
  onPressFilter: null,
};
