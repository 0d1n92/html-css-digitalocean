import styled from '@emotion/styled';
import { css } from '@emotion/core';
import media from 'css-in-js-media';

export const DropdownContainer = styled.div`

  button {
    background:none;
    border:none;
    width: 100%;
    text-align: left;
    outline: none;
  }

  .menu-container {
    display: flex;
    flex-direction: column;
    position: relative;

    ${media('< tablet')} {
      margin-top: 24px;
    }
  }

  .menu {
    background: #ffffff;
    border-radius: 8px;
    position: absolute;
    top: 46px;
    right: 0;
    opacity: 0;
    visibility: hidden;
  }

  .menu.active {
    opacity: 1;
    visibility: visible;
    transform: translateY(0);
    z-index: 10;

    .selected {
      background: #f3f5f9;

      p {
        color: #031B4E !important;
      }
    }
  }

  .menu ul {
    background: #ffffff;
    border: 1px solid #e5e8ed;
    box-sizing: border-box;
    /* Panel Hover */
    width: 272px;

    box-shadow: 0px 8px 16px rgba(1, 14, 40, 0.05);
    border-radius: 3px;
    list-style: none;
  }

  .menu li {
    text-decoration: none;
    background: #ffffff;
    box-sizing: border-box;
    border-radius: 3px;
    margin: 16px;

    a,
    p {
      padding: 16px;
      margin-top: 0;
      margin-bottom: 0;
      cursor: pointer;
      color #006aff;
    }
  }

  .menu-trigger {
    background: #ffffff;
    border: 1px solid #e5e8ed;
    box-sizing: border-box;
    border-radius: 3px;
    width: 272px;
    height: 48px;

    p {
      text-align: left;
      margin-left: 16px;
      margin-top: 8px;
    }
  }

  .menu-trigger:hover {
  }

  .menu-trigger:focus {
    outline: none;
  }

  .menu-trigger img {
    border-radius: 90px;
  }
`;

export const styledClose = css`
  cursor: pointer;
  position: absolute !important;
  right: 10px;
  top: 14px;
  max-width: 24px;
`;

export const styledDropdown = css`
  cursor: pointer;
  position: absolute !important;
  left: 238px;
  width: 24px;
  top: 12px;
  width: 32px;
`;
