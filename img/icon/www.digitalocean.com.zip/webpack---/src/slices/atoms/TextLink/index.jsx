/* eslint-disable import/no-cycle */
import React from 'react';
import PropTypes from 'prop-types';

import { styledTextLink } from './TextLinkStyles';

import { LazyLink } from '..';

const TextLink = props => {
  const { children, url } = props;

  return (
    <LazyLink url={url} {...props} css={styledTextLink}>
      {children}
    </LazyLink>
  );
};

export default TextLink;

TextLink.propTypes = {
  children: PropTypes.node.isRequired,
  url: PropTypes.node,
};

TextLink.defaultProps = {
  url: '',
};
