import { css } from '@emotion/core';

export const styledTextLink = css`
  color: #0069ff;
  font-family: 'Sailec-Bold', 'Helvetica', 'sans-serif';
  font-style: normal;

  :hover {
    color: #1633ff !important;
  }

  &.regular {
    font-family: 'Sailec-Regular', 'Helvetica', 'sans-serif';
  }

  &.medium {
    font-family: 'Sailec-Medium', 'Helvetica', 'sans-serif';
  }

  &.white {
    color: #fff;

    :hover {
      color: #fff !important;
      opacity: 0.8;
    }
  }

  &.arrow {
    &:after {
      position: relative;
      margin-left: 8px;
      top: 1px;
      content: '›';
      font-size: 23px;
      font-family: 'Sailec-Regular';
    }
  }
`;
