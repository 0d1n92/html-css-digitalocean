// Forms are created using React-Hook-Form (https://react-hook-form.com/)
/* eslint-disable camelcase */
import React, { useState } from 'react';
import PropTypes from 'prop-types';
import { useForm } from 'react-hook-form';

import { StyledFormWrapper, StyledDetailText } from '../FormsStyles';

const AbuseForm = card => {
  const {
    modal_form_1,
    modal_details_title_1,
    modal_details_text_1,
    modal_form_2,
    modal_details_title_2,
    modal_details_text_2,
    modal_form_3,
    modal_details_title_3,
    modal_details_text_3,
    modal_form_4,
    modal_details_title_4,
    modal_details_text_4,
    modal_form_5,
    modal_details_title_5,
    modal_details_text_5,
    modal_form_6,
    modal_details_title_6,
    modal_details_text_6,
    modal_form_7,
    modal_details_title_7,
    modal_details_text_7,
    modal_form_8,
    modal_details_title_8,
    modal_details_text_8,
    modal_form_9,
    modal_details_title_9,
    modal_details_text_9,
    modal_form_10,
    modal_details_title_10,
    modal_details_text_10,
    modal_form_11,
    modal_details_title_11,
    modal_details_text_11,
    modal_form_12,
    modal_details_title_12,
    modal_details_text_12,
  } = card;


  const { register, handleSubmit, watch, errors } = useForm();

  const [modalSideTitle, setModalSideTitle] = useState(modal_details_title_1[0].text);
  const [modalSideText, setModalSideText] = useState(modal_details_text_1[0].text);
  const [availableFormFields, setAvailableFormFields] = useState([]);
  const [showAbuseForm, setShowAbuseForm] = useState('is-hidden');
  const [showThankYou, setShowThankYou] = useState('is-hidden');
  const [showHideParentForm, setShowHideParentForm] = useState('is-block');
  const [showSpamvertiementText, setShowSpamvertiementText] = useState('form-item is-required textarea is-hidden');
  const [requireSpamvertiement, setRequireSpamvertiement] = useState(false);
  const [formResponseError, setFormResponseError] = useState('error-text');

  const onSubmit = data => {
    
    var urlEncodeFormData;

    const abuseType = data.abuse_type;

    switch(abuseType) {
      case 'dmca':
        urlEncodeFormData = 
        'abuse_report[abuse_type]=dmca' + 
        '&abuse_report[copyright_holder_name]=' + encodeURI(data.copyright_holder_name) +
        '&abuse_report[reporter_name]=' + encodeURI(data.reporter_name) +
        '&abuse_report[address]=' + encodeURI(data.address) +
        '&abuse_report[phone]=' + encodeURI(data.phone) +
        '&abuse_report[email]=' + encodeURIComponent(data.email) +
        '&abuse_report[infringing_description]=' + encodeURI(data.infringing_description) +
        '&abuse_report[original_description]=' + encodeURI(data.original_description) +
        '&abuse_report[acknowledgment_check]=acknowledged' +
        '&abuse_report[digital_signature]=' + encodeURI(data.digital_signature)
        break;
      case 'trademark':
        urlEncodeFormData = 
        'abuse_report[abuse_type]=trademark' + 
        '&abuse_report[reporter_name]=' + encodeURI(data.reporter_name) +
        '&abuse_report[address]=' + encodeURI(data.address) +
        '&abuse_report[phone]=' + encodeURI(data.phone) +
        '&abuse_report[email]=' + encodeURIComponent(data.email) +
        '&abuse_report[trademarked_work]=' + encodeURI(data.trademarked_work) +
        '&abuse_report[registration_office]=' + encodeURI(data.registration_office) +
        '&abuse_report[registration_number]=' + encodeURI(data.registration_number) +
        '&abuse_report[abuse_comments]=' + encodeURI(data.abuse_comments) +
        '&abuse_report[infringing_description]=' + encodeURI(data.infringing_description) +
        '&abuse_report[digital_signature]=' + encodeURI(data.digital_signature)
        break;
      case 'spam':
        urlEncodeFormData = 
        'abuse_report[abuse_type]=spam' + 
        '&abuse_report[reporter_name]=' + encodeURI(data.reporter_name) +
        '&abuse_report[email]=' + encodeURIComponent(data.email) +
        '&abuse_report[headers]=' + encodeURI(data.headers) +
        '&abuse_report[message_body]=' + encodeURI(data.message_body) +
        '&abuse_report[spamvertisement_checkbox]=' + encodeURI(data.spamvertisement_checkbox) +
        '&abuse_report[spamvertisement_bod]=' + encodeURI(data.spamvertisement_body)
        break;
      case 'phishing':
        urlEncodeFormData = 
        'abuse_report[abuse_type]=phishing' + 
        '&abuse_report[reporter_name]=' + encodeURI(data.reporter_name) +
        '&abuse_report[email]=' + encodeURIComponent(data.email) +
        '&abuse_report[phishing_target]=' + encodeURI(data.phishing_target) +
        '&abuse_report[evidence_urls]=' + encodeURI(data.evidence_urls) +
        '&abuse_report[additional_information]=' + encodeURI(data.additional_information)
        break;
      case 'malware':
        urlEncodeFormData = 
        'abuse_report[abuse_type]=malware' + 
        '&abuse_report[reporter_name]=' + encodeURI(data.reporter_name) +
        '&abuse_report[email]=' + encodeURIComponent(data.email) +
        '&abuse_report[evidence_urls]=' + encodeURI(data.evidence_urls) +
        '&abuse_report[additional_information]=' + encodeURI(data.additional_information)
        break;
      case 'botnet':
        urlEncodeFormData = 
        'abuse_report[abuse_type]=botnet' + 
        '&abuse_report[reporter_name]=' + encodeURI(data.reporter_name) +
        '&abuse_report[email]=' + encodeURIComponent(data.email) +
        '&abuse_report[evidence_urls]=' + encodeURI(data.evidence_urls)
        break;
      case 'bruteforce':
        urlEncodeFormData = 
        'abuse_report[abuse_type]=bruteforce' + 
        '&abuse_report[reporter_name]=' + encodeURI(data.reporter_name) +
        '&abuse_report[email]=' + encodeURIComponent(data.email) +
        '&abuse_report[evidence]=' + encodeURI(data.evidence) +
        '&abuse_report[timezone]=' + encodeURI(data.timezone) 
        break;
      case 'childabuse':
        urlEncodeFormData = 
        'abuse_report[abuse_type]=childabuse' + 
        '&abuse_report[reporter_name]=' + encodeURI(data.reporter_name) +
        '&abuse_report[email]=' + encodeURIComponent(data.email) +
        '&abuse_report[evidence_urls]=' + encodeURI(data.evidence_urls) +
        '&abuse_report[digital_signature]=' + encodeURI(data.digital_signature)
        break;
      case 'violent':
        urlEncodeFormData = 
        'abuse_report[abuse_type]=violent' + 
        '&abuse_report[reporter_name]=' + encodeURI(data.reporter_name) +
        '&abuse_report[email]=' + encodeURIComponent(data.email) +
        '&abuse_report[evidence_urls]=' + encodeURI(data.evidence_urls) +
        '&abuse_report[additional_information]=' + encodeURI(data.additional_information)
        break;
      case 'other':
        urlEncodeFormData = 
        'abuse_report[abuse_type]=other' + 
        '&abuse_report[reporter_name]=' + encodeURI(data.reporter_name) +
        '&abuse_report[email]=' + encodeURIComponent(data.email) +
        '&abuse_report[original_description]=' + encodeURI(data.original_description) +
        '&abuse_report[evidence]=' + encodeURI(data.evidence) +
        '&abuse_report[abuse_comments]=' + encodeURI(data.abuse_comments)
        break;
    }

    fetch('https://inbound.digitalocean.com/contact_forms/abuse_reports', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: urlEncodeFormData
    })
    .then((response) => {
     if (response.status === 201) {
        setShowHideParentForm('is-hidden')
        setShowThankYou('thank-you is-block')
      } else {
        setFormResponseError('error-text is-block')
      }
      
    })
    .catch((error) => {
      console.error('Error:', error);
    });

  };

  const onChange = event => {
    const value = event.target.value;
    const lowerValue = value.replace(/\s+/g, '-').toLowerCase();

    setShowAbuseForm('is-block');

    switch(lowerValue) {
      case 'dmca-takedown':
        setModalSideTitle(modal_details_title_2[0].text)
        setModalSideText(modal_details_text_2[0].text)

        availableFormFields.length = 0;
        setAvailableFormFields(availableFormFields.concat(
          {form_type: "input", type: "text", id: "DmcaAbuse-copyrightHolderName", name: "copyright_holder_name", required: true, placeholder: "Copyright Owner's Full Name", errorMessage: "Copyright Owner's Full Name"},
          {form_type: "input", type: "text", id: "DmcaAbuse-reporterName", name: "reporter_name", required: true, placeholder: "Your Full Name", errorMessage: "Full name is required"},
          {form_type: "input", type: "text", id: "DmcaAbuse-address", name: "address", required: true, placeholder: "Address", errorMessage: "Address is required"},
          {form_type: "input", type: "text", id: "DmcaAbuse-phone", name: "phone", required: true, placeholder: "Phone Number (Digits Only)", errorMessage: "Phone number is required"},
          {form_type: "input", type: "text", id: "DmcaAbuse-email", name: "email", required: true, placeholder: "Email Address", errorMessage: "Email address is required"},
          {form_type: "textarea", id: "DmcaAbuse-infringingDescription", name: "infringing_description", required: true, placeholder: "URL(s) and/or a description of the infringing content", errorMessage: "Infringing content is required"},
          {form_type: "textarea", id: "DmcaAbuse-originalDescription", name: "original_description", required: true, placeholder: "URL(s) and/or a description of the original content", errorMessage: "Original content is required"},
          {form_type: "checkbox", id: "DmcaAbuse-acknowledgementCheck", name: "acknowledgment_check", required: true, placeholder: "By checking this box, you attest, under penalty of perjury, that (1) you have a good faith belief that use of the material in this report is not authorized by the copyright owner, its agent, or the law; (2) you are the copyright owner or authorized to act on behalf of the copyright owner; and (3) you understand, under 17 U.S.C. § 512(f), that you may be liable for any damages, including costs and attorneys' fees, if you knowingly materially misrepresent that the material you are reporting is infringing.", errorMessage: "Acknowledgement checkbox is required."},
          {form_type: "input", type: "text", id: "DmcaAbuse-digitalSignature", name: "digital_signature", required: true, placeholder: "Digital Signature", errorMessage: "Digital Signature is required"},
          {form_type: "hidden", type: "hidden", name: "abuse_type", set_value: "dmca"}
        ))

        break;
      case 'trademark-infringement':
        setModalSideTitle(modal_details_title_3[0].text)
        setModalSideText(modal_details_text_3[0].text)
        
        availableFormFields.length = 0;
        setAvailableFormFields(availableFormFields.concat(
          {form_type: "input", type: "text", id: "TrademarkAbuse-reporterName", name: "reporter_name", required: true, placeholder: "Your Full Name", errorMessage: "Full name is required"},
          {form_type: "input", type: "text", id: "TrademarkAbuse-address", name: "address", required: true, placeholder: "Address", errorMessage: "Address is required"},
          {form_type: "input", type: "text", id: "TrademarkAbuse-phone", name: "phone", required: true, placeholder: "Phone Number (Digits Only)", errorMessage: "Phone number is required"},
          {form_type: "input", type: "text", id: "TrademarkAbuse-email", name: "email", required: true, placeholder: "Email Address", errorMessage: "Email address is required"},
          {form_type: "input", type: "text", id: "TrademarkAbuse-trademarkedWork", name: "trademarked_work", required: true, placeholder: "Trademarked word/symbol", errorMessage: "Trademarked word/symbol is required"},
          {form_type: "input", type: "text", id: "TrademarkAbuse-registrationOffice", name: "registration_office", required: true, placeholder: "Registration office, Country", errorMessage: "Registration office is required"},
          {form_type: "input", type: "text", id: "TrademarkAbuse-registrationNumber", name: "registration_number", required: true, placeholder: "Registration number", errorMessage: "Registration number is required"},
          {form_type: "textarea", id: "TrademarkAbuse-infringingDescription", name: "infringing_description", required: true, placeholder: "URL(s) and/or a description of the infringing content", errorMessage: "Infringing content is required"},
          {form_type: "textarea", id: "TrademarkAbuse-abuseComments", name: "abuse_comments", required: true, placeholder: "Comments/Commercial Nexus", errorMessage: "Comments field is required"},
          {form_type: "input", type: "text", id: "TrademarkAbuse-digitalSignature", name: "digital_signature", required: true, placeholder: "Digital Signature", errorMessage: "Digital Signature is required"},
          {form_type: "hidden", type: "hidden", name: "abuse_type", set_value: "trademark"}
        ))
        break;
      case 'spam':
        setModalSideTitle(modal_details_title_4[0].text)
        setModalSideText(modal_details_text_4[0].text)

        availableFormFields.length = 0;
        setAvailableFormFields(availableFormFields.concat(
          {form_type: "input", type: "text", id: "SpamAbuse-reporterName", name: "reporter_name", required: true, placeholder: "Your Full Name", errorMessage: "Full name is required"},
          {form_type: "input", type: "text", id: "SpamAbuse-email", name: "email", required: true, placeholder: "Email Address", errorMessage: "Email address is required"},
          {form_type: "textarea", id: "SpamAbuse-headers", name: "headers", required: true, placeholder: "Headers from email received", errorMessage: "Headers from email received are required"},
          {form_type: "textarea", id: "SpamAbuse-originalDescription", name: "message_body", required: true, placeholder: "Message Body", errorMessage: "Message body is required"},
          {form_type: "checkbox", id: "SpamAbuse-spamvertisementCheckbox", name: "spamvertisement_checkbox", required: true, placeholder: "Is this Spamvertisement?", errorMessage: ""},
          {form_type: "textarea", id: "SpamAbuse-spamvertisementBody", name: "spamvertisement_body", required: true, placeholder: "Spamvertisement URLs", errorMessage: "Spamvertisement URLs are required"},
          {form_type: "hidden", type: "hidden", name: "abuse_type", set_value: "spam"}
        ))
        break;
      case 'phishing':
        setModalSideTitle(modal_details_title_5[0].text)
        setModalSideText(modal_details_text_5[0].text)

        availableFormFields.length = 0;
        setAvailableFormFields(availableFormFields.concat(
          {form_type: "input", type: "text", id: "PhishingAbuse-reporterName", name: "reporter_name", required: true, placeholder: "Your Full Name", errorMessage: "Full name is required"},
          {form_type: "input", type: "text", id: "PhishingAbuse-email", name: "email", required: true, placeholder: "Email Address", errorMessage: "Your email address is required"},
          {form_type: "input", type: "text", id: "PhishingAbuse-target", name: "phishing_target", required: true, placeholder: "Target of Phishing Campaign", errorMessage: "Target of phishing campaign is required"},
          {form_type: "textarea", id: "PhishingAbuse-evidenceURLS", name: "evidence_urls", required: true, placeholder: "Evidence URLs", errorMessage: "Evidence URLs are required"},
          {form_type: "textarea", id: "PhishingAbuse-additional", name: "additional_information", required: true, placeholder: "Additional Evidence or Logs", errorMessage: "Additional Evidence or Logs are required"},
          {form_type: "hidden", type: "hidden", name: "abuse_type", set_value: "phishing"}
        ))
        break;
      case 'malware':
        setModalSideTitle(modal_details_title_6[0].text)
        setModalSideText(modal_details_text_6[0].text)

        availableFormFields.length = 0;
        setAvailableFormFields(availableFormFields.concat(
          {form_type: "input", type: "text", id: "MalwareAbuse-reporterName", name: "reporter_name", required: true, placeholder: "Your Full Name", errorMessage: "Full name is required"},
          {form_type: "input", type: "text", id: "MalwareAbuse-email", name: "email", required: true, placeholder: "Email Address", errorMessage: "Email address is required"},
          {form_type: "textarea", id: "MalwareAbuse-evidenceURLS", name: "evidence_urls", required: true, placeholder: "Evidence URLs", errorMessage: "Evidence URLs are required"},
          {form_type: "textarea", id: "MalwareAbuse-additional", name: "additional_information", required: true, placeholder: "Additional Evidence or Logs", errorMessage: "Additional Evidence or Logs are required"},
          {form_type: "hidden", type: "hidden", name: "abuse_type", set_value: "malware"}
        ))
        break;
      case 'botnet':
        setModalSideTitle(modal_details_title_7[0].text)
        setModalSideText(modal_details_text_7[0].text)

        availableFormFields.length = 0;
        setAvailableFormFields(availableFormFields.concat(
          {form_type: "input", type: "text", id: "BotnetAbuse-reporterName", name: "reporter_name", required: true, placeholder: "Your Full Name", errorMessage: "Full name is required"},
          {form_type: "input", type: "text", id: "BotnetAbuse-email", name: "email", required: true, placeholder: "Email Address", errorMessage: "Email address is required"},
          {form_type: "textarea", id: "BotnetAbuse-evidence", name: "evidence_urls", required: true, placeholder: "Evidence URLs", errorMessage: "Evidence URLs are required"},
          {form_type: "hidden", type: "hidden", name: "abuse_type", set_value: "botnet"}
        ))
        break;
      case 'bruteforce/portscan':
        setModalSideTitle(modal_details_title_8[0].text)
        setModalSideText(modal_details_text_8[0].text)

        availableFormFields.length = 0;
        setAvailableFormFields(availableFormFields.concat(
          {form_type: "input", type: "text", id: "BruteforceAbuse-reporterName", name: "reporter_name", required: true, placeholder: "Your Full Name", errorMessage: "Full name is required"},
          {form_type: "input", type: "text", id: "BruteforceAbuse-email", name: "email", required: true, placeholder: "Email Address", errorMessage: "Email address is required"},
          {form_type: "textarea", id: "BruteforceAbuse-evidence", name: "evidence", required: true, placeholder: "Evidence or logs of the activity showing source IP", errorMessage: "Evidence or logs of the activity showing source IP is required"},
          {form_type: "textarea", id: "BruteforceAbuse-timezone", name: "timezone", required: true, placeholder: "Your server's time zone", errorMessage: "Your server's time zone is required"},
          {form_type: "hidden", type: "hidden", name: "abuse_type", set_value: "bruteforce"}
        ))
        break;
      case 'child-abuse':
        setModalSideTitle(modal_details_title_9[0].text)
        setModalSideText(modal_details_text_9[0].text)

        availableFormFields.length = 0;
        setAvailableFormFields(availableFormFields.concat(
          {form_type: "input", type: "text", id: "ChildabuseAbuse-reporterName", name: "reporter_name", required: true, placeholder: "Your Full Name", errorMessage: "Full name is required"},
          {form_type: "input", type: "text", id: "ChildabuseAbuse-email", name: "email", required: true, placeholder: "Email Address", errorMessage: "Email address is required"},
          {form_type: "textarea", id: "ChildabuseAbuse-evidence", name: "evidence_urls", required: true, placeholder: "Evidence URLs", errorMessage: "Evidence URLs are required"},
          {form_type: "input", type: "text", id: "ChildabuseAbuse-digitalSignature", name: "digital_signature", required: true, placeholder: "Digital Signature", errorMessage: "Digital Signature is required"},
          {form_type: "hidden", type: "hidden", name: "abuse_type", set_value: "childabuse"}
        ))
        break;
      case 'violent-threats-and-harassment':
        setModalSideTitle(modal_details_title_10[0].text)
        setModalSideText(modal_details_text_10[0].text)

        availableFormFields.length = 0;
        setAvailableFormFields(availableFormFields.concat(
          {form_type: "input", type: "text", id: "ViolentAbuse-reporterName", name: "reporter_name", required: true, placeholder: "Your Full Name", errorMessage: "Full name is required"},
          {form_type: "input", type: "text", id: "ViolentAbuse-email", name: "email", required: true, placeholder: "Email Address", errorMessage: "Email address is required"},
          {form_type: "textarea", id: "ViolentAbuse-evidence", name: "evidence_urls", required: true, placeholder: "Evidence URLs", errorMessage: "Evidence URLs are required"},
          {form_type: "textarea", id: "ViolentAbuse-additionalinfo", name: "additional_information", required: true, placeholder: "Additional information", errorMessage: "Additional information is required"},
          {form_type: "hidden", type: "hidden", name: "abuse_type", set_value: "violent"}
        ))
        break;
      case 'other':
        setModalSideTitle(modal_details_title_11[0].text)
        setModalSideText(modal_details_text_11[0].text)

        availableFormFields.length = 0;
        setAvailableFormFields(availableFormFields.concat(
          {form_type: "input", type: "text", id: "OtherAbuse-reporterName", name: "reporter_name", required: true, placeholder: "Your Full Name", errorMessage: "Full name is required"},
          {form_type: "input", type: "text", id: "OtherAbuse-email", name: "email", required: true, placeholder: "Email Address", errorMessage: "Email address is required"},
          {form_type: "textarea", id: "OtherAbuse-description", name: "original_description", required: true, placeholder: "Description of issue", errorMessage: "Description of issue is required"},
          {form_type: "textarea", id: "OtherAbuse-evidence", name: "evidence", required: true, placeholder: "Evidence URL", errorMessage: "Evidence URL is required"},
          {form_type: "textarea", id: "OtherAbuse-comments", name: "abuse_comments", required: true, placeholder: "Comments", errorMessage: "Comments required"},
          {form_type: "hidden", type: "hidden", name: "abuse_type", set_value: "other"}
        ))
        break;
      case 'select-abuse-type':
        setModalSideTitle(modal_details_title_1[0].text)
        setModalSideText(modal_details_text_1[0].text)
        setShowAbuseForm('is-hidden');
        break;
      default:
        setModalSideTitle(modal_details_title_1[0].text)
        setModalSideText(modal_details_text_1[0].text)
    }
    
  };

  const onCheckboxChange = event => {

    const isChecked = event.target.checked;

    if (isChecked) {
      setShowSpamvertiementText('form-item is-required textarea')
      setRequireSpamvertiement(true)
    } else {
      setShowSpamvertiementText('form-item is-required textarea is-hidden')
      setRequireSpamvertiement(false)
    }
  }

  return (
    <StyledFormWrapper>
      <p className={formResponseError}>There was a problem with your form request. Please try again.</p>
      <span className={showThankYou}>
        <h4>Thank you! Someone from our team will followup with you shortly.</h4>
      </span>

      <form name="Abuse" onSubmit={handleSubmit(onSubmit)} className={showHideParentForm}>
        <span className="form-item">
          <select id="Abuse-type" name="abuseType" ref={register} onChange={onChange}>
            {modal_form_1 ? <option value={modal_form_1}>{modal_form_1}</option> : null}
            {modal_form_2 ? <option value={modal_form_2}>{modal_form_2}</option> : null}
            {modal_form_3 ? <option value={modal_form_3}>{modal_form_3}</option> : null}
            {modal_form_4 ? <option value={modal_form_4}>{modal_form_4}</option> : null}
            {modal_form_5 ? <option value={modal_form_5}>{modal_form_5}</option> : null}
            {modal_form_6 ? <option value={modal_form_6}>{modal_form_6}</option> : null}
            {modal_form_7 ? <option value={modal_form_7}>{modal_form_7}</option> : null}
            {modal_form_8 ? <option value={modal_form_8}>{modal_form_8}</option> : null}
            {modal_form_9 ? <option value={modal_form_9}>{modal_form_9}</option> : null}
            {modal_form_10 ? <option value={modal_form_10}>{modal_form_10}</option> : null}
            {modal_form_11 ? <option value={modal_form_11}>{modal_form_11}</option> : null}
            {modal_form_12 ? <option value={modal_form_12}>{modal_form_12}</option> : null}
          </select>
        </span>

        <span className={showAbuseForm}>
          
          {availableFormFields.map((form, i) => (
            
            <div>
            {form.form_type == 'input' ? (
              <span className="form-item is-required input" key={i}>
                <input
                  type={form.type}
                  id={form.id}
                  name={form.name}
                  placeholder={form.placeholder}
                  className={errors[form.name] ? 'error-border' : 'error-none'}
                  ref={register({ required: true })}
                />
                {errors[form.name] && <span className="error-text">{form.errorMessage}</span>}
              </span>
              
            ) : null}

            {form.form_type == 'textarea' ? (
              <span className={form.id == 'SpamAbuse-spamvertisementBody' ? showSpamvertiementText : 'form-item is-required textarea'} key={i}>
                <textarea
                  id={form.id}
                  name={form.name}
                  ref={register({ required: (form.id == 'SpamAbuse-spamvertisementBody' ? requireSpamvertiement : true) })}
                  placeholder={form.placeholder}
                  className={errors[form.name] ? 'error-border' : 'error-none'}
                />
                {errors[form.name] && <span className="error-text">{form.errorMessage}</span>}
              </span>
            ) : null}

            {form.form_type == 'checkbox' ? (
              <span className="form-item is-required" key={i}>
                <span className="checkbox-wrapper">
                  <span className="checkbox">
                    <input 
                      id={form.id} 
                      type="checkbox" 
                      name={form.name}
                      onChange={onCheckboxChange}
                      ref={register({ required: (form.id == 'SpamAbuse-spamvertisementCheckbox' ? requireSpamvertiement : true) })}
                    />
                  </span>
                  <span className="checkbox-text">
                    {form.placeholder}
                  </span>
                  {errors[form.name] && <span className="error-text">{form.errorMessage}</span>}
                </span>
              </span>

            ) : null}

            {form.form_type == 'hidden' ? (
              <span key={i}>
                <input 
                  type="hidden" 
                  name={form.name}
                  value={form.set_value}
                  ref={register({ required: false })}
                />
              </span>

            ) : null}
              
            </div>
            
          ))}          
          
          <p>
            By entering your name, you affirm all information is true and accurate. All information submitted to us may be
            relayed to the customer during our remediation process.
          </p>
          <span className="form-item">
            <input type="submit" value="Report Abuse" />
          </span>
        </span>
      </form>
    
      <StyledDetailText className={showHideParentForm}>
        <p>{modalSideTitle}</p>
        <p>{modalSideText}</p>
      </StyledDetailText>
    </StyledFormWrapper>
  );
};

export default AbuseForm;