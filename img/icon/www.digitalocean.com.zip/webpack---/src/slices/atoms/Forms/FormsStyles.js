import styled from '@emotion/styled';

export const StyledFormWrapper = styled.div`
  display: flex;
  justify-content: center;
  flex-wrap: wrap;
  overflow: scroll;

  form {
    margin-right: 40px;
    margin-top: 40px;
    width: 60%;
  }

  .form-item {
    position: relative;

    &.input.is-required:before,
    &.textarea.is-required:before {
      content: '';
      background: url(
        https://images.prismic.io/www-static/50bfb6e8-d754-4e9f-ade8-b9a08d1ab626_asterik-blue.svg?auto=compress,
        format
      );
      background-size: 10px;
      fill: #0069ff;
      width: 10px;
      height: 10px;
      background-repeat: no-repeat;
      position: absolute;
      top: 5px;
      right: 16px;
      -webkit-transform-origin: center center;
      transform-origin: center center;
      pointer-events: none;
      z-index: 2;
    }

    &.textarea.is-required:before {
      top: 35px;
    }

    input,
    select {
      width: 100%;
      height: 48px;
      background: #fff;
      border: 1px solid #e5e8ed;
      box-sizing: border-box;
      border-radius: 3px;
      margin-bottom: 8px;
      font-family: 'Sailec-Regular';
      font-size: 16px;
      padding: 16px;
      color: #5b6987;
      :focus {
        border-color: #0069ff;
        outline: #0069ff;
      }
    }

    input[type='submit'] {
      background: #0069ff;
      border: none;
      line-height: 100%;
      font-family: 'Sailec-Bold';
      color: #fff;
      padding: 17px;
      cursor: pointer;
      margin-bottom: 25px;
    }

    select {
      height: auto;
    }

    span.error-text {
      color: #ca0c0c;
      display: inline-block;
      font-family: 'Sailec-Regular';
      font-size: 12px;
      margin-bottom: 16px;
      text-align: left;
      width: 100%;
    }

    textarea {
      color: #5b6987;
      border: 1px solid #e5e8ed;
      font-family: 'Sailec-Regular';
      font-size: 16px;
      overflow: auto;
      vertical-align: top;
      resize: vertical;
      margin: 0 0 8px 0;
      min-height: 80px;
      height: auto;
      text-indent: 10px;
      width: 99%;
    }

    textarea::placeholder {
      color: #5b6987;
    }
  }

  .checkbox-wrapper {
    display: flex;
    flex-wrap: wrap;
    margin-bottom: 25px;

    .checkbox {
      width: 28px;
    }

    .checkbox-text {
      margin-bottom: 15px;
      margin-left: 15px;
      margin-top: 15px;
      width: 80%;
    }
  }

  .is-hidden {
    display: none;
  }

  .is-block {
    display: block;
  }

  .thank-you.is-block {
    margin: 40px 0;
  }

  p.error-text {
    color: #ca0c0c;
    display: none;
    font-family: 'Sailec-Regular';
    font-size: 16px;
    margin-bottom: 16px;
    text-align: center;
    width: 100%;
  }

  p.error-text.is-block {
    display: block;
  }
`;

export const StyledDetailText = styled.div`
  width: 30%;

  p:nth-of-type(odd) {
    color: #031b4e;
    font-family: 'Sailec-Regular';
    font-style: normal;
    font-weight: normal;
    font-size: 16px;
    line-height: 160%;
  }

  p:nth-of-type(even) {
    color: #5b6987;
    font-family: 'Sailec-Regular';
    font-style: normal;
    font-weight: normal;
    font-size: 12px;
    line-height: 160%;
  }
`;
