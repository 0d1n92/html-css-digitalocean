// Styles here will override Bulma styles
import { css } from '@emotion/core';
import styled from '@emotion/styled';
import media from 'css-in-js-media';

export const styledCarouselTestimonialSection = css`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
`;

export const styledHeading = css`
  text-align: center;
`;

export const styledSubHeading = css`
  text-align: center;
  max-width: 820px;
  p {
    margin-top: 0;
    margin-bottom: 36px !important;
  }
`;

export const styledQuoteContainer = css`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: flex-start;
  max-width: 770px;
  height: auto;
  margin: 64px;

  figure {
    max-width: 150px;
    height: auto;
    img {
      max-width: 150px;
      margin-bottom: 10px;
    }
  }

  p.quote {
    font-size: 24px;
  }
`;

export const styledCarouselTestimonialContent = css`
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  text-align: center;
`;

export const StyledSingleQuote = styled.div`
  width: 870px;

  ${media('< desktop')} {
    width: 90vw;
  }

  div {
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0;
    width: 100%;
    max-width: 100%;
  }
`;
