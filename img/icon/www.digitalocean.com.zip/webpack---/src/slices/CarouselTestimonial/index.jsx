/* eslint-disable camelcase */
import React from 'react';
import PropTypes from 'prop-types';

import BulmaSection from 'react-bulma-components/lib/components/section';
import BulmaColumns from 'react-bulma-components/lib/components/columns';
import BulmaContainer from 'react-bulma-components/lib/components/container';

import { css } from '@emotion/core';

import { Carousel, Quote, Heading } from '../atoms';

import {
  styledQuoteContainer,
  styledHeading,
  styledSubHeading,
  styledCarouselTestimonialSection,
  styledCarouselTestimonialContent,
  StyledSingleQuote,
} from './CarouselTestimonialStyles';

import { createRandomId } from '../../util/createRandomId';

const renderContent = (fields, text_color) =>
  fields.map(field => (
    <BulmaContainer css={styledQuoteContainer} key={createRandomId()}>
      <BulmaColumns gapless multiline={false}>
        <BulmaColumns.Column size={12} css={styledCarouselTestimonialContent}>
          <Quote quoteProps={{ ...field, text_color }} />
        </BulmaColumns.Column>
      </BulmaColumns>
    </BulmaContainer>
  ));

const CarouselTestimonial = ({ input }) => {
  const { background_color, background_image, text_color, heading, heading_color, subheading1 } = input.primary;

  return (
    <BulmaSection
      css={css`
        ${styledCarouselTestimonialSection}
        ${background_image ? `background-image: url(${background_image.url});` : null};
        background-color: ${background_color};
      `}
    >
      {heading && heading[0].text && (
        <Heading
          renderAs="h2"
          className={text_color === 'light' ? 'h2 white' : 'h2 darkblue'}
          css={css`
            ${styledHeading}
              color: ${heading_color} !important;
            `}
        >
          {heading[0].text}
        </Heading>
      )}
      {subheading1 && subheading1[0].text && (
        <Heading
          className={text_color === 'light' ? 'medium grey subtitle' : 'medium darkblue subtitle'}
          css={styledSubHeading}
        >
          {subheading1}
        </Heading>
      )}
      {input.fields.length > 1 ? (
        <Carousel
          fadeIn
          text_color={text_color}
          selectColor={text_color === 'light' ? '#fff' : '#0069ff'}
          id="testCarouselTestimonial"
          type="testimonial"
        >
          {renderContent(input.fields, text_color)}
        </Carousel>
      ) : (
        <StyledSingleQuote>{renderContent(input.fields, text_color)}</StyledSingleQuote>
      )}
    </BulmaSection>
  );
};

export default CarouselTestimonial;

CarouselTestimonial.propTypes = {
  input: PropTypes.object.isRequired,
};

renderContent.propTypes = {
  fields: PropTypes.array.isRequired,
};
