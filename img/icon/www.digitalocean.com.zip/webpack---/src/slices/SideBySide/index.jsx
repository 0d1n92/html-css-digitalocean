/* eslint-disable camelcase */
import React from 'react';
import PropTypes from 'prop-types';

import BulmaColumns from 'react-bulma-components/lib/components/columns';
import BulmaContainer from 'react-bulma-components/lib/components/container';
import BulmaSection from 'react-bulma-components/lib/components/section';

import LazyLoad from 'react-lazy-load'; // TODO: remove and use our own Framer Motion animation

import { Heading, TextLink } from '../atoms';

import ImageLoader from './ImageLoader'; // TODO: remove and use our own Framer Motion animation

import { StyledSideBySide, styledHeading, styledP, styledLink } from './SideBySideStyles';

const renderImage = image => (
  <LazyLoad debounce={false} offsetVertical={0}>
    <ImageLoader src={image.url} />
  </LazyLoad>
);

const renderHeading = (copy, atts) => <Heading {...atts}>{copy.text}</Heading>;

const renderLink = (link, linkText) =>
  link && link.url ? (
    <TextLink css={styledLink} url={link.url}>
      {linkText.text}
    </TextLink>
  ) : null;

const SideBySide = ({ input }) => {
  const { cta_url, cta_text, graphic, title, text } = input.primary;

  return (
    <StyledSideBySide className="side-by-side">
      <BulmaSection className="top-line">
        <BulmaContainer className="through-line">
          <BulmaColumns>
            <BulmaColumns.Column>{renderImage(graphic)}</BulmaColumns.Column>
            <BulmaColumns.Column>
              {title &&
                title[0].text &&
                renderHeading(title[0], { css: styledHeading, className: 'h3 darkblue', renderAs: 'h3' })}
              {text &&
                text[0].text &&
                renderHeading(text[0], { css: styledP, className: 'medium darkgrey', subtitle: true, renderAs: 'p' })}
              {cta_text && cta_text[0].text && renderLink(cta_url, cta_text[0])}
            </BulmaColumns.Column>
          </BulmaColumns>
        </BulmaContainer>
      </BulmaSection>
    </StyledSideBySide>
  );
};

export default SideBySide;

SideBySide.propTypes = {
  input: PropTypes.object.isRequired,
};
