// based on https://gist.github.com/rossbulat/d840280fe9fc0dde1e2d94db48519e27#file-imageloader-js

import React, { useState } from 'react';
import PropTypes from 'prop-types';

const ImageLoader = props => {
  // initial state: image loaded stage
  const [loaded, setLoaded] = useState(false);

  let className = '';
  const { src } = props;
  const loadedClassName = 'img-loaded';
  const loadingClassName = 'img-loading';

  const load = () => {
    setLoaded(true);
  };

  className = `${className} ${loaded ? loadedClassName : loadingClassName}`;

  return <img src={src} className={className} onLoad={load} alt={src || 'loading'} />;
};

export default ImageLoader;

ImageLoader.propTypes = {
  src: PropTypes.string.isRequired,
};
