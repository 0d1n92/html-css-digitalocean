// Styles here will override Bulma styles
import styled from '@emotion/styled';
import { css } from '@emotion/core';
import media from 'css-in-js-media';
import circle from '../../assets/images/circle-lightgray.svg';

export const styledHeading = css`
  margin-bottom: 0 !important;
  padding-left: 50px;
  position: relative;

  ${media('< tablet')} {
    margin-top: 0;
    padding-left: 0;
  }

  :before {
    background: url(${circle}) no-repeat 0 0;
    content: '';
    height: 20px;
    left: -19px;
    margin-top: -10px;
    position: absolute;
    top: 50%;
    width: 20px;

    ${media('< desktop')} {
      background-image: none;
    }
  }
`;

export const styledP = css`
  padding-left: 50px;
  padding-right: 100px;

  ${media('< tablet')} {
    padding-left: 0;
    padding-right: 0;
  }
`;

export const styledLink = css`
  padding-left: 50px;

  ${media('< tablet')} {
    padding-left: 0;
    display: inline-block;
  }
`;

export const StyledSideBySide = styled.div`
  position: relative;

  ${media('< tablet')} {
    text-align: center;
  }

  img {
    max-width: 100%;
    ${media('= tablet')} {
      max-width: 350px;
    }
  }

  @keyframes fadeInImg {
    from {
      margin-left: -40px;
      opacity: 0;
    }

    to {
      margin-left: 0;
      opacity: 1;
    }
  }

  .img-loading {
    opacity: 0;
    margin-left: -40px;
  }

  .img-loaded {
    animation-name: fadeInImg;
    animation-duration: 0.5s;
    animation-iteration-count: 1;
    animation-direction: normal;
    animation-timing-function: ease-in;
    animation-fill-mode: forwards;
    animation-delay: 0;
  }

  .column {
    display: flex;
    flex-direction: column;
    justify-content: center;
    max-height: 400px;

    ${media('< desktop')} {
      display: block;
      max-height: 100%;
      padding: 0;
    }
  }

  .LazyLoad {
    height: 500px;
    ${media('< tablet')} {
      height: 300px;
    }
  }

  .top-line::before {
    ${media('< desktop')} {
      display: none;
    }
  }

  .through-line::before {
    background-color: #e5e8ed;
    content: '';
    height: 131%;
    left: 49.95%;
    position: absolute;
    top: -35px;
    width: 2px;

    ${media('< desktop')} {
      background-color: transparent;
    }
  }
`;
