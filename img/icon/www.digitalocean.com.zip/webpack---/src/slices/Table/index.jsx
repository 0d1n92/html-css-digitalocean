/* eslint-disable camelcase */
import React from 'react';
import PropTypes from 'prop-types';
import { RichText } from 'prismic-reactjs';
import linkResolver from '../../util/linkResolver';

import BulmaContainer from 'react-bulma-components/lib/components/container';
import BulmaSection from 'react-bulma-components/lib/components/section';
import BulmaTable from 'react-bulma-components/lib/components/table';

import { createRandomId } from '../../util/createRandomId';

import { Heading } from '../atoms';

import { styledHeading, styledSubheading, styledTable, styledSection } from './TableStyles';

const renderHeading = (text, atts) => (
  <Heading {...atts} css={atts.css}>
    {text.text}
  </Heading>
);

const Table = ({ input }) => {
  const {
    text_color,
    background_color,
    background_image,
    heading,
    heading_color,
    subheading,
    subheading_color,
    column_header_1,
    column_header_2,
    column_header_3,
    column_header_4,
    column_header_5,
    column_header_6,
  } = input.primary;

  return (
    <BulmaSection
      css={styledSection}
      style={{
        backgroundColor: background_color || '#fff',
        backgroundImage: `url(${background_image && background_image.url})`,
        paddingTop: `${!heading && !subheading ? '0px' : null}`,
      }}
    >
      <BulmaContainer>
        {heading &&
          heading[0].text &&
          renderHeading(heading[0], {
            'data-testid': 'heading',
            renderAs: 'h2',
            style: heading_color ? { color: heading_color } : null,
            className: text_color === 'light' ? 'h2 white' : 'h2 darkblue',
            css: styledHeading,
          })}
        {subheading &&
          subheading[0].text &&
          renderHeading(subheading[0], {
            'data-testid': 'subheading',
            renderAs: 'p',
            style: subheading_color ? { color: subheading_color } : null,
            className: text_color === 'light' ? 'medium white' : 'medium darkgrey',
            subtitle: true,
            css: styledSubheading,
          })}
        <BulmaTable css={styledTable} className="is-scrollable">
          <thead>
            <tr>
              <th className={column_header_1 && column_header_1[0].text && 'active'} key={createRandomId()}>
                {column_header_1 && column_header_1[0].text}
              </th>
              <th className={column_header_2 && column_header_2[0].text && 'active'} key={createRandomId()}>
                {column_header_2 && column_header_2[0].text}
              </th>
              <th className={column_header_3 && column_header_3[0].text && 'active'} key={createRandomId()}>
                {column_header_3 && column_header_3[0].text}
              </th>
              <th className={column_header_4 && column_header_4[0].text && 'active'} key={createRandomId()}>
                {column_header_4 && column_header_4[0].text}
              </th>
              <th className={column_header_5 && column_header_5[0].text && 'active'} key={createRandomId()}>
                {column_header_5 && column_header_5[0].text}
              </th>
              <th className={column_header_6 && column_header_6[0].text && 'active'} key={createRandomId()}>
                {column_header_6 && column_header_6[0].text}
              </th>
            </tr>
          </thead>
          <tbody>
            {input.fields.map(row => {
              return (
                <>
                  <tr>
                    <th className={row.column_1 && row.column_1[0].text && 'active'}>
                      {row.column_1 && row.column_1[0].text ? (
                        <RichText linkResolver={linkResolver} render={row.column_1} />
                      ) : null}
                    </th>
                    <td className={row.column_2 && row.column_2[0].text && 'active'}>
                      {row.column_2 && row.column_2[0].text ? (
                        <RichText linkResolver={linkResolver} render={row.column_2} />
                      ) : null}
                    </td>
                    <td className={row.column_3 && row.column_3[0].text && 'active'}>
                      {row.column_3 && row.column_3[0].text ? (
                        <RichText linkResolver={linkResolver} render={row.column_3} />
                      ) : null}
                    </td>
                    <td className={row.column_4 && row.column_4[0].text && 'active'}>
                      {row.column_4 && row.column_4[0].text ? (
                        <RichText linkResolver={linkResolver} render={row.column_4} />
                      ) : null}
                    </td>
                    <td className={row.column_5 && row.column_5[0].text && 'active'}>
                      {row.column_5 && row.column_5[0].text ? (
                        <RichText linkResolver={linkResolver} render={row.column_5} />
                      ) : null}
                    </td>
                    <td className={row.column_6 && row.column_6[0].text && 'active'}>
                      {row.column_6 && row.column_6[0].text ? (
                        <RichText linkResolver={linkResolver} render={row.column_6} />
                      ) : null}
                    </td>
                  </tr>
                </>
              );
            })}
          </tbody>
        </BulmaTable>
      </BulmaContainer>
    </BulmaSection>
  );
};

export default Table;

Table.propTypes = {
  input: PropTypes.object.isRequired,
};
