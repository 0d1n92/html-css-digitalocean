// Styles here will override Bulma styles
import { css } from '@emotion/core';
import styled from '@emotion/styled';
import media from 'css-in-js-media';

export const styledSection = css`
  background: repeat;
  overflow: hidden;
  .container {
    justify-content: center;
    align-items: center;
    display: flex;
    flex-direction: column;
  }
`;

export const styledColumn = css`
  padding-bottom: 28px !important;

  ${media('< desktop')} {
    text-align: center !important;
    width: 80% !important;
    margin: 0 auto;
    padding-bottom: 12px !important;
    flex-direction: column;
    align-items: center;
  }
`;

export const StyledHeadingContainer = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-bottom: 30px;

  p {
    text-align: center;
  }
`;

export const styledHeading = css`
  text-align: center;
`;

export const styledSubheading = css`
  max-width: 670px;
  text-align: center;
`;

export const styledTable = css`
  border-collapse: collapse;
  border-spacing: 0;
  width: 100%;
  max-width: 876px;
  margin-top: 64px;

  ${media('< tablet')} {
    display: inline-block;
    overflow: scroll;
  }

  tr th {
    max-width: 500px !important;
  }

  li {
    margin-left: 18px;
  }

  p {
    margin: 5px 0;
  }

  thead,
  tbody {
    th,
    td {
      &.active {
        padding-right: 8px;
      }
      color: #5b6987;
      background: #fff !important;
      padding: 10px 0px;
      border-bottom: 1px solid #e5e8ed;
    }
  }

  tbody {
    th {
      font-weight: normal;
      min-width: 140px;
    }
    td {
      &.active {
        min-width: 180px;
      }
    }
  }
`;
