/* eslint-disable camelcase */
import React from 'react';
import PropTypes from 'prop-types';

import BulmaCard from 'react-bulma-components/lib/components/card';
import BulmaColumns from 'react-bulma-components/lib/components/columns';
import BulmaContainer from 'react-bulma-components/lib/components/container';
import BulmaHero from 'react-bulma-components/lib/components/hero';

import { css } from '@emotion/core';

import { createRandomId } from '../../util/createRandomId';
import { scrollToTargetElement } from '../../util/scrollToTargetElement';
import { Heading, Button, LazyLink, LazyImage } from '../atoms';

import {
  styledHeroBoxSection,
  styledHeroBoxWrapper,
  styledHeroBoxFullscreen,
  styledHeroBox,
  styledHeroBoxTitle,
  styledButton,
  StyledFeatureList,
  styledHero,
  StyledHeadings,
  StyledSmallHeading,
} from './HeroBoxStyles';

const renderHeading = (text, atts) => <Heading {...atts}>{text.text}</Heading>;

const renderBoxFeature = (feature, hero_box_text_color) => {
  const { hero_box_text_icon, hero_box_text } = feature;

  return (
    <li key={createRandomId()}>
      <div>
        <LazyImage alt={hero_box_text_icon.alt || 'text logo'} src={hero_box_text_icon.url} />
        <span style={{ color: hero_box_text_color || '#031b4e' }}>{hero_box_text[0].text}</span>
      </div>
    </li>
  );
};

const HeroBox = ({ input }) => {
  const {
    fullscreen,
    large_text,
    text_color,
    hero_background_color,
    hero_background_image,
    hero_small_heading,
    hero_small_heading_color,
    hero_small_heading_icon,
    hero_heading,
    hero_heading_color,
    hero_subheading,
    hero_subheading_color,
    hero_box_title,
    hero_box_title_color,
    hero_box_cta_text,
    hero_box_cta_url,
    hero_box_text_color,
    hero_box_cta_scroll_to_element_id,
  } = input.primary;

  return (
    <BulmaHero
      data-testid="bulma_hero"
      css={css`
        ${styledHeroBoxSection}
        ${fullscreen ? styledHeroBoxFullscreen : styledHeroBoxWrapper}
      `}
      style={{
        backgroundColor: hero_background_color || '#031b4e',
        backgroundImage:
          hero_background_image && hero_background_image.url ? `url(${hero_background_image.url})` : null,
      }}
    >
      <BulmaHero.Body>
        <BulmaContainer>
          <BulmaColumns>
            <BulmaColumns.Column css={styledHero} size={7}>
              <StyledHeadings>
                {hero_small_heading && hero_small_heading[0].text && (
                  <StyledSmallHeading>
                    {hero_small_heading_icon && hero_small_heading_icon.url && (
                      <LazyImage alt={hero_small_heading_icon.alt || 'text logo'} src={hero_small_heading_icon.url} />
                    )}
                    {renderHeading(hero_small_heading[0], {
                      style: hero_small_heading_color && { color: hero_small_heading_color },
                      className: text_color === 'light' ? 'h6 white' : 'h6 darkblue',
                      renderAs: 'h6',
                    })}
                  </StyledSmallHeading>
                )}
                {renderHeading(hero_heading[0], {
                  style: hero_heading_color ? { color: hero_heading_color } : null,
                  className: `${text_color === 'light' ? 'h1 white' : 'h1 darkblue'} ${large_text ? 'hero-title' : ''}`,
                  renderAs: 'h1',
                  'data-testid': 'hero_heading',
                })}
                {renderHeading(hero_subheading[0], {
                  style: hero_subheading_color && { color: hero_subheading_color },
                  className: text_color === 'light' ? 'large white' : 'large darkgrey',
                  subtitle: true,
                  renderAs: 'p',
                  'data-testid': 'hero_subheading',
                })}
              </StyledHeadings>
            </BulmaColumns.Column>
            <BulmaColumns.Column size={4}>
              <BulmaCard css={styledHeroBox} data-testid="hero_box">
                <BulmaCard.Header.Title css={styledHeroBoxTitle}>
                  {renderHeading(hero_box_title[0], {
                    className: 'h5 darkblue',
                    renderAs: 'h5',
                    style: hero_box_title_color ? { color: hero_box_title_color } : null,
                    'data-testid': 'hero_box_title',
                  })}
                </BulmaCard.Header.Title>
                <BulmaCard.Content>
                  <StyledFeatureList data-testid="hero_box_feature_list">
                    {input.fields.map(feature => renderBoxFeature(feature, hero_box_text_color))}
                  </StyledFeatureList>
                  <Button
                    data-testid="hero_box_cta_button"
                    color="primary"
                    renderAs={LazyLink}
                    css={styledButton}
                    url={hero_box_cta_url.url}
                    onClick={() =>
                      hero_box_cta_scroll_to_element_id && scrollToTargetElement(hero_box_cta_scroll_to_element_id)
                    }
                  >
                    {hero_box_cta_text[0].text}
                  </Button>
                </BulmaCard.Content>
              </BulmaCard>
            </BulmaColumns.Column>
          </BulmaColumns>
        </BulmaContainer>
      </BulmaHero.Body>
    </BulmaHero>
  );
};

export default HeroBox;

HeroBox.propTypes = {
  input: PropTypes.object.isRequired,
};
