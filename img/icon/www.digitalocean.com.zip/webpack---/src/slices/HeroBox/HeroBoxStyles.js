import { css } from '@emotion/core';
import media from 'css-in-js-media';
import styled from '@emotion/styled';

export const styledHeroBoxSection = css`
  background-repeat: no-repeat;
  background-position: bottom;
  background-size: cover;

  .column {
    margin: auto;
    display: flex;
    justify-content: center;
    flex-direction: column;
  }

  .hero-body {
    display: flex;
    align-items: center;
  }

  ${media('< largeDesktop')} {
    .is-7,
    is-4 {
      width: 38%;
    }
  }

  ${media('< desktop')} {
    height: auto;
    .columns {
      flex-direction: column;
    }
    .column {
      width: 100%;
    }
    .is-7,
    is-4 {
      width: 100%;
    }
  }

  ${media('< tablet')} {
    .columns {
      margin-right: 0;
    }
  }
`;

export const styledHeroBoxWrapper = css`
  padding: 3rem 1.5rem;
`;

export const styledHeroBoxFullscreen = css`
  height: 100vh;
  display: flex;
  flex-direction: column;
  justify-content: center;

  ${media('< desktop')} {
    height: 100vh;
  }
`;

export const styledHero = css`
  display: flex;
  justify-content: center;

  .title {
    margin-top: 40px;
    max-width: 670px;
  }

  .medium {
    margin-top: 20px;
    max-width: 670px;
    font-size: 24px !important;
  }

  ${media('< desktop')} {
    margin: auto !important;
    text-align: center;
  }
`;

export const StyledSmallHeading = styled.div`
  display: flex;

  h6 {
    letter-spacing: 1px !important;
    margin: 0;
    margin-top: 5px !important;
    text-transform: uppercase !important;
  }

  ${media('< desktop')} {
    margin-right: 0px;
    justify-content: center;
    h6 {
      margin-right: 10px !important;
    }
  }
`;

export const StyledHeadings = styled.div`
  display: flex;
  flex-direction: column;

  h1,
  p {
    margin: 0;
  }

  img {
    margin-right: 10px;
    height: 22px;
    width: 22px;
  }

  .title {
    word-break: normal;
  }

  ${media('< desktop')} {
    justify-content: center;
  }
`;

export const styledHeroBox = css`
  display: flex;
  flex-direction: column;
  align-items: center;
  min-width: 360px;
  margin: auto;
  border-radius: 6px;

  .card-content {
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    min-height: 220px;
    text-align: center;
    padding: 32px;
    width: 85%;
  }

  ${media('< tablet')} {
    min-width: 240px;
  }
`;

export const styledHeroBoxTitle = css`
  flex: 0 !important;
  width: 92.8%;
  justify-content: center;
  border-radius: 6px 6px 0px 0px;
  background-color: #f3f5f9;

  h5 {
    margin-top: 0px;
    display: flex;
    align-items: center;
    height: 36px;
  }

  ${media('< tablet')} {
    width: 90%;
  }
`;

export const StyledFeatureList = styled.ul`
  display: flex;
  justify-content: space-between;
  flex-direction: column;
  min-height: 115px;
  margin-left: 20px;
  text-align: left;
  list-style: none;

  img {
    width: 16px;
    height: 16px;
    margin-right: 16px;
  }

  li {
    margin-top: 10px;
  }

  div {
    display: flex;
    align-items: center;
  }
`;

export const styledButton = css`
  &.is-primary {
    width: 100%;
    margin: 25px auto 0px auto !important;
  }
`;
