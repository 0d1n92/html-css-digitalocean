/* eslint-disable camelcase */
import React from 'react';
import PropTypes from 'prop-types';

import BulmaBox from 'react-bulma-components/lib/components/box';
import BulmaSection from 'react-bulma-components/lib/components/section';

import { css } from '@emotion/core';
import { RichText } from 'prismic-reactjs';
import { linkResolver } from '../../util/linkResolver';

import { SlidingTabsContainer, SlidingTab, Heading, Quote } from '../atoms';

import {
  styledSubheading,
  styledHeading,
  styledCardContent,
  styledContent,
  styledContentSubtitle,
  styledContentTitle,
  styledCard,
} from './LeftSlidingNavContentStyles';

const renderQuoteCard = (quote, quote_author_image, quote_author_name, quote_author_details) => (
  <BulmaBox renderAs="div" css={styledCard}>
    <div css={styledCardContent}>
      <Quote
        quoteProps={{
          avatar: quote_author_image,
          quote,
          author: quote_author_name,
          author_details: quote_author_details,
        }}
      />
    </div>
  </BulmaBox>
);

const LeftSlidingNavContent = ({ input }) => {
  const { background_image, background_color, text_color } = input.primary;

  return (
    <BulmaSection
      css={css`
        background-image: url(${background_image ? background_image.url : ''});
        background-color: ${background_color};
      `}
    >
      <SlidingTabsContainer text_color={text_color}>
        {input.fields.map(item => (
          <SlidingTab key={`tabbed-content-${item.heading[0].text}`} label={item.heading[0].text}>
            {item.heading ? (
              <Heading
                id="testLeftSlidingNavHeading"
                style={item.heading_color ? { color: item.heading_color } : null}
                className={text_color === 'light' ? 'h3 grey light' : 'h3 darkblue light'}
                renderAs="h3"
                css={styledHeading}
              >
                {item.heading[0].text}
              </Heading>
            ) : null}
            {item.subheading && item.subheading[0] && item.subheading[0].text ? (
              <Heading
                id="testLeftSlidingNavSubheading"
                style={item.subheading_color ? { color: item.subheading_color } : null}
                subtitle
                className={text_color === 'light' ? 'h4 grey light' : 'h4 darkblue light'}
                renderAs="h4"
                css={styledSubheading}
              >
                {item.subheading[0].text}
              </Heading>
            ) : null}
            {item.content_title && item.content_title[0] && item.content_title[0].text ? (
              <Heading
                id="testLeftSlidingNavHeading"
                className={text_color === 'light' ? 'h4 grey light' : 'h4 darkblue light'}
                renderAs="h4"
                css={styledContentTitle}
              >
                {item.content_title[0].text}
              </Heading>
            ) : null}
            {item.content_subtitle && item.content_subtitle[0] && item.content_subtitle[0].text ? (
              <p css={styledContentSubtitle}>{item.content_subtitle[0].text}</p>
            ) : null}
            {item.copy && item.copy[0] ? (
              <div css={styledContent} className={!item.quote || !item.quote[0].text ? 'no-quote' : ''}>
                <RichText render={item.copy} linkResolver={linkResolver} />
              </div>
            ) : null}
            {item.quote && item.quote[0] && item.quote[0].text
              ? renderQuoteCard(item.quote, item.quote_author_image, item.quote_author_name, item.quote_author_details)
              : null}
            {item.quote_2 && item.quote_2[0] && item.quote_2[0].text
              ? renderQuoteCard(
                  item.quote_2,
                  item.quote_author_image_2,
                  item.quote_author_name_2,
                  item.quote_author_details_2,
                )
              : null}
            {item.quote_3 && item.quote_3[0] && item.quote_3[0].text
              ? renderQuoteCard(
                  item.quote_3,
                  item.quote_author_image_3,
                  item.quote_author_name_3,
                  item.quote_author_details_3,
                )
              : null}
            {item.quote_4 && item.quote_4[0] && item.quote_4[0].text
              ? renderQuoteCard(
                  item.quote_4,
                  item.quote_author_image_4,
                  item.quote_author_name_4,
                  item.quote_author_details_4,
                )
              : null}
          </SlidingTab>
        ))}
      </SlidingTabsContainer>
    </BulmaSection>
  );
};

export default LeftSlidingNavContent;

LeftSlidingNavContent.propTypes = {
  input: PropTypes.object.isRequired,
};
