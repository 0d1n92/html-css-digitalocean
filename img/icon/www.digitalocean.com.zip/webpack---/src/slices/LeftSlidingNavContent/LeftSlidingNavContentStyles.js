import { css } from '@emotion/core';
import media from 'css-in-js-media';

export const styledHeading = css`
  text-align: left;
  font-size: 1.7rem;
  margin: 0 !important;
`;

export const styledSubheading = css`
  margin: 20px 0 0 0 !important;
  text-align: left;
  ${media('> tablet')} {
    margin-bottom: 40px !important;
  }
`;

export const styledCard = css`
  margin-top: 20px;
  margin-bottom: 40px;
`;

export const styledCardContent = css`
  position: relative;
  height: 100%;
  padding: 20px;
  .title {
    margin-top: 15px;
  }
  img {
    margin-bottom: 10px;
  }
  ${media('<= desktop')} {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
  }
`;

export const styledButton = css`
  margin-top: 60px;
  margin-bottom: 40px;
`;

export const styledContent = css`
  max-width: 860px;
  color: #031b4e;
  ${media('< tablet')} {
    padding: 0px;
  }
  h1,
  h2,
  h3,
  h4,
  h5,
  h6 {
    font-family: 'Sailec-Bold';
    font-weight: 400;
  }
  h2,
  h3,
  h4,
  h5,
  h6 {
    line-height: 1.3;
    margin: 3rem 0 0;
  }
  h1 {
    font-size: 2.4rem;
  }
  h2 {
    font-size: 1.7rem;
  }
  h3 {
    font-size: 1.3rem;
  }
  img {
    max-width: 100%;
  }
  ul {
    margin: 16px 0 64px 0;
    padding-left: 32px;
    color: #5b6987;
    font-size: 16px;
    line-height: 160%;
    font-weight: 400;
  }
  li {
    margin: 0.25rem 0;
  }
  a {
    color: #0069ff;
    text-decoration: underline;
    text-decoration-skip-ink: auto;
    font-family: 'Sailec-Regular';
    font-weight: normal;
  }
  p {
    margin-top: 20px;
  }

  &.no-quote {
    margin-bottom: 64px;
  }
`;

export const styledContentTitle = css`
  margin: 48px 0 0 0 !important;
  text-align: left;
`;

export const styledContentSubtitle = css`
  margin: 20px 0 0 0 !important;
  text-align: left;
`;
