/* eslint-disable camelcase */
import React from 'react';
import PropTypes from 'prop-types';

import BulmaColumns from 'react-bulma-components/lib/components/columns';
import BulmaContainer from 'react-bulma-components/lib/components/container';
import BulmaSection from 'react-bulma-components/lib/components/section';

import { createRandomId } from '../../util/createRandomId';
import { Heading } from '../atoms';

import { styledSection, styledHeading, styledSubheading, styledStatsColumns, StyledStat } from './StatisticsStyles';

const renderHeading = (text, atts) => (
  <Heading {...atts} css={atts.css}>
    {text.text}
  </Heading>
);

const renderStat = (stat, defaultTextColor, titleColor, detailColor) => {
  const { stat_detail, stat_title } = stat;

  return (
    <BulmaColumns.Column key={createRandomId()}>
      <StyledStat>
        {renderHeading(stat_title[0], {
          style: titleColor ? { color: titleColor } : null,
          className: defaultTextColor === 'light' ? 'h4 white' : 'h4 darkblue',
          renderAs: 'h4',
          'data-testid': 'stat_title',
        })}
        {renderHeading(stat_detail[0], {
          style: detailColor ? { color: detailColor } : null,
          className: defaultTextColor === 'light' ? 'tiny transparentWhite' : 'tiny darkgrey',
          renderAs: 'p',
          subtitle: true,
          'data-testid': 'stat_detail',
        })}
      </StyledStat>
    </BulmaColumns.Column>
  );
};

const Statistics = ({ input }) => {
  const {
    background_color,
    background_image,
    heading,
    heading_color,
    stat_detail_color,
    stat_title_color,
    subheading_color,
    subheading,
    text_color,
  } = input.primary;

  return (
    <BulmaSection
      css={styledSection}
      style={{
        backgroundColor: background_color || '#031B4E',
        backgroundImage: background_image && background_image.url ? `url(${background_image.url})` : null,
      }}
    >
      <BulmaContainer>
        {heading &&
          heading[0].text &&
          renderHeading(heading[0], {
            style: heading_color ? { color: heading_color } : null,
            css: styledHeading,
            className: text_color === 'light' ? 'white' : 'darkblue',
            renderAs: 'h1',
          })}
        {subheading &&
          subheading[0].text &&
          renderHeading(subheading[0], {
            style: subheading_color ? { color: subheading_color } : null,
            css: styledSubheading,
            className: text_color === 'light' ? 'h2 white medium' : 'h2 darkgrey medium',
            subtitle: true,
            renderAs: 'h2',
          })}
        <BulmaColumns css={styledStatsColumns}>
          {input.fields.map(statistic => renderStat(statistic, text_color, stat_title_color, stat_detail_color))}
        </BulmaColumns>
      </BulmaContainer>
    </BulmaSection>
  );
};

export default Statistics;

Statistics.propTypes = {
  input: PropTypes.object.isRequired,
};
