// Styles here will override Bulma styles
import styled from '@emotion/styled';
import { css } from '@emotion/core';
import media from 'css-in-js-media';

export const styledSection = css`
  min-height: 200px;
  display: flex;
  align-items: center;
  padding-top: 64px;
  padding-bottom: 64px;
  background-size: cover;
`;

export const styledStatsColumns = css`
  max-width: 960px;
  margin: 20px auto !important;

  ${media('< desktop')} {
    flex-direction: column;
    .column:not(:first-of-type) {
      margin-top: 25px;
    }
  }
`;

export const styledHeading = css`
  margin: 60px auto 0 auto;
  text-align: center;
`;

export const styledSubheading = css`
  margin: 20px auto 60px auto !important;
  max-width: 670px;
  text-align: center;
`;

export const styledTitle = css`
  ${media('< desktop')} {
    width: 90%;
    margin: 0 auto;
    text-align: center;
  }
`;

export const StyledStat = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;

  h4 {
    margin-top: 0px;
  }

  h6 {
    text-transform: uppercase;
    text-align: center;
    margin-top: 8px;
  }
`;
