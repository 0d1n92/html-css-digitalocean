/* eslint-disable camelcase */
import React from 'react';
import PropTypes from 'prop-types';

import BulmaContainer from 'react-bulma-components/lib/components/container';
import BulmaSection from 'react-bulma-components/lib/components/section';

import { createRandomId } from '../../util/createRandomId';
import { Heading, TextLink } from '../atoms';

import {
  styledHeading,
  styledSubheading,
  StyledGridContainer,
  StyledLocationsList,
  StyledLocationName,
  StyledServerName,
  StyledTextLive,
} from './LocationsStyles';

const renderLocationItem = (locationItem, locationServerNameColor, locationNameColor, locationLinkTextColor) => {
  const { location_name, location_server_name, location_link_text, location_link_url } = locationItem;
  return (
    <li key={createRandomId()}>
      <StyledServerName data-testid="location_server_name" color={locationServerNameColor || '#fff'}>
        {location_server_name}
      </StyledServerName>
      <StyledLocationName data-testid="location_name" color={locationNameColor || '#fff'}>
        {location_name}
      </StyledLocationName>
      {location_link_url && location_link_url.url ? (
        <TextLink
          style={{ color: locationLinkTextColor || '#00d7d2' }}
          className={location_link_url && location_link_url.url ? 'arrow medium' : 'medium'}
          url={location_link_url && location_link_url.url ? location_link_url.url : null}
          data-testid="link_text"
        >
          {location_link_text}
        </TextLink>
      ) : (
        <StyledTextLive
          style={{ color: locationLinkTextColor || '#00d7d2' }}
          className="medium"
          data-testid="link_text"
        >
          {location_link_text}
        </StyledTextLive>
      )}
    </li>
  );
};

const Locations = ({ input }) => {
  const {
    text_color,
    heading,
    heading_color,
    subheading,
    subheading_color,
    background_image,
    background_color,
    location_server_name_color,
    location_name_color,
    location_link_text_color,
  } = input.primary;
  const { fields } = input;

  return (
    <BulmaSection
      style={{
        background:
          `${background_color} url(${background_image && background_image.url})` ||
          '#031b4e'`url(${background_image && background_image.url})`,
        backgroundPosition: '50% 50%',
        backgroundRepeat: 'no-repeat',
        backgroundSize: 'cover',
      }}
    >
      <BulmaContainer>
        {heading && heading[0].text ? (
          <Heading
            style={heading_color ? { color: heading_color } : null}
            css={styledHeading}
            className={text_color === 'light' ? 'h2 white' : 'h2 darkblue'}
            renderAs="h2"
          >
            {heading[0].text}
          </Heading>
        ) : null}
        {subheading && subheading[0].text ? (
          <Heading
            style={subheading_color ? { color: subheading_color } : null}
            css={styledSubheading}
            className={text_color === 'light' ? 'medium white subtitle' : 'medium darkgrey subtitle'}
          >
            {subheading}
          </Heading>
        ) : null}
        <StyledGridContainer>
          <StyledLocationsList>
            {fields.map(location =>
              renderLocationItem(location, location_server_name_color, location_name_color, location_link_text_color),
            )}
          </StyledLocationsList>
        </StyledGridContainer>
      </BulmaContainer>
    </BulmaSection>
  );
};

export default Locations;

Locations.propTypes = {
  input: PropTypes.object.isRequired,
};
