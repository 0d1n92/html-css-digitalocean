// Styles here will override Bulma styles
import styled from '@emotion/styled';
import { css } from '@emotion/core';
import media from 'css-in-js-media';

export const styledSection = css`
  background-repeat: repeat;
  margin-top: 60px;
`;

export const styledHeading = css`
  text-align: center;
  max-width: 700px;
  margin: 0 auto;
`;

export const styledSubheading = css`
  margin: 20px auto 60px auto !important;
  max-width: 670px;
  text-align: center;
`;

export const StyledGridContainer = styled.div`
  margin-top: 64px;
`;

export const StyledLocationsList = styled.ul`
  display: grid;
  grid-auto-flow: dense;
  grid-auto-rows: 1fr;
  grid-gap: 0px 30px;
  grid-template-columns: repeat(2, minmax(220px, 1fr));
  margin: auto;

  li {
    display: flex;
    align-items: center;
    justify-content: space-between;
    height: 40px;
    border-bottom: 1px solid hsla(0, 0%, 100%, 0.2);
  }

  li:nth-last-of-type(-n + 2) {
    border-bottom: none;
  }

  li span {
    font-size: 13px;
    width: 80px;
    margin-left: 10px;
  }

  li a {
    text-align: center;
    width: 95px;
    font-size: 12px;
  }

  li div,
  li p {
    font-size: 13px;
    text-align: left;
    margin-left: 0px;
    width: 350px;
  }

  li div {
    text-align: right;
  }

  ${media('< desktop')} {
    display: flex;
    flex-direction: column;
    margin-left: 0px;
    margin-right: 0px;

    li:nth-last-of-type(-n + 2) {
      border-bottom: 1px solid hsla(0, 0%, 100%, 0.2);
    }

    li:last-of-type {
      border-bottom: none !important;
    }

    li {
      margin: auto;
    }
  }

  ${media('< tablet')} {
    margin-left: -10px;
    li p {
      width: 125px;
    }
  }
`;

export const StyledLocationName = styled.p`
  color: ${props => props.color};
  opacity: 0.6;
`;

export const StyledServerName = styled.span`
  font-family: 'Sailec-Bold', 'Helvetica', 'sans-serif';
  color: ${props => props.color};
`;

export const StyledTextLive = styled.p`
  text-align: right !important;
`;
