/* eslint-disable */

import React, { useState, useEffect } from 'react';
import { graphql } from 'gatsby';
import { Helmet } from 'react-helmet';
import PropTypes from 'prop-types';

import { MainLayout } from '../layouts';

import { SliceZone } from '../components';

import Cookies from 'js-cookie';
import { HeroHomeForm } from '../slices';

export const query = graphql`
  query HomeQuery($uid: String!) {
    prismic {
      home(lang: "en-us", uid: $uid) {
        _meta {
          lang
          lastPublicationDate
          type
          uid
        }
        body {
        ... on PRISMIC_HomeBodyHerohomeform {
          type
label
primary {
  fullscreen
  background_color
  background_image
  large_text
  email_placeholder
  form_title
  headline
  headline_color
  name_placeholder
  password_placeholder
  subheadline
  subheadline_color
  submit_button_text
  subscript
  text_color
}
fields {
  button_link {
    ... on PRISMIC__ExternalLink {
      _linkType
      url
    }
  }
  button_text
  icon
}
        },
        ... on PRISMIC_HomeBodyLogogrid {
          type
            label
            fields {
              logo
            }
            primary {
              text_color
              autoScroll
              background_color
              cta_link {
                ... on PRISMIC__ExternalLink {
                  _linkType
                  url
                }
              }
              cta_text
              heading
              heading_color
              subheading
              subheading_color
              scroll_speed
            }
        },
        ... on PRISMIC_HomeBodyTabbedcontent {
          type
            label
            primary {
              background_color
              text_color
              heading
              heading_color
              subheading
              subheading_color
              background_image
            }
            fields {
              content1
              content2
              content3
              content4
              tab_label
              label_color
              content_color
            }
        },
        ... on PRISMIC_HomeBodyCarouselimage {
          type
            primary {
              background_color
              background_image
              text_color
              heading
              heading_color
              subheading
              subheading_color
            }
            fields {
              image
              image_text
              image_text_color
            }
        },
        ... on PRISMIC_HomeBodyCarouseltestimonial {
          type
            label
            primary {
              background_color
              background_image
              text_color
              heading
              heading_color
              subheading1
              subheading_color
            }
            fields {
              logo
              quote
              author
              author_details
              avatar
              link {
                ... on PRISMIC__ExternalLink {
                  _linkType
                  url
                }
              }
              link_text
            }
        },
        ... on PRISMIC_HomeBodyListgridv2 {
          type
            label
            primary {
              background_color
              background_image
              heading
              heading_color
              list_column_number
              list_item_alignment_position
              list_item_heading_color
              list_item_text_color
              list_item_icon_position
              list_item_icon_size
              subheading
              subheading_color
              text_color
              cta_button_text
              cta_button_url {
                ... on PRISMIC__ExternalLink {
                  _linkType
                  url
                }
              }
              annotation
            }
            fields {
              list_item_heading
              list_item_icon
              list_item_text
              list_item_url_link {
                ... on PRISMIC__ExternalLink {
                  _linkType
                  url
                }
              }
              list_item_url_text
            }
        },
        ... on PRISMIC_HomeBodyLocations {
          type
            label
            fields {
              location_name
              location_server_name
              location_link_text
              location_link_url {
                ... on PRISMIC__ExternalLink {
                  _linkType
                  url
                }
              }
            }
            primary {
              background_color
              background_image
              column_number
              heading_color
              heading
              subheading
              subheading_color
              text_color
              location_name_color
              location_server_name_color
              location_link_text_color
            }
        },
        ... on PRISMIC_HomeBodyCtaband {
          type
            label
            primary {
              text_color
              background_color
              cta_band
              cta_primary_background_color
              cta_text_primary
              cta_text_secondary
              cta_url_primary {
                ... on PRISMIC__ExternalLink {
                  _linkType
                  url
                }
              }
              cta_url_secondary {
                ... on PRISMIC__ExternalLink {
                  _linkType
                  url
                }
              }
              heading
              subheading
              background_image
            }
        },
        ... on PRISMIC_HomeBodyPromoband {
          type
label
primary {
  background_color
  cta_button_link {
    ... on PRISMIC__ExternalLink {
      _linkType
      url
    }
  }
  cta_button_text
  heading
  heading_color
  icon
  subheading
  subheading_color
}

        }}
        date
        description
        path
        title
        open_graph_image
      }
    }
  }
`;

// HOMEPAGE HERO MESSAGING HARDCODED EXPERIMENT
// 10-23-2020 - 11-06-2020
// Do not remove!

const dataControl = {
  "type": "herohomeform",
  "label": null,
  "fields": [
    {
      "button_link": {
        "target": null,
        "_linkType": "Link.web",
        "url": "https://cloud.digitalocean.com/registrations/google"
      },
      "button_text": "Sign up with Google",
      "icon": {
        "dimensions": {
          "width": 18,
          "height": 18
        },
        "alt": null,
        "copyright": null,
        "url": "https://prismic-io.s3.amazonaws.com/www-static/8d18ab05-0db4-4fd7-95d1-c5fbc4b83fc2_icon-google.svg"
      }
    },
    {
      "button_link": {
        "target": null,
        "_linkType": "Link.web",
        "url": "https://cloud.digitalocean.com/registrations/github"
      },
      "button_text": null,
      "icon": {
        "dimensions": {
          "width": 18,
          "height": 18
        },
        "alt": null,
        "copyright": null,
        "url": "https://prismic-io.s3.amazonaws.com/www-static/ae808fab-d9d7-458e-b368-05344b7ad308_icon-github.svg"
      }
    }
  ],
  "primary": {
    "background_color": "#0069ff",
    "background_image": null,
    "email_placeholder": "Email address",
    "form_title": [
      {
        "type": "heading1",
        "text": "Deploy in seconds",
        "spans": []
      }
    ],
    "fullscreen": false,
    "headline": [
      {
        "type": "heading1",
        "text": "Welcome to the developer cloud",
        "spans": []
      }
    ],
    "headline_color": null,
    "large_text": true,
    "name_placeholder": "Name",
    "password_placeholder": "Create a password",
    "subheadline": [
      {
        "type": "paragraph",
        "text": "We make it simple to launch in the cloud and scale up as you grow – with an intuitive control panel, predictable pricing, team accounts, and more.",
        "spans": []
      }
    ],
    "subheadline_color": null,
    "submit_button_text": "Sign up with email",
    "subscript": [
      {
        "type": "paragraph",
        "text": "By signing up you agree to the Terms of Service.",
        "spans": [
          {
            "start": 31,
            "end": 47,
            "type": "hyperlink",
            "data": {
              "link_type": "Web",
              "url": "https://www.digitalocean.com/legal/terms-of-service-agreement/"
            }
          }
        ]
      }
    ],
    "text_color": "light"
  }
};

const dataTreatment_A = {
  "type": "herohomeform",
  "label": null,
  "fields": [
    {
      "button_link": {
        "target": null,
        "_linkType": "Link.web",
        "url": "https://cloud.digitalocean.com/registrations/google"
      },
      "button_text": "Sign up with Google",
      "icon": {
        "dimensions": {
          "width": 18,
          "height": 18
        },
        "alt": null,
        "copyright": null,
        "url": "https://prismic-io.s3.amazonaws.com/www-static/8d18ab05-0db4-4fd7-95d1-c5fbc4b83fc2_icon-google.svg"
      }
    },
    {
      "button_link": {
        "target": null,
        "_linkType": "Link.web",
        "url": "https://cloud.digitalocean.com/registrations/github"
      },
      "button_text": null,
      "icon": {
        "dimensions": {
          "width": 18,
          "height": 18
        },
        "alt": null,
        "copyright": null,
        "url": "https://prismic-io.s3.amazonaws.com/www-static/ae808fab-d9d7-458e-b368-05344b7ad308_icon-github.svg"
      }
    }
  ],
  "primary": {
    "background_color": "#0069ff",
    "background_image": {
      "url": "https://prismic-io.s3.amazonaws.com/www-static/5315ae46-6bc4-49fe-aa85-a434f9066bd4_bg-home-3.svg"
    },
    "email_placeholder": "Email address",
    "form_title": [
      {
        "type": "heading1",
        "text": "Deploy in seconds",
        "spans": []
      }
    ],
    "fullscreen": false,
    "headline": [
      {
        "type": "heading1",
        "text": "Every developer's cloud",
        "spans": []
      }
    ],
    "headline_color": null,
    "large_text": true,
    "name_placeholder": "Name",
    "password_placeholder": "Create a password",
    "subheadline": [
      {
        "type": "paragraph",
        "text": "A complete set of infrastructure and fully managed platform services for all your development needs – with an intuitive control panel, powerful performance, and predictable pricing.",
        "spans": []
      }
    ],
    "subheadline_color": null,
    "submit_button_text": "Sign up with email",
    "subscript": [
      {
        "type": "paragraph",
        "text": "By signing up you agree to the Terms of Service.",
        "spans": [
          {
            "start": 31,
            "end": 47,
            "type": "hyperlink",
            "data": {
              "link_type": "Web",
              "url": "https://www.digitalocean.com/legal/terms-of-service-agreement/"
            }
          }
        ]
      }
    ],
    "text_color": "light"
  }
};

const dataTreatment_B = {
  "type": "herohomeform",
  "label": null,
  "fields": [
    {
      "button_link": {
        "target": null,
        "_linkType": "Link.web",
        "url": "https://cloud.digitalocean.com/registrations/google"
      },
      "button_text": "Sign up with Google",
      "icon": {
        "dimensions": {
          "width": 18,
          "height": 18
        },
        "alt": null,
        "copyright": null,
        "url": "https://prismic-io.s3.amazonaws.com/www-static/8d18ab05-0db4-4fd7-95d1-c5fbc4b83fc2_icon-google.svg"
      }
    },
    {
      "button_link": {
        "target": null,
        "_linkType": "Link.web",
        "url": "https://cloud.digitalocean.com/registrations/github"
      },
      "button_text": null,
      "icon": {
        "dimensions": {
          "width": 18,
          "height": 18
        },
        "alt": null,
        "copyright": null,
        "url": "https://prismic-io.s3.amazonaws.com/www-static/ae808fab-d9d7-458e-b368-05344b7ad308_icon-github.svg"
      }
    }
  ],
  "primary": {
    "background_color": "#0069ff",
    "background_image": {
      "url": "https://prismic-io.s3.amazonaws.com/www-static/5315ae46-6bc4-49fe-aa85-a434f9066bd4_bg-home-3.svg"
    },
    "email_placeholder": "Email address",
    "form_title": [
      {
        "type": "heading1",
        "text": "Deploy in seconds",
        "spans": []
      }
    ],
    "fullscreen": false,
    "headline": [
      {
        "type": "heading1",
        "text": "For developers of all backgrounds & apps of any scale",
        "spans": []
      }
    ],
    "headline_color": null,
    "large_text": true,
    "name_placeholder": "Name",
    "password_placeholder": "Create a password",
    "subheadline": [
      {
        "type": "paragraph",
        "text": "Prototypes, simple apps, business-critical websites, massive container-based applications, and more – we support all your cloud needs through infrastructure and platform services that are simple to use, reliable, and affordable.",
        "spans": []
      }
    ],
    "subheadline_color": null,
    "submit_button_text": "Sign up with email",
    "subscript": [
      {
        "type": "paragraph",
        "text": "By signing up you agree to the Terms of Service.",
        "spans": [
          {
            "start": 31,
            "end": 47,
            "type": "hyperlink",
            "data": {
              "link_type": "Web",
              "url": "https://www.digitalocean.com/legal/terms-of-service-agreement/"
            }
          }
        ]
      }
    ],
    "text_color": "light"
  }
};

const dataTreatment_C = {
  "type": "herohomeform",
  "label": null,
  "fields": [
    {
      "button_link": {
        "target": null,
        "_linkType": "Link.web",
        "url": "https://cloud.digitalocean.com/registrations/google"
      },
      "button_text": "Sign up with Google",
      "icon": {
        "dimensions": {
          "width": 18,
          "height": 18
        },
        "alt": null,
        "copyright": null,
        "url": "https://prismic-io.s3.amazonaws.com/www-static/8d18ab05-0db4-4fd7-95d1-c5fbc4b83fc2_icon-google.svg"
      }
    },
    {
      "button_link": {
        "target": null,
        "_linkType": "Link.web",
        "url": "https://cloud.digitalocean.com/registrations/github"
      },
      "button_text": null,
      "icon": {
        "dimensions": {
          "width": 18,
          "height": 18
        },
        "alt": null,
        "copyright": null,
        "url": "https://prismic-io.s3.amazonaws.com/www-static/ae808fab-d9d7-458e-b368-05344b7ad308_icon-github.svg"
      }
    }
  ],
  "primary": {
    "background_color": "#0069ff",
    "background_image": {
      "url": "https://prismic-io.s3.amazonaws.com/www-static/5315ae46-6bc4-49fe-aa85-a434f9066bd4_bg-home-3.svg"
    },
    "email_placeholder": "Email address",
    "form_title": [
      {
        "type": "heading1",
        "text": "Deploy in seconds",
        "spans": []
      }
    ],
    "fullscreen": false,
    "headline": [
      {
        "type": "heading1",
        "text": "The simplest, most powerful cloud",
        "spans": []
      }
    ],
    "headline_color": null,
    "large_text": true,
    "name_placeholder": "Name",
    "password_placeholder": "Create a password",
    "subheadline": [
      {
        "type": "paragraph",
        "text": "For individual developers, tech startups, and SMBs, DigitalOcean’s cloud infrastructure and fully managed services simplify app development with an intuitive control panel and powerful performance – all with predictable, competitive pricing.",
        "spans": []
      }
    ],
    "subheadline_color": null,
    "submit_button_text": "Sign up with email",
    "subscript": [
      {
        "type": "paragraph",
        "text": "By signing up you agree to the Terms of Service.",
        "spans": [
          {
            "start": 31,
            "end": 47,
            "type": "hyperlink",
            "data": {
              "link_type": "Web",
              "url": "https://www.digitalocean.com/legal/terms-of-service-agreement/"
            }
          }
        ]
      }
    ],
    "text_color": "light"
  }
};

const dataTreatment_D = {
  "type": "herohomeform",
  "label": null,
  "fields": [
    {
      "button_link": {
        "target": null,
        "_linkType": "Link.web",
        "url": "https://cloud.digitalocean.com/registrations/google"
      },
      "button_text": "Sign up with Google",
      "icon": {
        "dimensions": {
          "width": 18,
          "height": 18
        },
        "alt": null,
        "copyright": null,
        "url": "https://prismic-io.s3.amazonaws.com/www-static/8d18ab05-0db4-4fd7-95d1-c5fbc4b83fc2_icon-google.svg"
      }
    },
    {
      "button_link": {
        "target": null,
        "_linkType": "Link.web",
        "url": "https://cloud.digitalocean.com/registrations/github"
      },
      "button_text": null,
      "icon": {
        "dimensions": {
          "width": 18,
          "height": 18
        },
        "alt": null,
        "copyright": null,
        "url": "https://prismic-io.s3.amazonaws.com/www-static/ae808fab-d9d7-458e-b368-05344b7ad308_icon-github.svg"
      }
    }
  ],
  "primary": {
    "background_color": "#0069ff",
    "background_image": {
      "url": "https://prismic-io.s3.amazonaws.com/www-static/5315ae46-6bc4-49fe-aa85-a434f9066bd4_bg-home-3.svg"
    },
    "email_placeholder": "Email address",
    "form_title": [
      {
        "type": "heading1",
        "text": "Deploy in seconds",
        "spans": []
      }
    ],
    "fullscreen": false,
    "headline": [
      {
        "type": "heading1",
        "text": "Simplify your workflow",
        "spans": []
      }
    ],
    "headline_color": null,
    "large_text": true,
    "name_placeholder": "Name",
    "password_placeholder": "Create a password",
    "subheadline": [
      {
        "type": "paragraph",
        "text": "Spend less time worrying about your infrastructure, and more time shipping features. DigitalOcean's cloud and fully managed services enable streamlined app development with powerful performance and predictable, competitive pricing.",
        "spans": []
      }
    ],
    "subheadline_color": null,
    "submit_button_text": "Sign up with email",
    "subscript": [
      {
        "type": "paragraph",
        "text": "By signing up you agree to the Terms of Service.",
        "spans": [
          {
            "start": 31,
            "end": 47,
            "type": "hyperlink",
            "data": {
              "link_type": "Web",
              "url": "https://www.digitalocean.com/legal/terms-of-service-agreement/"
            }
          }
        ]
      }
    ],
    "text_color": "light"
  }
};

const Home = ({ data, location }) => {
  const [isClient, setClient] = useState(false);

  useEffect(() => {
    setClient(true);
  }, []);

  if (isClient) {
    window && window.analytics && window.analytics.track('Experiment Viewed', {
      action: 'Experiment Viewed',
      experiment_id: 'home_hero_messaging_10_22_2020',
      variation_name: `${Cookies.get('home_hero_messaging_10_22_2020')}`
    });
  }

  return data.prismic.home ? (
    <MainLayout location={location} layout='home'>
    <Helmet>
      <title>{(data.prismic.home.title[0] && data.prismic.home.title[0].text) || 'DigitalOcean'}</title>
      <link rel="canonical" href={data.prismic.home.path  == '/' ? 'https://www.digitalocean.com' + data.prismic.home.path : 'https://www.digitalocean.com' + data.prismic.home.path + '/'} />
      <meta
        name="description"
        content={
          data.prismic.home.description ||
          'Helping millions of developers easily build, test, manage, and scale applications of any size – faster than ever before.'
        }
      />
      <meta name="twitter:card" content="summary"/>
      <meta name="twitter:title" content={data.prismic.home.title[0] ? data.prismic.home.title[0].text : 'DigitalOcean'} />
      <meta name="twitter:description" content={data.prismic.home.description ? data.prismic.home.description : 'DigitalOcean'} />
      <meta name="twitter:image" property={data.prismic.home.open_graph_image ? data.prismic.home.open_graph_image.url : 'https://images.prismic.io/www-static/0026a57b93abe5b04413765253903472dab58e11_general-droplets_blog-v4_twitter---facebook.png?auto=compress,format'} />
      <meta property="og:type" content="website" />
      <meta property="og:description" content={data.prismic.home.description ? data.prismic.home.description : 'DigitalOcean'} />
      <meta property="og:title" content={data.prismic.home.title[0] ? data.prismic.home.title[0].text : 'DigitalOcean'} />
      <meta property="og:url" content={data.prismic.home.path  == '/' ? 'https://www.digitalocean.com' + data.prismic.home.path : 'https://www.digitalocean.com' + data.prismic.home.path + '/'} />
      <meta property="og:image:width" content="1200" />
      <meta property="og:image:height" content="600" />
      <meta property="og:image" content={data.prismic.home.open_graph_image ? data.prismic.home.open_graph_image.url : 'https://images.prismic.io/www-static/0026a57b93abe5b04413765253903472dab58e11_general-droplets_blog-v4_twitter---facebook.png?auto=compress,format'} />
    </Helmet>
      {isClient
          ? (Cookies.get('home_hero_messaging_10_22_2020') === 'treatment_A'
            ? <HeroHomeForm input={dataTreatment_A} />
            : Cookies.get('home_hero_messaging_10_22_2020') === 'treatment_B'
              ? <HeroHomeForm input={dataTreatment_B} />
              : Cookies.get('home_hero_messaging_10_22_2020') === 'treatment_C'
                ? <HeroHomeForm input={dataTreatment_C} />
                : Cookies.get('home_hero_messaging_10_22_2020') === 'treatment_D'
                  ? <HeroHomeForm input={dataTreatment_D} />
                  : <HeroHomeForm input={dataControl} />)
          : null}
      <SliceZone allSlices={data.prismic.home.body} />
    </MainLayout>
  ) : null;
}

Home.propTypes = {
  data: PropTypes.object.isRequired,
};

export default Home;
