import styled from '@emotion/styled';
import media from 'css-in-js-media';

export const StyledMainLayout = styled.div`
  /* ANNOUNCEMENTBAR STYLES MOBILE*/
  /* set universal padding-top for all inital slices on tablet and mobile media sizes to account for when there is an announcement bar */
  .slices {
    ${media('< desktop')} {
      position: relative;
      section:first-of-type {
        padding-top: 80px;
      }
    }
  }
  /* 404 STYLES */
  .error404 {
    max-width: 1170px;
    margin: 200px auto 140px auto;
    text-align: center;
    ${media('< desktop')} {
      margin: 100px 40px;
    }
    h2 {
      margin-top: 60px;
    }
    p {
      font-size: 20px;
    }
    a {
      color: #0069ff;
      cursor: pointer;
      font-weight: bold;
      text-decoration: underline;
      letter-spacing: 1px;
      :hover {
        color: #005fe6 !important;
      }
    }
    /* Water animation for 404 */
    .water404 {
      font-size: 140px;
      font-family: 'Sailec-Bold', 'Helvetica', 'san-serif';
      font-weight: bold;
    }
    @keyframes wave {
      from {
        top: 0%;
        x: -400px;
      }
      to {
        top: 99%;
        x: 0;
      }
    }
    @keyframes fill-up {
      from {
        top: 0%;
        height: 0;
        y: 120px;
      }
      to {
        top: 100%;
        height: 160px;
        y: -30px;
      }
    }
    .water-fill {
      animation: wave 1.5s infinite linear, fill-up 15s infinite ease-out alternate;
    }
  }

  /* BLOG GENERIC STYLES */

  .blog {
    display: flex;
    justify-content: flex-start;
    align-items: flex-start;
    max-width: 1170px;
    flex-direction: column;

    .container {
      max-width: 870px;
      margin-top: 200px;
      margin-right: 20px;
      margin-bottom: 60px;
      ${media('< desktop')} {
        width: 90vw;
        margin-top: 10px;
        margin-right: auto;
        margin-bottom: 20px;
      }
    }

    .blog-tag-container {
      width: 100%;
      display: flex;
      flex-direction: row;
      align-self: center;
      align-items: start;

      ${media('< desktop')} {
        margin-top: 64px;
        align-items: center;
        flex-direction: column;
      }

      ${media('< tablet')} {
        margin-top: 0px;
      }
    }

    div.disqus {
      margin: 80px 0;
      border-top: 1px solid #ccc;
      padding-top: 40px;
      ${media('< desktop')} {
        padding-top: 20px;
        margin: 20px 0;
      }
    }
    iframe {
      ${media('< desktop')} {
        max-width: 90vw;
      }
    }
  }

  /* PRICING OVERVIEW PAGE STYLES */
  .pricingoverview {
    .section:first-of-type {
      height: auto;
    }

    .section:not(:last-of-type) {
      padding: 64px 0 0 0 !important;
      margin-bottom: 42px;
      margin-left: 300px;

      @media (max-width: 1219px) {
        margin-left: 0;
      }

      .container {
        max-width: 870px;
        ${media('< tablet')} {
          margin: 0 20px;
        }
      }
      /* unifying all header tags for this page - gross solution */
      h3,
      h2 {
        margin-top: 0;
        margin-left: 0;
        margin-bottom: 0 !important;
        font-size: 24px;
        text-align: left;
      }
      div#testCards {
        margin-top: 24px !important;
      }
      div#testContentBlockContent {
        h5 {
          margin-top: 16px;
          font-size: 18px !important;
          margin: 32px 0 0 0;
        }
        p {
          margin-bottom: 0;
        }
      }
    }

    section#testPricingSection {
      h2,
      p {
        text-align: left;
        margin-left: 0 !important;

        @media (max-width: 1219px) {
          margin-left: 32px !important;
        }
      }

      div {
        div {
          div {
            max-width: 220px !important;

            @media (max-width: 1219px) {
              max-width: 100% !important;
            }
          }
        }
      }

      div.medium {
        p {
          @media (max-width: 1219px) {
            text-align: center;
          }
        }
      }

      .title.medium {
        height: 50px;

        @media (max-width: 1219px) {
          height: 25px;
        }
      }

      .price {
        font-size: 45px;
      }

      a {
        color: #0069ff !important;
      }

      .button {
        margin-bottom: 64px;
      }
    }
  }

  /* CURRENTS PAGE STYLES */
  .currents {
    #pageNavLinks {
      height: 20575px;
    }

    img {
      max-width: 750px;
      max-height: 600px;

      ${media('< desktop')} {
        max-width: 90%;
      }
    }

    ul,
    ol {
      list-style-position: inside;

      margin: 0 0 32px 0;
      li {
        margin-top: 24px;
      }
    }
    .section:last-of-type {
      margin-bottom: 120px;
    }

    .section:not(:first-of-type),
    .section#testContentBlockSection {
      padding: 120px 0 0 0 !important;
      margin-left: 320px;

      @media (max-width: 1219px) {
        margin-left: 0;
      }

      p {
        margin: 0px;
        padding: 8px 0;
      }

      .container {
        max-width: 870px;
        ${media('< tablet')} {
          margin: 0 8px;
        }
      }
    }

    #ListGrid {
      padding-top: 32px !important;
    }
  }
`;
