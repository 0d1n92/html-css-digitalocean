/* eslint no-unused-expressions: 0 */
/* eslint react/destructuring-assignment: 0 */

import React, { Component, useRef, useEffect } from 'react';
import PropTypes from 'prop-types';

import BulmaContainer from 'react-bulma-components/lib/components/container';
import { StyledMainLayout } from './layoutStyles';

import { Navigation, AnnouncementBar, Footer } from '../../components';

const PureLayout = ({ children, layout, location }) => {
  // Removing is-active class from mega menus when you click anywhere outside of the dropdown nav

  const entirePage = useRef();

  const handleClick = e => {
    const targetIsDropdown =
      e.target.id === 'solutionsMegaDropdown' ||
      e.target.id === 'productsMegaDropdown' ||
      e.target.id === 'communityMegaDropdown';

    const parentIsProductsDropdown = e.target.closest('#productsMegaDropdown');
    const parentIsCommunityDropdown = e.target.closest('#communityMegaDropdown');
    const parentIsSolutionsDropdown = e.target.closest('#solutionsMegaDropdown');

    const currentLink = e.target.classList.contains('navbar-link') || e.target.classList.contains('dropdown-item');
    const aDropdownIsCurrentlyActive = document.getElementsByClassName('is-active')[0];

    if (
      entirePage.current.contains(e.target) &&
      aDropdownIsCurrentlyActive &&
      !targetIsDropdown &&
      !parentIsSolutionsDropdown &&
      !parentIsProductsDropdown &&
      !parentIsCommunityDropdown &&
      !currentLink
    ) {
      aDropdownIsCurrentlyActive.classList.remove('is-active');
    }
  };

  useEffect(() => {
    // add when mounted
    document.addEventListener('mousedown', handleClick);
    // return function to be called when unmounted
    return () => {
      document.removeEventListener('mousedown', handleClick);
    };
  }, []);

  return (
    <StyledMainLayout ref={entirePage}>
      <Navigation location={location} />
      <BulmaContainer className={`${layout} container-main`} breakpoint="fullhd">
        <AnnouncementBar />
        {children}
      </BulmaContainer>
      <Footer />
    </StyledMainLayout>
  );
};

class MainLayout extends Component {
  render() {
    return <PureLayout {...this.props}>{this.props.children}</PureLayout>;
  }
}

export default MainLayout;

MainLayout.propTypes = {
  children: PropTypes.oneOfType([PropTypes.array, PropTypes.node]).isRequired,
};

PureLayout.propTypes = {
  children: PropTypes.oneOfType([PropTypes.array, PropTypes.node]).isRequired,
  layout: PropTypes.string,
  location: PropTypes.object,
};

PureLayout.defaultProps = {
  layout: null,
  location: null,
};
