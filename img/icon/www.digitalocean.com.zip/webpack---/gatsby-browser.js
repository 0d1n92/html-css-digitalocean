import './static/loadFonts.css';
import './static/prism.css';
import 'lazysizes';

import { registerLinkResolver } from 'gatsby-source-prismic-graphql';

import init from './src/util/tracking';
import { linkResolver } from './src/util/linkResolver';

import initHomepageTest from './src/util/homePageHeroMessagingTest';

registerLinkResolver(linkResolver);

export const onInitialClientRender = () => {
  window.cookieDomain = '.digitalocean.com';
  window.googleMapsApiKey = 'AIzaSyCSKmGpLScyml6i3_YOoKoE7UCUeYs-H0k';

  (function(w, d, s, l, i) {
    w[l] = w[l] || [];
    w[l].push({ 'gtm.start': new Date().getTime(), event: 'gtm.js' });
    const f = d.getElementsByTagName(s)[0];
    const j = d.createElement(s);
    const dl = l != 'dataLayer' ? `&l=${l}` : '';
    j.async = true;
    j.src = `https://www.googletagmanager.com/gtm.js?id=${i}${dl}`;
    f.parentNode.insertBefore(j, f);
  })(window, document, 'script', 'dataLayer', 'GTM-KHWBBT');

  !(function() {
    const analytics = (window.analytics = window.analytics || []);
    if (!analytics.initialize)
      if (analytics.invoked) window.console && console.error && console.error('Segment snippet included twice.');
      else {
        analytics.invoked = !0;
        analytics.methods = [
          'trackSubmit',
          'trackClick',
          'trackLink',
          'trackForm',
          'pageview',
          'identify',
          'reset',
          'group',
          'track',
          'ready',
          'alias',
          'debug',
          'page',
          'once',
          'off',
          'on',
        ];
        analytics.factory = function(t) {
          return function() {
            const e = Array.prototype.slice.call(arguments);
            e.unshift(t);
            analytics.push(e);
            return analytics;
          };
        };
        for (let t = 0; t < analytics.methods.length; t++) {
          const e = analytics.methods[t];
          analytics[e] = analytics.factory(e);
        }
        analytics.load = function(t, e) {
          const n = document.createElement('script');
          n.type = 'text/javascript';
          n.async = !0;
          n.src = `https://cdn.segment.com/analytics.js/v1/${t}/analytics.min.js`;
          const a = document.getElementsByTagName('script')[0];
          a.parentNode.insertBefore(n, a);
          analytics._loadOptions = e;
        };
        analytics.SNIPPET_VERSION = '4.1.0';
        analytics.load(
          'eodkqsm339',
          document.cookie.indexOf('cookieconsent_status=dismiss') > -1
            ? {}
            : { integrations: { All: false, 'Segment.io': true } },
        );
        analytics.page();
      }
  })();

  init();
  initHomepageTest();
};

export const onRouteUpdate = () => {
  window.analytics && window.analytics.page();
  window.dataLayer && window.dataLayer.push({
    event: 'pageviewCuttlefish',
    pagePath: `${window.location.pathname}`,
    pageTitle : `${window.document.title}`,
  });
};
